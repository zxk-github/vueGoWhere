<template>
  <div class="box">
    <el-container>
      <el-header>
        <button @click="jiankong">资粮监控</button>
        <button @click="shuju">监测数据</button>
      </el-header>
      <el-container>
        <!-- <el-aside width="200px">Aside</el-aside>
        <el-main>Main</el-main> -->
        <component :is="zujian"></component>
      </el-container>
    </el-container>
  </div>
</template>

<script>
import ziliangjiankong from './components/ziliangjiankong/ziliangjiankong.vue';
// import jianceshuju from './components/jianceshuju/jianceshuju.vue';
import jianceshuju from './components/jianceshuju/childTable';

  export default {
    data() {
      return {
        zujian: 'jianceshuju'
        
      }
    },
    methods: {
      jiankong() {
        this.zujian = 'ziliangjiankong'
      }, 
      shuju() {
        this.zujian = 'jianceshuju'
      }
    },
    components: {
      ziliangjiankong,
      jianceshuju
    }
  };
</script>

<style>
html, body{
  margin: 0;
  padding: 0;
}
html, body, .box, section{
  height: 100%;
}
.el-header, .el-footer {
    background-color: #B3C0D1;
    color: #333;
    text-align: center;
    line-height: 60px;
  }
  
  .el-aside {
    background-color: #D3DCE6;
    color: #333;
    text-align: center;
    line-height: 200px;
  }
  
  .el-main {
    background-color: #E9EEF3;
    color: #333;
    text-align: center;
    line-height: 160px;
  }
  
  body > .el-container {
    margin-bottom: 40px;
  }
</style>

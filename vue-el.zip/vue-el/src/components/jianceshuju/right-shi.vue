<template>
    <div>
        shishi
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('ssss')
        },
        destroyed() {
            console.log(1222);
        }
    }
</script>

<style scoped>

</style>
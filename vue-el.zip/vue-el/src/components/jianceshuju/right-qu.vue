<template>
    <div>
        ququq
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('qqq')
        },
        destroyed() {
            console.log(3333);
        }
    }
</script>

<style scoped>

</style>
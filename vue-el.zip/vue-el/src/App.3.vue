<template>
  <div>
    {{obj.a}}
  </div>
</template>

<script>
  export default {
      props: ['obj'],
      data() {
        return {
          objC: JSON.parse(JSON.stringify(this.obj))
        }
      },
      created() {
       
      },
      watch: {
        obj: {
          handler() {
            console.log(this)
            console.log(this.objC)
          },
          deep: true
        }
      }
  };
</script>
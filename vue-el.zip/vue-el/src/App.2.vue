
<template>
  <el-tree
  :data="data"
  :props="defaultProps"
  accordion
  @node-click="handleNodeClick">
</el-tree>
</template>


<script>
  export default {
    data() {
      return {
        data: [{
          label: '一级 1',
          children: [{
            label: '二级 1-1',
            children: [{
              label: '三级 1-1-1'
            }]
          }]
        }, {
          label: '一级 2',
          children: [{
            label: '二级 2-1',
            children: [{
              label: '三级 2-1-1'
            }]
          }, {
            label: '二级 2-2',
            children: [{
              label: '三级 2-2-1'
            }]
          }]
        }, {
          label: '一级 3',
          children: [{
            label: '二级 3-1',
            children: [{
              label: '三级 3-1-1'
            }]
          }, {
            label: '二级 3-2',
            children: [{
              label: '三级 3-2-1'
            }]
          }]
        }],
        defaultProps: {
          children: 'children',
          label: 'label'
        },
        nodes: {}
      };
    },
    methods: {
      handleNodeClick(data, node, vm) {

        console.log(data, node, vm);
        this.nodes = {};
        this.getParentNode(node)
        console.log(this.nodes);
      }, 
      getParentNode(node){
        let parent = node.parent;
        if(node.level == 1) { 
          this.nodes.quanguo = node.label;
        } else if(node.level == 2) {
          this.nodes.sheng = node.label;
        } else if(node.level == 3) {
          this.nodes.qu = node.label;
        } else if(node.level == 4) {
          this.nodes.zheng = node.label;
        }
        if(parent.level === 0) {
          return ;
        }
        this.getParentNode(parent);
      }
    }
  };
</script>
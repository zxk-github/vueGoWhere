<template>
  <div>
    <button @click="show">显示</button>
  </div>
</template>

<script>
  export default {
    methods: {
      show() {
        this.$loading.createLoading()
        setTimeout(() => {
          this.$loading.removeLoading()
        }, 2000);
      }
    }
  }
</script>

<style scoped>

</style>
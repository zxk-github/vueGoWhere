#!/bin/bash

BASE=/home/jiaoyaning/Android/jiagu/jiagu.jar
echo "$BASE"

#360加固账号
pwd
NAME=`grep jiagu_NAME ./config.properties | awk -F "=" '{print $2}'`
#360加固账号的密码
PASSWORD=`grep jiagu_PASSWORD ./config.properties | awk -F "=" '{print $2}'`
#密钥路径
KEYSTORE_FILE=`grep KEYSTORE_FILE ./config.properties | awk -F "=" '{print $2}'`
#密钥密码
KEYSTORE_PASSWORD=`grep KEYSTORE_PASSWORD ./config.properties | awk -F "=" '{print $2}'`
#别名
KEY_ALIAS=`grep KEY_ALIAS ./config.properties | awk -F "=" '{print $2}'`
#别名密码
KEY_PASSWORD=`grep KEY_PASSWORD ./config.properties | awk -F "=" '{print $2}'`

outputDir=`grep appReleaseDir ./config.properties | awk -F "=" '{print $2}'`

#需要加固的apk路径
apkPath=`grep apkPath ./config.properties | awk -F "=" '{print $2}'`
#输出加固包路径
DEST=${outputDir}

echo "------ running! ------"

java -jar ${BASE} -version
java -jar ${BASE} -login ${NAME} ${PASSWORD}
java -jar ${BASE} -importsign ${KEYSTORE_FILE} ${KEYSTORE_PASSWORD} ${KEY_ALIAS} ${KEY_PASSWORD}
java -jar ${BASE} -showsign
#java -jar ${BASE}/jiagu.jar -importmulpkg ${BASE}/多渠道模板.txt #根据自身情况使用
java -jar ${BASE} -showmulpkg
java -jar ${BASE} -showconfig
java -jar ${BASE} -jiagu ${apkPath} ${DEST} -autosign

echo "------ finished! ------"

#-login          <username>                    首次使用必须先登录 <360用户名>
#                <password>                    <登录密码>

#-importsign     <keystore_path>               导入签名信息 <密钥路径>
#                <keystore_password>           <密钥密码>
#                <alias>                       <别名>
#                <alias_password>              <别名密码>

#-importmulpkg   <mulpkg_filepath>             导入多渠道配置信息，txt格式
#-showsign                                     查看已配置的签名信息
#-showmulpkg                                   查看已配置的多渠道信息
#-help                                         显示帮助信息

#-config         [-update]                     配置加固可选项 【升级通知】
#                [-crashlog]                  【崩溃日志】
#                [-x86]                       【x86支持】

#-showconfig                                   显示已配置加固项
#-version                                      显示当前版本号
#-update                                       升级到最新版本

#-jiagu          <inputAPKpath>                加固命令 <APK路径>
#                <outputPath>                  <输出路径>
#                [-autosign]                  【自动签名】
#                [-automulpkg]                【自动多渠道】
#                [-pkgparam mulpkg_filepath]  【自定义文件生成多渠道】
#!/bin/sh

#appEnv=$1

#outputDir=`grep appReleaseDir ./config.properties | awk -F "=" '{print $2}'`
#appVersionName=`grep appVersionName ./config.properties | awk -F "=" '{print $2}'`
#appName="nonghe${appEnv}-${appVersionName}"
#echo ${appName}

#apkDir="${outputDir}/${appName}.apk"

apkPath=`grep apkPath ./config.properties | awk -F "=" '{print $2}'`
echo "apkPath:${apkPath}"

upds=`grep updateDescription ./config.properties | awk -F "=" '{print $2}' | awk 'BEGIN {FS="\ ";RS="";ORS=""} { x=1; while(x<NF) { print $x "\n"; x++} print $NF "\n"}'`
echo "upds:${upds}"

a=`curl -F "file=@${apkPath}" \
-F "uKey=7ea02c9349abdb052c263db7ca4ce9c4" \
-F "_api_key=e82e4fc6296107d021bd20f0723b18d8" \
-F "updateDescription=${upds}" \
https://qiniu-storage.pgyer.com/apiv1/app/upload`

echo $a

code=`echo $a | awk -F ":|," '{print $2}'`
if [[ $code == 0 ]]; then
    echo "上传成功！！！"
else
    echo "上传失败失败失败失败失败失败失败！！！"
fi
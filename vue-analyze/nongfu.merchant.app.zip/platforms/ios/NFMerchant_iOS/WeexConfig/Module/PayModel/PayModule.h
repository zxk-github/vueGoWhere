//
//  PayModule.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2017/12/15.
//  Copyright © 2017年 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WeexSDK/WeexSDK.h>

@interface PayModule : NSObject<WXModuleProtocol>
@end

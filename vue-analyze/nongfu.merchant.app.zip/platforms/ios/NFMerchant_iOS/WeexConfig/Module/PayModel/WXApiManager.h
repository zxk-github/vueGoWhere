//
//  WXApiManager.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2017/12/15.
//  Copyright © 2017年 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WechatOpenSDK/WXApi.h>

#define WX_AppId  @"wx84116c02d50bb9c8"
@protocol WXApiManagerDelegate <NSObject>
@optional
-(void)WechatDidFinishPayWithInfo:(NSDictionary *) info;
    
@end

typedef void(^WechatDidFinishPayBlock)(NSDictionary* info);

@interface WXApiManager : NSObject<WXApiDelegate>
@property (nonatomic, assign) id<WXApiManagerDelegate> delegate;

+ (instancetype)sharedManager;
@property (nonatomic, copy) WechatDidFinishPayBlock payHandler;
//-(void)setPayFinishHandler:(WechatDidFinishPayBlock)handler;

@end

//
//  PayModule.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2017/12/15.
//  Copyright © 2017年 taobao. All rights reserved.
//

#import "PayModule.h"
#import <WechatOpenSDK/WXApi.h>
#import "WXApiManager.h"



@implementation PayModule
WX_EXPORT_METHOD(@selector(wechatPayment:))
@synthesize weexInstance;


-(void)wechatPayment:(NSDictionary *)info {
    if (![WXApi isWXAppInstalled]) {
//        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"抱歉" message:@"您的手机未安装微信" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
//            [alertView show];
        [weexInstance fireGlobalEvent:@"NongheNativeCallback" params:@{@"params":@"",@"status":@"fail", @"execution":info[@"execution"],@"result":@{@"res":@"用户未安装微信"} }];
        return;
    }
    NSString *dealResult = [self wechatPayWithParams:info[@"params"]];
    if ([dealResult isEqualToString:@"success"]) {//数据没问题 可以唤起微信
        //处理支付结果
        [[WXApiManager sharedManager] setPayHandler:^(NSDictionary *payResult) {
            NSString *status = @"fail";
            if ([payResult[@"retstr"] isEqualToString:@"success"]){
                status = @"success";
            } else {
                status = @"fail";
            }
            
//            if () {
//                status = @"cancle";
//            }
            
            [weexInstance fireGlobalEvent:@"NongheNativeCallback" params:@{@"params":@"",@"status":status, @"execution":info[@"execution"],@"result":@{@"res": payResult[@"retstr"]} }];
        }];
        
        
    } else {
        [weexInstance fireGlobalEvent:@"NongheNativeCallback" params:@{@"params":@"",@"status":@"fail", @"execution":info[@"execution"],@"result":@{@"res": dealResult} }];
    }
    
    



}
-(NSString *) wechatPayWithParams:(NSDictionary *)params{
    
    if (params != nil){
        NSMutableString *retcode = [params objectForKey:@"retcode"];
        if (retcode.intValue == 0){
            NSMutableString *stamp  = [params objectForKey:@"timestamp"];
            //调起微信支付
            PayReq* req = [[PayReq alloc] init];
            req.partnerId = [params objectForKey:@"partnerid"];
            req.prepayId = [params objectForKey:@"prepayid"];
            req.nonceStr = [params objectForKey:@"noncestr"];
            req.timeStamp = stamp.intValue;
            req.package = [params objectForKey:@"package"];
            req.sign = [params objectForKey:@"sign"];
            [WXApi sendReq:req];
            //日志输出
        NSLog(@"appid=%@\npartid=%@\nprepayid=%@\nnoncestr=%@\ntimestamp=%ld\npackage=%@\nsign=%@",[params objectForKey:@"appid"],req.partnerId,req.prepayId,req.nonceStr,(long)req.timeStamp,req.package,req.sign);
            return @"success";
        }else{
            return [params objectForKey:@"retmsg"];
        }
    }else{
        return @"服务器返回错误，未获取到json对象";
    }
    
    

}
@end

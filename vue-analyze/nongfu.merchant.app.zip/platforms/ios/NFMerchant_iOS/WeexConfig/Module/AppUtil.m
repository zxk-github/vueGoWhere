//
//  AppUtil.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2017/12/15.
//  Copyright © 2017年 taobao. All rights reserved.
//

#import "AppUtil.h"
#import <WechatOpenSDK/WXApi.h>
#if DEVELOPMENT
#import "NFMerchant_iOSDev-Swift.h"
#else
#import "NFMerchant_iOS-Swift.h"
#endif
#import "Reachability.h"
#import "StorageModule.h"

@implementation AppUtil
WX_EXPORT_METHOD(@selector(judgeAppIsInatalledByTargetInfo:))
WX_EXPORT_METHOD(@selector(getVersion:))
WX_EXPORT_METHOD(@selector(openApp:callback:))
WX_EXPORT_METHOD(@selector(getNetWortState:))

@synthesize weexInstance;
-(void)judgeAppIsInatalledByTargetInfo:(NSDictionary *)info{
    NSString *appName = info[@"params"][@"appName"];
    if([appName isEqualToString:@"weixin"]){
        
        [weexInstance fireGlobalEvent:@"NongheNativeCallback" params:@{@"params":@"",@"status":@"success", @"execution":info[@"execution"],@"result":@{@"res": ( [WXApi isWXAppInstalled] ? @"1" : @"0")}}];
        
        ;
    }
}

+(NSString * _Nonnull )getAccessToken{
    __block NSString *token = @"";
    StorageModule *storage = [[StorageModule alloc] init];
    [storage getItem:@"nongfu.merchant.state" callback:^(NSDictionary* result) {
        if([result[@"result"] isEqualToString:@"success"]){
            NSString *jsonStr = result[@"data"];
            NSError *error = nil;
            NSDictionary *data = [NSJSONSerialization JSONObjectWithData:[jsonStr dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingMutableContainers error:&error];
            if (!error) {
                token = data[@"auth"][@"user"][@"access_token"];
            }
            
        }
    }];
    return token;
}


+(NSString *)imageSavedPath {
    NSString *path = [NSString stringWithFormat:@"%@/Library/Caches/userImage/",NSHomeDirectory()];
    [[NSFileManager defaultManager] createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
    return [NSString stringWithFormat:@"%@/Library/Caches/userImage/",NSHomeDirectory()];
}



-(void)getVersion:(WXModuleKeepAliveCallback)callback {
    return callback(@{@"result":@"success", @"data": @{@"version": [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]}}, NO);
}

-(void)openApp:(NSDictionary *)options callback:(WXModuleKeepAliveCallback)callBack{
    NSString *url = options[@"url"];
    //通用链接
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url] options:@{UIApplicationOpenURLOptionUniversalLinksOnly: [NSNumber numberWithBool:YES]} completionHandler:^(BOOL success) {
        if (success) {
            callBack(@{@"result": @"success"}, NO);
        } else{
            callBack(@{@"result": @"error"}, NO);
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://itunes.apple.com/app/apple-store/id1112082855"] options:@{} completionHandler:nil];
        }
        
    }];
}

-(void)getNetWortState:(WXModuleKeepAliveCallback)callback{
    NetworkStatus status = [[(AppDelegate *)[UIApplication sharedApplication].delegate reachablity] currentReachabilityStatus];
    NSString *networkState = @"";
    NSString *result = @"error";
    switch (status) {
        case NotReachable:
            networkState = @"undefined";
            result = @"success";
            break;
        case ReachableViaWiFi:
            networkState = @"WIFI";
            result = @"success";
            break;
        case ReachableViaWWAN:
            networkState = @"4G";
            result = @"success";
            break;
    }
    callback(@{@"networkState":networkState, @"result": result}, NO);
    
}


@end

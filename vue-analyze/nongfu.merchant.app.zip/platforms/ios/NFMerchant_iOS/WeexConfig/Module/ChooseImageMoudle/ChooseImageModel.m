//
//  ChooseImageModel.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2017/8/17.
//  Copyright © 2017年 taobao. All rights reserved.
//

#import "ChooseImageModel.h"
//#import <BlocksKit/UIImagePickerController+BlocksKit.h>
#import "SystemPermissionsManager.h"
#import <TZImagePickerController/TZImagePickerController.h>
#import "GlobalUtil.h"
#import "NHNetWorkEngine.h"
#import "AppUtil.h"
#import "UIImage+WT.h"
//#import <UIAlertView+BlocksKit.h>

@interface ChooseImageModel ()<TZImagePickerControllerDelegate>
@end

@implementation ChooseImageModel
@synthesize weexInstance;
WX_EXPORT_METHOD(@selector(chooseImage:callback:))
WX_EXPORT_METHOD(@selector(uploadImage:callback:))



-(instancetype)init{
    if (self = [super init]) {
    }
    return self;
}

//发起的 action json
/*
{"action":"chooseImage","params":{"crop":true,"count":1,"sizeType":["original","compressed"],"sourceType":["album","camera"]},"execution":"execution43"} 
*/


//传过去的
/*
 
 {
 "result" : {
 "res" : {
 "localIds" : [
 {
 "id" : "\/var\/mobile\/Containers\/Data\/Application\/93DCFCAE-2A5C-4C29-916C-847A33401C32\/Documents\/photo1513337079254.3220210.png",
 "url" : "data:image\/png;base64,\/9j\/4AAQSkZJRgABAQAASABIAAD\/4QBYRXhpZgAATU0AKgAAAAgAAgESAAMAAAABAAEAAIdpAAQAAAABAAAAJgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAyKADAAQAAAABAAAAyAAAAAD\/7QA4UGhvdG9zaG9wIDMuMAA4QklNBAQAAAAAAAA4QklNBCUAAAAAABDUHYzZjwCyBOmACZjs+EJ+\/8AAEQgAyADIAwEiAAIRAQMRAf\/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC\/\/EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29\/j5+v\/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC\/\/EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29\/j5+v\/bAEMABgYGBgYGCgYGCg4KCgoOEg4ODg4SFxISEhISFxwXFxcXFxccHBwcHBwcHCIiIiIiIicnJycnLCwsLCwsLCwsLP\/bAEMBBwcHCwoLEwoKEy4fGh8uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLv\/dAAQADf\/aAAwDAQACEQMRAD8A4W18PafbfMyeY3q3NXmOnwsI9qFz0VVBJ\/AVMuj3c\/N9OxH9yP5V\/PrWpb2NtZjEEYU9zjn863k3LWTuUlbYzFtZZvuwpEPVwCfyH+NWF0m0JzOBJ7EAD8hWp05NQuS3A4FKwyvJFbbDDHEgBGPuiuYgSJIyHRflJHQdq6zhegyadY6UkUjXM+GZjkL2H\/16qKAraXpqEC5uYlA\/hUgZ+praNvb\/APPNP++RU5phrRRKIfs9v\/zzT\/vkUv2e3\/55p\/3yKkzUE1xHAMyHHoO5oESiG3H\/ACzT\/vkVWlu7SI7FjR29Ao\/U1zOpa9sPlA7fUDrj3Nc7JfOziWB+nbtWcmhXOzuSLj76IP8AZCgCsW+0+2lQB41P4YxWGut3MDbZl3L61fXW7ObCsdpPY1ncCqLDySPKPyjswBFaMepzWPSMMnptDD\/EVOjwzDMbBvpTjAppWHc07LxHpE2FuI0jY+wP6da6i3FhcLvhWNx7AV5RqgsbYeZOoLDpxzn2qGDU5op42s2Me7hiPQ9qmTs0khp3Z7OLa2P\/ACyT\/vkU8WtsP+WSf98ivMWuNUfkyu30aun8P38iRSQXjEbTuUuex6ioU23Zo6J0VGPMpJnSPa25\/wCWSf8AfIqlc2tmIz5kUZHoVH+Fc1qPi82120NrEssa8biSMnv+Fczq\/im5vrdoFUQl+CQecelPmRjY5vXhps14yWUKKqk5ZRgE+2O1YElrEoLEACrhEfdh+dMMRZt27IHQdeafMjNpmUsAeQxnjA7c1J9iH94\/lVtoGDtLkAH0qPb\/ALTfnRzIOVn\/0JGWo2UAZNXtm47V60z7I7ZJYVsjQy2BbrTCD0WtQ2bZ+8KbJEtrGZn5xTCxDb2wT536+npVo0iurKGHekJrRKwCGmGlzTT04qgM7UL5bSJmzgqMknnArzq88QyszG3Byf435P4DoK1\/EhxcFWkdUcckfdz6EViQLBDtWe3W4iYjJDbT+DDpn3FZyZLZjNLJMS7kknqTTNxHQ4r2vS\/Cvhy40W6uzaymWONpkDSKOF6An3HtXjWqvbfbJDZxNDDn5UZtxX2JwKza7CasQ\/aG6dqpyCOVsqdjD8qiM3r0qszlzx0qQNCO9vrNhg59D1B\/Gt9PEr+WEWPe2OSexrmULmMrJ9w+vWr1rZyXWI4V2r3Y96dgK9zcTXUvmStvf9BW7pdi7FZZOfStWz0WFQBtyR3NdAtusK4Uc1SiMhiTYMHrVe\/ufIhKqfmbgf1q6QEBZug5rmLubzXaV+nb2FRVnyqyLirmVdOyR4X7zcCs8aZckZOcn1rc06FZ7k3M33U6D3PSuqiiUnJHSsoR0G3c84\/su69KvQ2pjiCMMnqfrXcXrRwW5bA3NwK5iUiNC\/tWdV20RUV1OevOGEa8f41S8l\/WpLuUq+4ckc\/jVP7dL6CritCJPU\/\/0dSAfIznucZp\/Y1nLqVogCOcEdfrSHVrLpu\/UVqmamkoyaxNZYyKlorYzyasrrVijbgc8HvXH6zftLcSPGCV2kq3bjjFO4mdJBJsjCkjj3qx5if3h+dcBa37lcXMTD3FbEUkEpHlODns3+c1akxXOnDoe4\/OgsMcGsDAzgr+VG1+kbc+mSKd2BLeWkNyCrjOa5K40a4tGMti231XqD+FdSTdp1z\/ADpPtLDiRQfqMUn5oRyVtqstpuglHkMwIORmNs+3b8KpahZRzRo0IKux56FD7g\/5NdfPb2F2pWZMZ7jmsWTQZogf7NuV2nrHJwDUsLHAT2cyMdy4OelILV0TdjJ9K6WXStbDeTJDsXP3l+YfnzWlbaIp5lyT\/OpSuIw9O0trkiW4OVHYV29pp6qBhdqirVppyRAZGAOgrWVABxWiiNIqiNUXgYAquRk5q3Lg\/KKqzuIYXm\/ugmm9BmLqNxz9nXt97\/CueulkIVFHDGrTXcLsWZuTyaQyxN\/EK86U25czNktLF+1hS3iORkR8n3b0\/Cs5mldzKwYZ54zyalWeVP8AVOfwNTtd3ZUrvPPBq\/bInkKas5GXJJ96pX0uECfjWiOFJfoBXOTy+cd\/QHmsFq7st6KxkXHO6s\/FXZidxFVsV1LY53uf\/9LHlSJx+8UEe9cjd+WZiYDsX3ya1tRvMAwoee9YBavBwdScHzN6HtYiEZq1ixHbzv8A6pkf6GtezsrmQCKcAIDk\/wCFc28TYEi9+4q3b6nfW5AWQkDs3I\/WvoIyTVzyGrOzO2SzRuAoxRJpVsw5Xn1rJg8ROoAniBHqpx+hrWh1ixn4D7D6Nx\/9atFJDKp06aL\/AI95WHseRUZa8j4mjEg9RW4HVxlSCPUVct7ZZzgnA9aoVjl0vYwcZZD6f\/WPFXFmEg\/hf9D\/AIVq3lhAp2nDg+1ZD6ZGDmFih9qdxCPHaHl1MZ\/L\/wCtUZsCRmGQEUvk30P3cSCovtCoczxNEfUcfrTugG+XewdAce3NKLwA\/vkBP0wauR3Qf\/VyhvZv8akYo\/8Arosj1Hzf\/Xo5UBBDOk0gjUEZrS2r0xWM9nEX821fDjtnH6ULe3NsNs65561DTC5qPAhPHFctf6hCbWePvyo9x61qXWsQJaSMMhsYH41xVyyTQfK2Qecj25rKc2tEUjH3Um\/FMzTc1zGlyUynp0qMykc5qJjUdKwrjpbiTY2GOMHvUaD5FUdcAU4QTXGY4VLMeMAZrWGmPb4+2OImHIj+8\/4qOn4kU7paCbORmBWVhnODio61rqazRysERZs8s5\/oKqfaf+maflWyb7GTP\/\/T8N\/4SbVzyZEP1jQ\/0o\/4SXUu4hP1iT\/CsTaaNlLlXYvmfc6FfFGoqNvlwEf9cxS\/8JPdH71tbH\/gH+Brndppdpq0S2dKPE8mMGztz+DD\/wBmp48TL\/FYwn6Fx\/7NXMBDS7DTC52EPitIjlLNV\/3ZXH9a2YPHzx8Czz\/20P8AhXnISrMRYMB\/OqQXPUP+Erna0+3y2DeTu27vNHX6EZqn\/wAJ1Z4wbOUH1Dg\/+y1l62y2emWWnqfm2eZIOwZq5Flz1q5qzsJNs7r\/AIS3TGbM0V23t5gA\/QCl\/wCEr0nOY\/tkftuVx+TZrgCgFMZalzYrI9EfxJ4amALx3CP3ZVUZ\/Ddilh8S6JEflnucejRqf\/Zq842Gk2GlzDPVh4r8PMMPJMfrED\/7NSnxL4bI+W4lX6xZH5ZNeUbTTdpo5mO56Xeat4bu4WiF0UJ\/i8lun51jTjQZIvKi1IIOOsL9PwrjNppNlS9dwudX9l0Y9NVj\/GKT\/Ck+xaSemqw\/98Sf\/E1y3l0eXUciK5mdQbDTT01S3\/FZB\/7LT4dN0syr52p2\/l5527849srXJ7KNlLkQczPSLu5gjtvsei31pbJ3bcwdvq23NYUGnRpM0r39q2VwP3hz+orlCtGwilClGOwnI2ZNBkdyy3lmc\/8ATYf4VH\/wj03\/AD9Wn\/f4Vk7DSbKuwj\/\/1OW\/4VvppbYuoygg4IMGcH3wakuvhWlqQH1IDIJGYSemPRvevbMQxuV8qXGfvLyD+RqVBDIm8LIoyRh8g\/XrWPPLub+52PCofhRcXWfsuowvjGcxuMZqA\/C29526ha\/KSCG3ryP+A19CxRx7gqkjJ9anMVgxxJJypI+Zf8RVKbFaB87L8JNekYrDcWkhHUB2\/wDiah\/4VX4jJ2o9qxzjAmAOfxAr6Yhisof9VMqZ9AB0\/Cm\/YdNdtxeIsT14zVc7FaJ8zt8K\/FqqXEETKOpEyY4+pFPtvhl4sjnjeWy3IGBO2SM8f99V9QQWcCQm2ikj2NnIz6\/jViHRrZUZyFwB\/eP5\/eqozdxcsT5d1vwP4uvtQkmj02QrwFAKk4HA4DVht4C8XL9\/TLj8Fz\/
 
 */
- (void)chooseImage:(NSDictionary *)options callback:(WXModuleKeepAliveCallback)callback{
    [SystemPermissionsManager requestAuthorization:KALAssetsLibrary completionHandler:^(BOOL granted) {
        if (granted) {
            NSInteger imageCount = [options[@"count"] integerValue];
            TZImagePickerController *imagePickerVc = [[TZImagePickerController alloc] initWithMaxImagesCount:imageCount delegate:self];
            imagePickerVc.allowCrop = [options[@"crop"] boolValue];
            imagePickerVc.allowPickingOriginalPhoto = NO;
            imagePickerVc.allowPickingGif = NO;
            imagePickerVc.allowPickingVideo = NO;
            imagePickerVc.sortAscendingByModificationDate = YES;
            imagePickerVc.barItemTextColor = [UIColor whiteColor];
            // 设置竖屏下的裁剪尺寸
            NSInteger left = 30;
            NSInteger widthHeight = UI_SCREEN_WIDTH - 2 * left;
            NSInteger top = (UI_SCREEN_HEIGHT - widthHeight) / 2;
            imagePickerVc.cropRect = CGRectMake(left, top, widthHeight, widthHeight);
            // You can get the photos by block, the same as by delegate.
            // 你可以通过block或者代理，来得到用户选择的照片.
            [imagePickerVc setDidFinishPickingPhotosHandle:^(NSArray<UIImage *> *photos, NSArray *assets, BOOL isSelectOriginalPhoto) {
                NSMutableArray *jsRes =  @[].mutableCopy;
                
                [photos enumerateObjectsUsingBlock:^(UIImage * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    NSLog(@"%@", [NSThread currentThread]);
                    NSMutableDictionary *imageInfos = @{}.mutableCopy;
                    NSData *pre = UIImageJPEGRepresentation(obj,1.0);
                    NSLog(@"压缩前   %lf", ([pre length] / 1024.0 / 1024.0));
                    UIImage *resizeImg = [obj allowMaxImg_thum:NO];
                    NSData *imageData = UIImageJPEGRepresentation(resizeImg, 0.5);
                    NSLog(@"压缩后   %lf", ([imageData length] / 1024.0 / 1024.0));
//                    NSString *base64 = [imageData base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
                    NSString *imageName = [NSString stringWithFormat:@"photo%f%ld.jpg",[[NSDate date] timeIntervalSince1970],(unsigned long)idx];
                    NSString *imagePath = [NSString stringWithFormat:@"%@%@",[AppUtil imageSavedPath], imageName];
                    BOOL res = [[NSFileManager defaultManager] createFileAtPath: imagePath contents:imageData attributes:nil];
                    if (!res) {
                        callback(@{@"result": @"fail", @"data": @""}, NO);
                        return ;
                    }
                    [imageInfos setObject:[NSString stringWithFormat:@"localfile://%@", imagePath] forKey:@"url"];
                    [jsRes addObject:imageInfos];
                    NSLog(@"%ld", imageData.length);
                }];
                if (jsRes.count > 0) {
                    NSDictionary *params = @{@"result" : @"success",@"data": jsRes};
                    callback(params, NO);
                } else {
                    callback(@{@"result": @"fail", @"data": @""}, NO);
                }
            }];
            dispatch_async(dispatch_get_main_queue(), ^{
                [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:imagePickerVc animated:YES completion:nil];
            });
            
        } else {
            callback(@{@"result": @"unauthorized", @"data": @""}, NO);
        }
    }];
}


/* 传过来的

 
 
 * @param  {[string]} localId [图片本地ID]
 * @param  {[string]} repoDomain [图片上传的域]
 * @param  {[string]} catagory [图片对应模块]
 * @param  {[number]} cropWidth [图片裁剪宽度，可选]
 * @param  {[number]} cropHeight [图片裁剪高度，可选]
 * @param  {[string]} accessToken [token]
 * @param  {[function]} [success] [成功回调]
 * @param  {[function]} [fail] [失败回调]
 
 {
 execution = execution4;
 params =     {
 authorization = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoibGtjcyIsImlhdCI6MTUyMDU2NTIyMSwib3d0IjoidXNlciIsImV4cCI6MTUyMzE1NzIyMSwiYXVkIjoic3pub25nZnU6bWVyY2hhbnQ6and0OmFjY2VzcyIsImlzcyI6InN6bm9uZ2Z1Lm1lcmNoYW50LmFwcCIsInN1YiI6IjkzYTFlYjY0LTFjMmQtMTFlOC1hNGNkLTE0MTg3NzVkNDBlZiIsImp0aSI6IjhkN2I3YTJlLTRiN2UtNDA0NS1hNTIwLTVjYTVjYjQxMzk1YyJ9.UvXpErdD4UpxjZsLd0tNCURj9r1X6Gz7Ll__24TyWkg";
 catagory = merchantStore;
 cropHeight = 195;
 cropWidth = 244;
 localId = "localfile:///var/mobile/Containers/Data/Application/1EAF8D56-B772-45E4-B87C-BC7B5ABE06C7/Library/Caches/userImage/photo1520591588.1086490.jpg";
 repoDomain = "stage.repo.merchant.sznongfu.com";
 };
 }
 
 
 */

/*传回去的
 {\"result\":{\"res\":{\"image\":{\"fieldname\":\"uploadfile\",\"originalname\":\"001.png\",\"url\":\"sns\/S0yL_JxoqfKWUHHK4EprNTnEg-vERbTE.png\"},\"thumbnail\":{\"height\":269,\"compressMethod\":\"thumb\",\"fieldname\":\"uploadfile\",\"originalname\":\"001.png\",\"url\":\"sns\/S0yL_JxoqfKWUHHK4EprNTnEg-vERbTE_thumbnail.png\",\"width\":300}}},\"status\":\"success\",\"execution\":\"execution31\",\"action\":\"uploadImage\"}
 
 */

- (void)uploadImage:(NSDictionary *)options callback:(WXModuleKeepAliveCallback)callback{
    
    //formData: 表单数据(如图片,文件)的信息 格式如:{"input":"uploadfile","name":"001.png","data":"xxxxx",type:"image/png"}
    
    if ([AppUtil getAccessToken].length > 0) {
        NSMutableArray *array = @[].mutableCopy;
        NSArray *imagePaths = options[@"photos"];
        BOOL haveOperation = [options valueForKey:@"operation"] && [[options valueForKey:@"operation"] isEqualToString:@"thumbnail"];
        [imagePaths enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSString *imagePath = [obj[@"url"] substringFromIndex:11];
            NSData *imageData = [NSData dataWithContentsOfFile:imagePath];
            NSDictionary *imageInfo = @{
                                    @"input": [NSString stringWithFormat:@"%@%ld",@"uploadfile",idx] ,
                                    @"name": [NSString stringWithFormat:@"%ld.jpg",(unsigned long)imagePath.hash],
                                    @"data": imageData,
                                    @"type": @"image/jpeg",
                                    };
            NSMutableDictionary *parameters = @{}.mutableCopy;
            if (haveOperation) {
                [parameters setObject:[NSString stringWithFormat:@"{\"operation\":\"%@\", \"options\": {\"width\":%@,\"height\":%@}}", options[@"operation"], options[@"cropWidth"], options[@"cropHeight"]] forKey:imageInfo[@"input"]];
            }
            [array addObject: @{@"file":imageInfo, @"action": parameters}];
        }];
        NSString *domain = [GlobalUtil environmentInfo][@"repo_domain"];
        NSString *uploadUrl = [NSString stringWithFormat:@"http://%@/api/v1.0/multiparts/images/upload", domain];

        [NHNetWorkEngine postFormDataRequest:uploadUrl configHeaderDic:@{@"x-nongfu-category" : options[@"catagory"], @"authorization": [NSString stringWithFormat:@"Bearer %@",[AppUtil getAccessToken]]} parameters:nil formData:array success:^(NSURLSessionDataTask * _Nullable task, id  _Nullable responseObject) {
        
                NSArray *result = responseObject;
                if (result) {
                    NSMutableArray *final = @[].mutableCopy;
                    [result enumerateObjectsUsingBlock:^(NSMutableDictionary *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                        NSMutableDictionary *imageInfo = obj.mutableCopy;
                        NSMutableDictionary * res = obj[@"image"];
                        [res setObject:[NSString stringWithFormat:@"http://%@/%@",domain, res[@"url"]] forKey:@"url"];
                        [imageInfo setObject:res forKey:@"image"];
                    
                        NSMutableDictionary * res2 = obj[@"thumbnail"];
                        if (res2) {
                            [res2 setObject:[NSString stringWithFormat:@"http://%@/%@",domain, res2[@"url"]] forKey:@"url"];
                            [imageInfo setObject:res2 forKey:@"thumbnail"];
                        }
                        [final addObject:imageInfo];
                    }];
                
                    callback(@{@"result": @"success", @"data": final}, NO);
                } else {
                    callback(@{@"result": @"fail", @"data": @""}, NO);
                }
            
            [imagePaths enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSString *imagePath = [obj[@"url"] substringFromIndex:11];
            [[NSFileManager defaultManager] removeItemAtPath:imagePath error:nil];
        }];
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nullable error) {
            callback(@{@"result": @"fail", @"data": @""}, NO);
        }];

    } else {
        callback(@{@"result": @"fail", @"data": @""}, NO);
    }
    
    
    
}
@end

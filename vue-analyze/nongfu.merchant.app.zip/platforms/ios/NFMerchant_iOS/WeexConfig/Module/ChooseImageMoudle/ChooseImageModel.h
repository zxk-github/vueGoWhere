//
//  ChooseImageModel.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2017/8/17.
//  Copyright © 2017年 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WeexSDK/WeexSDK.h>
@interface ChooseImageModel : NSObject<WXModuleProtocol>

@end

//
//  MultilevelPickerModule.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/3.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WeexSDK/WXModuleProtocol.h>
@interface MultilevelPickerModule : NSObject<WXModuleProtocol>
@property(nonatomic, strong) UIView *pickerContainer;
@end

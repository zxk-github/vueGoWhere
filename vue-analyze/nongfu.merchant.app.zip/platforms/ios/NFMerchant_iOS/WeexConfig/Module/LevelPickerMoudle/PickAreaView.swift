//
//  PickAreaView.swift
//  NongheMobileApp
//
//  Created by 胡鹏飞 on 2017/8/7.
//
//

import UIKit
import SwiftyJSON
@objcMembers
class PickAreaView: UIView, UIPickerViewDelegate,UIPickerViewDataSource {
    var sure: (([[String: String]])->Void)!
    var cancle: (()->Void)!
    var index: Int = 0 // 显示在tableview 的哪个cell
    private var changedComponent = 0//被改变的列
    private var numberOfColumn = 0// 多少列
    
    private var dataSource:JSON!
    //省市区row默认值
    private var provinceSelect = 0
    private var citySelect = 0
    private var districtSelect = 0
    
    @IBOutlet weak var pickerView: UIPickerView!
    @objc @IBAction func handleSure(_ sender: UIButton) {
        
        if numberOfColumn == 0 {
            return;
        }
        if self.sure != nil && dataSource != nil {
            
            var result: [Dictionary<String, String>] = [];
            if numberOfColumn == 1 {
                let province = self.dataSource[provinceSelect]
                result = [ ["name": province["name"].stringValue, "id": province["id"].stringValue] ]
            }
            if numberOfColumn == 2 {
                let province = self.dataSource[provinceSelect]
                let city = self.dataSource[provinceSelect]["children"][citySelect]
                result = [ ["name": province["name"].stringValue, "id": province["id"].stringValue], ["name": city["name"].stringValue, "id": city["id"].stringValue] ]
            }
            if numberOfColumn == 3 {
                let province = self.dataSource[provinceSelect]
                let city = self.dataSource[provinceSelect]["children"][citySelect]
                let district = self.dataSource[provinceSelect]["children"][citySelect]["children"][districtSelect]
                result = [
                    ["name": province["name"].stringValue, "id": province["id"].stringValue],
                    ["name": city["name"].stringValue, "id": city["id"].stringValue],
                    ["name": district["name"].stringValue, "id": district["id"].stringValue]
                ]
            }
            self.sure(result)
            //消除 因滑的过快点击了确定 didselect没有执行  导致显示错位
            var row = 0
            switch changedComponent {
            case 0:
                row = provinceSelect
            case 1:
                row = citySelect
            case 2:
                row = districtSelect
            default:
                break
            }
            pickerView.selectRow(row, inComponent: changedComponent, animated: false)

        }
    }
    @objc @IBAction func handleCancle(_ sender: UIButton) {
        if self.cancle != nil {
            self.cancle()
        }
    }
    
    @objc func showIn(view: UIView) {
        self.alpha = 0
        view.addSubview(self)
        UIView.animate(withDuration: 0.25) {
            view.alpha = 1
        }
    }
    
    
    var contentView:UIView!
    
    private override init(frame: CGRect) {
        super.init(frame: frame)
        contentView = loadViewFromNib()
        addSubview(contentView)
        addConstraints()
        //初始化属性配置
//        self.initialSetup()
    }

    internal override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    convenience init(frame: CGRect, sourceData: Data, numberOfColumn: Int) {
        self.init(frame: frame)
//        let data = try?  Data.init(contentsOf:URL.init(fileURLWithPath: Bundle.main.path(forResource: "city", ofType: "json")!) )
//        if data != nil {
//            let city = try! JSONSerialization.jsonObject(with: data!, options: .mutableContainers)
//            self.dataSource = JSON(city)
//            print(dataSource)
//        }
        
        self.dataSource = JSON(sourceData)
//        print(dataSource)
        self.numberOfColumn = numberOfColumn
        self.initialSetup()
    }
    
    func loadViewFromNib() -> UIView {
        let className = type(of: self)
        let bundle = Bundle(for: className)
        let name = NSStringFromClass(className).components(separatedBy: ".").last
        let nib = UINib(nibName: name!, bundle: bundle)
        let view = nib.instantiate(withOwner: self, options: nil).first as! UIView
        return view
    }
    
    //设置好xib视图约束
    func addConstraints() {
        contentView.translatesAutoresizingMaskIntoConstraints = false
        var constraint = NSLayoutConstraint(item: contentView, attribute: .leading,
                                            relatedBy: .equal, toItem: self, attribute: .leading,
                                            multiplier: 1, constant: 0)
        addConstraint(constraint)
        constraint = NSLayoutConstraint(item: contentView, attribute: .trailing,
                                        relatedBy: .equal, toItem: self, attribute: .trailing,
                                        multiplier: 1, constant: 0)
        addConstraint(constraint)
        constraint = NSLayoutConstraint(item: contentView, attribute: .top, relatedBy: .equal,
                                        toItem: self, attribute: .top, multiplier: 1, constant: 0)
        addConstraint(constraint)
        constraint = NSLayoutConstraint(item: contentView, attribute: .bottom,
                                        relatedBy: .equal, toItem: self, attribute: .bottom,
                                        multiplier: 1, constant: 0)
        addConstraint(constraint)
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        contentView = loadViewFromNib()
        addSubview(contentView)
        addConstraints()
    }
    func initialSetup(){
     
        
//        let data = try?  Data.init(contentsOf:URL.init(fileURLWithPath: Bundle.main.path(forResource: "city", ofType: "json")!) )
//        if data != nil {
//            self.dataSource = JSON(data!)
//        }
 
        self.pickerView.showsSelectionIndicator = true
        self.pickerView.delegate = self
        self.pickerView.dataSource = self
        
    }
    // returns the number of 'columns' to display.
    public func numberOfComponents(in pickerView: UIPickerView) -> Int{
        return numberOfColumn
    }
    
    
    // returns the # of rows in each component..
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        var count = 0
        switch component {
        case 0:
            let temp = dataSource[provinceSelect]["children"].count
            //切换同一 column 中的不同 row时 可能对应下级菜单rows 不同
            //切换上级菜单记录下级菜单 超出当前最大selected 值 [则选中最后一个](这个"选中操作"是系统自动执行的并没有触发代理, 因此需要在数据层和UI上一一对应)
            citySelect = citySelect > (temp - 1) ? (temp - 1) : citySelect
            count = dataSource.count
        case 1:
            let temp = dataSource[provinceSelect]["children"][citySelect]["children"].count
            districtSelect = districtSelect > (temp - 1) ? (temp - 1) : districtSelect
            count = dataSource[provinceSelect]["children"].count
        case 2:
            count = dataSource[provinceSelect]["children"][citySelect]["children"].count
        default:
            break
        }
        return count
    }
    public func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?{
        var title = ""
        switch component {
        case 0:
            title = dataSource[row]["name"].stringValue
        case 1:
            title = dataSource[provinceSelect]["children"][row]["name"].stringValue
        case 2:
            title = dataSource[provinceSelect]["children"][citySelect]["children"][row]["name"].stringValue
        default:
            break
        }
        return title
    }
    public func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int){
        switch component {
        case 0:
            provinceSelect = row
        case 1:
            citySelect = row
        case 2:
            districtSelect = row
        default:
            break
        }
        changedComponent = component
        pickerView .reloadAllComponents()
    }
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}

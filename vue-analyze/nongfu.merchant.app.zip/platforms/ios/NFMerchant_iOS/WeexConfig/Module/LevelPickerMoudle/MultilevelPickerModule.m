//
//  MultilevelPickerModule.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/3.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "MultilevelPickerModule.h"
#if DEVELOPMENT
#import "NFMerchant_iOSDev-Swift.h"
#else
#import "NFMerchant_iOS-Swift.h"
#endif
@implementation MultilevelPickerModule
WX_EXPORT_METHOD(@selector(pickData:callback:))
@synthesize weexInstance;

-(void)pickData:(NSDictionary *)options callback:(WXModuleKeepAliveCallback)callback {
    [_pickerContainer removeFromSuperview];
    NSData *cityJson = [NSJSONSerialization dataWithJSONObject:options[@"data"] options:NSJSONWritingPrettyPrinted error:nil] ;
    NSInteger level = 3;
    if (options) {
        level = [options[@"level"] integerValue];
    }
    PickAreaView *pickerView = [[PickAreaView alloc] initWithFrame:CGRectMake(0, UI_SCREEN_HEIGHT - 255 - UI_TabbarSafeBottomMargin, UI_SCREEN_WIDTH, 255) sourceData:cityJson numberOfColumn: level];
    __weak MultilevelPickerModule * weakSelf = self;
    pickerView.cancle = ^(){
        weakSelf.pickerContainer.alpha = 1.0;
        [UIView animateWithDuration:0.25 animations:^{
            weakSelf.pickerContainer.alpha = 0;
        }];
        callback(@{@"result": @"error", @"data": @{} }, NO);
    };
    [pickerView setSure:^(NSArray<NSDictionary<NSString *,NSString *> *> * _Nonnull result) {
        NSLog(@"%@", result);
        weakSelf.pickerContainer.alpha = 1.0;
        [UIView animateWithDuration:0.25 animations:^{
            weakSelf.pickerContainer.alpha = 0;
        }];
        if (result && result.count >= 1) {
            if (result.count == 3) {
                callback(@{@"result": @"success", @"data": @{@"id": @[result[0][@"id"] , result[1][@"id"], result[2][@"id"] ] , @"name": @[result[0][@"name"] , result[1][@"name"], result[2][@"name"] ]}}, NO);
            } else if (result.count == 2) {
                callback(@{@"result": @"success", @"data": @{@"id": @[result[0][@"id"] , result[1][@"id"] ] , @"name": @[result[0][@"name"] , result[1][@"name"] ]}}, NO);
            } else if (result.count == 1) {
                callback(@{@"result": @"success", @"data": @{@"id": @[result[0][@"id"]], @"name": @[result[0][@"name"]]}}, NO);
            }
            
        } else {
            callback(@{@"result": @"error", @"data": @{} }, NO);
        }
    }];
    //iphonex 下补全底部34pt
    UIView *supplementView = [[UIView alloc] initWithFrame:CGRectMake(0, UI_SCREEN_HEIGHT - UI_TabbarSafeBottomMargin, UI_SCREEN_WIDTH, UI_TabbarSafeBottomMargin)];
    supplementView.backgroundColor = [UIColor whiteColor];
    //灰色背景
    self.pickerContainer = [[UIView alloc] initWithFrame: UI_SCREEN_BOUNDS];
    _pickerContainer.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
    [_pickerContainer addSubview:pickerView];
    [_pickerContainer addSubview:supplementView];
    //手势
    
    //    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTap:)];
    //    [_pickerContainer addGestureRecognizer:tap];
    
    
    
    self.pickerContainer.alpha = 0;
    [[[[UIApplication sharedApplication] keyWindow] rootViewController].view addSubview:_pickerContainer];
    [UIView animateWithDuration:0.25 animations:^{
        self.pickerContainer.alpha = 1.0;
    }];
    
}
@end

//
//  PickerMoudle.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/3/5.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WeexSDK/WXModuleProtocol.h>
@interface PickerMoudle : NSObject<WXModuleProtocol>

@end

//
//  Navigator.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/19.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WeexSDK/WeexSDK.h>



@protocol NavigatorDataTransferDelegate

@property (nonatomic, copy) WXModuleKeepAliveCallback callback;
@property (nonatomic, strong) NSDictionary *wxData;

@end


@interface Navigator : NSObject<WXModuleProtocol>

@end

//
//  Navigator.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/19.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "Navigator.h"
#import "PrintControlViewController.h"
#import "BaseViewController.h"
#import "UINavigationController+FDFullscreenPopGesture.h"
@implementation Navigator

WX_EXPORT_METHOD(@selector(pushPrinterConnectionSettingController:))
WX_EXPORT_METHOD(@selector(show::))
-(void)pushPrinterConnectionSettingController:(WXModuleKeepAliveCallback)callback{

    PrintControlViewController *pvc = [[PrintControlViewController alloc] init];
    pvc.fd_prefersNavigationBarHidden = NO;
    [(UINavigationController *)[[[UIApplication sharedApplication] keyWindow] rootViewController] pushViewController:pvc animated:YES];
    callback(@{@"result": @"success"}, NO);
}

-(void)show:(NSDictionary *)options :(WXModuleKeepAliveCallback)callback{
    BaseViewController *vc = [[NSClassFromString(options[@"pageName"]) alloc] init];
    vc.wxData = options[@"data"];
//    vc.callback = callback;
    
    if ([options[@"mode"] isEqualToString:@"present"]) {
        [[(UINavigationController *)[[[UIApplication sharedApplication] keyWindow] rootViewController] topViewController] presentViewController:vc animated:YES completion:nil];
        callback(@{@"result": @"success"}, NO);
    } else if ([options[@"mode"] isEqualToString:@"push"]) {
        [(UINavigationController *)[[[UIApplication sharedApplication] keyWindow] rootViewController] pushViewController:vc animated:YES];
        callback(@{@"result": @"success"}, NO);
    }
    
}

@end

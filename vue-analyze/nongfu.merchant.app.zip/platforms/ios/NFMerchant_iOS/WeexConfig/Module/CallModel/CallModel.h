//
//  CallModel.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2017/8/28.
//  Copyright © 2017年 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WeexSDK/WeexSDK.h>
@interface CallModel : NSObject<WXModuleProtocol>


@end

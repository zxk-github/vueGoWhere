//
//  CallModel.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2017/8/28.
//  Copyright © 2017年 taobao. All rights reserved.
//

#import "CallModel.h"

@implementation CallModel
@synthesize weexInstance;
WX_EXPORT_METHOD(@selector(telephoneCall:))
WX_EXPORT_METHOD(@selector(clearCache:))
-(void)telephoneCall:(NSDictionary *)params{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel:%@",params[@"params"][@"telephoneNumber"]]]];
}
-(void)clearCache:(NSDictionary *)params {
//    NSHTTPCookie *cookie;
//    NSHTTPCookieStorage *storage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
//    for (cookie in [storage cookies]) {
//        [storage deleteCookie:cookie];
//    }
//    [[NSURLCache sharedURLCache] removeAllCachedResponses];
//    NSURLCache *cache = [NSURLCache sharedURLCache];
//    
//    [cache removeAllCachedResponses];
//    [cache setDiskCapacity:0];
//    [cache setMemoryCapacity:0];
    [weexInstance fireGlobalEvent:@"NongheNativeCallback" params:@{@"params":@"",@"status":@"success", @"execution":params[@"execution"],@"result":@"" }];

}

@end

//
//  LocationMoudle.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/3/29.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "LocationMoudle.h"
#import <CoreLocation/CoreLocation.h>
#import "SystemPermissionsManager.h"
#import "GlobalUtil.h"
#if DEVELOPMENT
#import "NFMerchant_iOSDev-Swift.h"
#else
#import "NFMerchant_iOS-Swift.h"
#endif

#import <AMapSearchKit/AMapSearchKit.h>
#import <AMapFoundationKit/AMapFoundationKit.h>
#import <MAMapKit/MAMapKit.h>


@interface LocationMoudle()<CLLocationManagerDelegate, AMapSearchDelegate>
@property(nonatomic,strong) CLLocationManager *locationManager;
@property(nonatomic, copy) WXModuleKeepAliveCallback locationCallBack;
@property(nonatomic, assign) NSInteger locationNum;
@property(nonatomic, strong) UIView *pickerContainer;
@property(nonatomic, strong) AMapSearchAPI *search;
@end

@implementation LocationMoudle
@synthesize weexInstance;
WX_EXPORT_METHOD(@selector(getLocation:))
WX_EXPORT_METHOD(@selector(getAreaCodeByRegion:callback:))
WX_EXPORT_METHOD(@selector(pickData:callback:))
WX_EXPORT_METHOD(@selector(getSearchArea:))
WX_EXPORT_METHOD(@selector(getGeoInfo:callback:))
-(instancetype)init{
    if (self = [super init]) {
        self.locationManager = [SystemPermissionsManager sharedManager].locationManager;
        self.locationManager.delegate = self;
    
    }
    return self;
}

-(void)getSearchArea:(WXModuleKeepAliveCallback)callback {
    if ([CLLocationManager authorizationStatus]  == kCLAuthorizationStatusNotDetermined) {
        //已经在 appdeleget中调起定位了
        //等待用户确认
        callback(@{@"result": @"pending", @"data": @{} }, NO);
        return;
    }
    
    [SystemPermissionsManager requestAuthorization:KCLLocationManager completionHandler:^(BOOL granted) {
        if (granted) {
            PickPointViewController *pickVC = [[PickPointViewController alloc] init];
            pickVC.didSubmitAddress = ^(AMapReGeocode * address, NSString *name, NSDictionary* currentCoordinate){
                if (address && ![currentCoordinate[@"latitude"] isEqualToString:@"0"]) {
                    callback(@{@"result": @"success", @"data": @{@"latitude":currentCoordinate[@"latitude"],
                                                                 @"longitude":currentCoordinate[@"longitude"],
                                                                 @"province": address.addressComponent.province,
                                                                 @"city": address.addressComponent.city,
                                                                 @"district": address.addressComponent.district,
                                                                 @"particulars": name ? name : @"",
                                                                 } }, NO);
                } else{
                     callback(@{@"result": @"error", @"data": @{} }, NO);
                }
            };
            [(UINavigationController *)[[[UIApplication sharedApplication] keyWindow] rootViewController] pushViewController:pickVC animated:YES];
            
        } else {
            callback(@{@"result": @"unauthorized", @"data": @{} }, NO);
            
        }
    }];
}

-(void)getGeoInfo:(NSDictionary *)options callback:(WXModuleKeepAliveCallback)callback {
    
    [SystemPermissionsManager requestAuthorization:KCLLocationManager completionHandler:^(BOOL granted) {
        if (granted) {
            [AMapServices sharedServices].apiKey = @"d6a8dc6c0adbba5c37cbf17cbeda5485";
            self.search = [[AMapSearchAPI alloc] init];
            self.search.delegate = self;
            AMapGeocodeSearchRequest *geo = [[AMapGeocodeSearchRequest alloc] init];
            geo.address = options[@"address"];
            [self.search AMapGeocodeSearch:geo];
            self.locationCallBack = callback;
            
        } else {
            callback(@{@"result": @"unauthorized", @"data": @{} }, NO);
            
        }
    }];
    
    
}
-(void)getLocation:(WXModuleKeepAliveCallback)callback {
    
    if ([CLLocationManager authorizationStatus]  == kCLAuthorizationStatusNotDetermined) {
        //已经在 appdeleget中调起定位了
        //等待用户确认
        callback(@{@"result": @"pending", @"data": @{} }, NO);
        return;
    }
    [SystemPermissionsManager requestAuthorization:KCLLocationManager completionHandler:^(BOOL granted) {
        if (granted) {
            _locationNum = 0;
            [_locationManager startUpdatingLocation];
            self.locationCallBack = callback;
        } else {
            callback(@{@"result": @"unauthorized", @"data": @{} }, NO);

        }
    }];
}
-(void)getAreaCodeByRegion:(NSDictionary *)options callback:(WXModuleKeepAliveCallback)callback {
    NSString *province = [options valueForKey:@"province"];
    NSString *city = [options valueForKey:@"city"];
    NSString *district = [options valueForKey:@"district"];
    NSDictionary<NSString *, NSString*> *result = [GlobalUtil findAreaByProvinceName:province cityName:city districtName:district];
    if ([result valueForKey:@"districtId"].length > 0 ) {
        callback(@{@"result": @"success", @"data": @{@"id": [result valueForKey:@"districtId"]} }, NO);
    } else {
        callback(@{@"result": @"notFound", @"data": @{} }, NO);
    }
    
    
}
-(void)pickData:(NSDictionary *)options callback:(WXModuleKeepAliveCallback)callback {
    [_pickerContainer removeFromSuperview];
    NSData *cityJson = options[@"data"];
    NSInteger level = 3;
    if (options) {
        level = [options[@"level"] integerValue];
    }
    PickAreaView *pickerView = [[PickAreaView alloc] initWithFrame:CGRectMake(0, UI_SCREEN_HEIGHT - 255 - UI_TabbarSafeBottomMargin, UI_SCREEN_WIDTH, 255) sourceData:cityJson numberOfColumn: level];
    __weak LocationMoudle * weakSelf = self;
    pickerView.cancle = ^(){
        weakSelf.pickerContainer.alpha = 1.0;
        [UIView animateWithDuration:0.25 animations:^{
            weakSelf.pickerContainer.alpha = 0;
        }];
        callback(@{@"result": @"error", @"data": @{} }, NO);
    };
    [pickerView setSure:^(NSArray<NSDictionary<NSString *,NSString *> *> * _Nonnull result) {
        NSLog(@"%@", result);
        weakSelf.pickerContainer.alpha = 1.0;
        [UIView animateWithDuration:0.25 animations:^{
            weakSelf.pickerContainer.alpha = 0;
        }];
        if (result && result.count >= 1) {
            if (result.count == 3) {
                callback(@{@"result": @"success", @"data": @{@"id": @[result[0][@"id"] , result[1][@"id"], result[2][@"id"] ] , @"name": @[result[0][@"name"] , result[1][@"name"], result[2][@"name"] ]}}, NO);
            } else if (result.count == 2) {
                callback(@{@"result": @"success", @"data": @{@"id": @[result[0][@"id"] , result[1][@"id"] ] , @"name": @[result[0][@"name"] , result[1][@"name"] ]}}, NO);
            }
            
        } else {
            callback(@{@"result": @"error", @"data": @{} }, NO);
        }
    }];
    //iphonex 下补全底部34pt
    UIView *supplementView = [[UIView alloc] initWithFrame:CGRectMake(0, UI_SCREEN_HEIGHT - UI_TabbarSafeBottomMargin, UI_SCREEN_WIDTH, UI_TabbarSafeBottomMargin)];
    supplementView.backgroundColor = [UIColor whiteColor];
    //灰色背景
    self.pickerContainer = [[UIView alloc] initWithFrame: UI_SCREEN_BOUNDS];
    _pickerContainer.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
    [_pickerContainer addSubview:pickerView];
    [_pickerContainer addSubview:supplementView];
    //手势
    
    //    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTap:)];
    //    [_pickerContainer addGestureRecognizer:tap];
    
    
    
    self.pickerContainer.alpha = 0;
    [[[[UIApplication sharedApplication] keyWindow] rootViewController].view addSubview:_pickerContainer];
    [UIView animateWithDuration:0.25 animations:^{
        self.pickerContainer.alpha = 1.0;
    }];
    
}

#pragma mark-  CLLocationManagerDelegate

//定位结果回调
- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(nonnull NSArray<CLLocation *> *)locations {
    NSLog(@"回调位置数组-->%@\n",locations);
    if ([locations lastObject]) {
        //指定位一次
        _locationNum += 1;
        if (_locationNum > 1) {
            return;
        }
        [manager stopUpdatingLocation];
        CLLocation *currentLocation = [locations lastObject];
        // 保存 Device 的现语言 (英语 法语 等)
        NSMutableArray *userDefaultLanguages = [[NSUserDefaults standardUserDefaults] objectForKey:@"AppleLanguages"];
        // 强行设置为中文
        [[NSUserDefaults standardUserDefaults] setObject:@[@"zh-hans"] forKey:@"AppleLanguages"];
        CLGeocoder *geoCoder = [[CLGeocoder alloc] init];
        [geoCoder reverseGeocodeLocation:currentLocation completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
            NSLog(@"反向地理编码 -> 结果:%@ \n\t错误:%@\n", placemarks, error);
            CLPlacemark *place = [placemarks firstObject];
            if (!place) {
                self.locationCallBack(@{@"result": @"error", @"data": @{} }, NO);
                return ;
            }
            NSString *province = [backStr(place.administrativeArea) length] == 0 ? backStr(place.locality) : backStr(place.administrativeArea);
            self.locationCallBack(@{@"result": @"success", @"data": @{@"latitude":[NSString stringWithFormat:@"%lf", currentLocation.coordinate.latitude], @"longitude": [NSString stringWithFormat:@"%lf", currentLocation.coordinate.longitude], @"country": backStr(place.country), @"province": province, @"city": backStr(place.locality), @"district": backStr(place.subLocality), @"street":backStr(place.thoroughfare), @"streetNum": backStr(place.subThoroughfare)} }, NO);
            
            NSLog(@"返回地理数据---%@", @{@"result": @"success", @"data": @{@"latitude":[NSString stringWithFormat:@"%lf", currentLocation.coordinate.latitude], @"longitude": [NSString stringWithFormat:@"%lf", currentLocation.coordinate.longitude], @"country": backStr(place.country), @"province": province, @"city": backStr(place.locality), @"district": backStr(place.subLocality), @"street":backStr(place.thoroughfare), @"streetNum": backStr(place.subThoroughfare)} });
        }];
        // 还原Device 的语言(延迟0.5秒，如果直接执行有很大概率依然是原设备语言)
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [[NSUserDefaults standardUserDefaults] setObject:userDefaultLanguages forKey:@"AppleLanguages"];
        });
    } else {
        self.locationCallBack(@{@"result": @"error", @"data": @{} }, NO);

    }
    
    
}
//定位失败回调
- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
    NSLog(@"定位失败错误信息:%@\n", error);
    self.locationCallBack(@{@"result": @"error", @"data": @{} }, NO);

}


/// 高德

- (void)onGeocodeSearchDone:(AMapGeocodeSearchRequest *)request response:(AMapGeocodeSearchResponse *)response
{
    if (!response.geocodes || response.geocodes.count == 0)
    {
        self.locationCallBack(@{@"result": @"error", @"data": @{} }, NO);

    } else {
        NSString *latitude = [NSString stringWithFormat:@"%lf", response.geocodes.firstObject.location.latitude];
        NSString *longitude = [NSString stringWithFormat:@"%lf", response.geocodes.firstObject.location.longitude];
        self.locationCallBack(@{@"result": @"success", @"data": @{@"latitude":latitude,@"longitude":longitude} }, NO);
    }
    
    //解析response获取地理信息，具体解析见 Demo
}
- (void)AMapSearchRequest:(id)request didFailWithError:(NSError *)error{
    //失败
    self.locationCallBack(@{@"result": @"error", @"data": @{} }, NO);
}
@end

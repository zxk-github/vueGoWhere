//
//  AppStorage.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/1/31.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "AppStorage.h"

#import <LBXScan/LBXScanViewController.h>

@implementation AppStorage

WX_EXPORT_METHOD(@selector(setItem:))
WX_EXPORT_METHOD(@selector(getItem:))
WX_EXPORT_METHOD(@selector(getAllKeys:))
WX_EXPORT_METHOD(@selector(removeItem:))
@synthesize weexInstance;

-(instancetype)init {
    if (self = [super init]) {
        if (![[NSUserDefaults standardUserDefaults] objectForKey:@"js_storage"]) {
            [[NSUserDefaults standardUserDefaults] setObject:@{}.mutableCopy forKey:@"js_storage"];
        }
    }
    return self;
}



-(void)setItem:(NSDictionary *)params {
    NSString *key = params[@"params"][@"key"];
    id obj = params[@"params"][@"value"];
    
    if (key && obj) {
        
        NSMutableDictionary *jsStorage = [[NSUserDefaults standardUserDefaults] objectForKey:key];
        [jsStorage setObject:obj forKey:key];
        [[NSUserDefaults standardUserDefaults] setObject:jsStorage forKey:@"js_storage"];
        
        [weexInstance fireGlobalEvent:@"NongheNativeCallback" params:@{@"status":@"success", @"execution":params[@"execution"],@"result":@"" }];
    } else {
        [weexInstance fireGlobalEvent:@"NongheNativeCallback" params:@{@"status":@"fail", @"execution":params[@"execution"],@"result":@"" }];
    }
    
    
}

-(void)getItem:(NSDictionary *)params {
    NSString *key = params[@"params"][@"key"];
    
    if (key) {
        NSMutableDictionary *jsStorage = [[NSUserDefaults standardUserDefaults] objectForKey:@"js_storage"];
        
        id value = [jsStorage objectForKey:key];
        if (value) {
            [weexInstance fireGlobalEvent:@"NongheNativeCallback" params:@{@"status":@"success", @"execution":params[@"execution"],@"result":@{@"res":@{@"key":key, @"value": value}} }];
        } else {
            [weexInstance fireGlobalEvent:@"NongheNativeCallback" params:@{@"status":@"fail", @"execution":params[@"execution"],@"result":@"" }];
        }
        
        
    } else {
        [weexInstance fireGlobalEvent:@"NongheNativeCallback" params:@{@"status":@"fail", @"execution":params[@"execution"],@"result":@"" }];
    }
    
    
    
    
}

-(void)getAllKeys:(NSDictionary *)params {
    NSMutableDictionary *jsStorage = [[NSUserDefaults standardUserDefaults] objectForKey:@"js_storage"];
    [weexInstance fireGlobalEvent:@"NongheNativeCallback" params:@{@"status":@"success", @"execution":params[@"execution"],@"result":@{@"res":[jsStorage allKeys]} }];
    
}

-(void)removeItem:(NSDictionary *)params {
    NSString *key = params[@"params"][@"key"];
    
    if (key) {
        NSMutableDictionary *jsStorage = [[NSUserDefaults standardUserDefaults] objectForKey:@"js_storage"];
        [jsStorage removeObjectForKey:key];
        [[NSUserDefaults standardUserDefaults] setObject:jsStorage forKey:key];
        
        [weexInstance fireGlobalEvent:@"NongheNativeCallback" params:@{@"status":@"success", @"execution":params[@"execution"],@"result":@"" }];
        
    } else {
        [weexInstance fireGlobalEvent:@"NongheNativeCallback" params:@{@"status":@"fail", @"execution":params[@"execution"],@"result":@"" }];
    }
}


@end

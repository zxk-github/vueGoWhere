/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#import "StorageModule.h"
#import "HFThreadSafeMutableDictionary.h"
#import "HFThreadSafeMutableArray.h"
#import <CommonCrypto/CommonCrypto.h>


static NSString * const StorageDirectory            = @"wxstorage"; //Storage的目录名字
static NSString * const StorageFileName             = @"wxstorage.plist";// Storage的文件名
static NSString * const StorageInfoFileName         = @"wxstorage.info.plist";// Storage的信息(Storage 中存item 时间戳, 大小等)文件名
static NSString * const StorageIndexFileName        = @"wxstorage.index.plist";// Storage 的索引(item的key值)文件名
static NSUInteger const StorageLineLimit            = 1024; // 每个字段存储的最大值 1024 Bit
static NSUInteger const StorageTotalLimit           = 5 * 1024 * 1024; //  Storage 的总大小 5MB
static NSString * const StorageThreadName           = @"com.taobao.weex.storage"; //storage的线程名
static NSString * const StorageNullValue            = @"#{eulaVlluNegarotSXW}"; //标识 obj 大于 StorageLineLimit 时 存储此标识 真实 的obj所对应的文件名为 key 的 MD5

@implementation StorageModule

@synthesize weexInstance;

WX_EXPORT_METHOD(@selector(length:)) //storage中item个数
WX_EXPORT_METHOD(@selector(getItem:callback:))//读取storage中的item
WX_EXPORT_METHOD(@selector(setItem:value:callback:))//设置item
WX_EXPORT_METHOD(@selector(setItemPersistent:value:callback:))//设置item 同时指定是否持久化
WX_EXPORT_METHOD(@selector(getAllKeys:))//获取storage中所有item的key值
WX_EXPORT_METHOD(@selector(removeItem:callback:))//移除item

#pragma mark - Export

- (dispatch_queue_t)targetExecuteQueue {
    return [StorageModule storageQueue];
}

- (void)length:(WXModuleCallback)callback
{
    if (callback) {
        callback(@{@"result":@"success",@"data":@([[StorageModule memory] count])});
    }
}

- (void)getAllKeys:(WXModuleCallback)callback
{
    if (callback) {
        callback(@{@"result":@"success",@"data":[StorageModule memory].allKeys});
    }
}

- (void)getItem:(NSString *)key callback:(WXModuleCallback)callback
{
    if ([self checkInput:key]) {//除数值和字符串类型外
        if (callback) {
            callback(@{@"result":@"failed",@"data":@"key must a string or number!"}); // forgive my english
        }
        return;
    }
    
    if ([key isKindOfClass:[NSNumber class]]) {//key是数字类型
        key = [((NSNumber *)key) stringValue]; // oh no!
    }
    
    if ([WXUtility isBlankString:key]) {//字符串为空
        if (callback) {
            callback(@{@"result":@"failed",@"data":@"invalid_param"});
        }
        return ;
    }
    
    NSString *value = [self.memory objectForKey:key]; //读取storage文件中的内容
    if ([StorageNullValue isEqualToString:value]) { //如果 storage文件中所对应的值为 StorageNullValue
        value = [[WXUtility globalCache] objectForKey:key];// 从内存中取值
        if (!value) {// 如果内存里没有
            NSString *filePath = [StorageModule filePathForKey:key]; //storage value所对应的文件(命名为 key 的MD5值)
            NSString *contents = [WXUtility stringWithContentsOfFile:filePath]; //读取文件中的值
            if (contents) {//有值
                [[WXUtility globalCache] setObject:contents forKey:key cost:contents.length];//保存至内存
                value = contents;
            }
        }
    }
    if (!value) {// 如果没有值
        [self executeRemoveItem:key]; //移除与key有关的信息
        if (callback) {
            callback(@{@"result":@"failed",@"data":@"undefined"});
        }
        return;
    }
    //不知道 为什么取的操作里还要更新这两个
    [self updateTimestampForKey:key];//更新时间戳
    [self updateIndexForKey:key];//更新索引
    if (callback) {
        callback(@{@"result":@"success",@"data":value});
    }
}

- (void)setItem:(NSString *)key value:(NSString *)value callback:(WXModuleCallback)callback
{
    if ([self checkInput:key]) {
        if (callback) {
            callback(@{@"result":@"failed",@"data":@"key must a string or number!"});
        }
        return;
    }
    if ([self checkInput:value]) {
        if (callback) {
            callback(@{@"result":@"failed",@"data":@"value must a string or number!"});
        }
        return;
    }
    
    if ([key isKindOfClass:[NSNumber class]]) {
        key = [((NSNumber *)key) stringValue];
    }
    
    if ([value isKindOfClass:[NSNumber class]]) {
        value = [((NSNumber *)value) stringValue];
    }
    
    if ([WXUtility isBlankString:key]) {
        if (callback) {
            callback(@{@"result":@"failed",@"data":@"invalid_param"});
        }
        return ;
    }
    [self setObject:value forKey:key persistent:NO callback:callback];
}

- (void)setItemPersistent:(NSString *)key value:(NSString *)value callback:(WXModuleCallback)callback
{
    if ([self checkInput:key]) {
        if (callback) {
            callback(@{@"result":@"failed",@"data":@"key must a string or number!"});
        }
        return;
    }
    if ([self checkInput:value]) {
        if (callback) {
            callback(@{@"result":@"failed",@"data":@"value must a string or number!"});
        }
        return;
    }
    
    if ([key isKindOfClass:[NSNumber class]]) {
        key = [((NSNumber *)key) stringValue];
    }
    
    if ([value isKindOfClass:[NSNumber class]]) {
        value = [((NSNumber *)value) stringValue];
    }
    
    if ([WXUtility isBlankString:key]) {
        if (callback) {
            callback(@{@"result":@"failed",@"data":@"invalid_param"});
        }
        return ;
    }
    [self setObject:value forKey:key persistent:YES callback:callback];
}

- (void)removeItem:(NSString *)key callback:(WXModuleCallback)callback
{
    if ([self checkInput:key]) {
        if (callback) {
            callback(@{@"result":@"failed",@"data":@"key must a string or number!"});
        }
        return;
    }
    
    if ([key isKindOfClass:[NSNumber class]]) {
        key = [((NSNumber *)key) stringValue];
    }
    
    if ([WXUtility isBlankString:key]) {
        if (callback) {
            callback(@{@"result":@"failed",@"data":@"invalid_param"});
        }
        return ;
    }
    BOOL removed = [self executeRemoveItem:key];
    if (removed) {
        if (callback) {
            callback(@{@"result":@"success"});
        }
    } else {
        if (callback) {
            callback(@{@"result":@"failed"});
        }
    }
}

- (BOOL)executeRemoveItem:(NSString *)key {
    if ([StorageNullValue isEqualToString:self.memory[key]]) {// 如果storage中key 的obj 为 StorageNullValue
        [self.memory removeObjectForKey:key]; //删掉key
        NSDictionary *dict = [self.memory copy];
        [self write:dict toFilePath:[StorageModule filePath]];//覆盖新的storage
        dispatch_async([StorageModule storageQueue], ^{ //异步执行
            NSString *filePath = [StorageModule filePathForKey:key];
            [[NSFileManager defaultManager] removeItemAtPath:filePath error:nil];//删除MD5文件
            [[WXUtility globalCache] removeObjectForKey:key];//删除内存中的数据
        });
    } else if (self.memory[key]) {// 如果storage中key 的obj 为 StorageNullValue 以外的值
        [self.memory removeObjectForKey:key]; //删掉key
        NSDictionary *dict = [self.memory copy];
        [self write:dict toFilePath:[StorageModule filePath]];//覆盖storage
    } else {
        return NO;
    }
    [self removeInfoForKey:key];//删掉 info
    [self removeIndexForKey:key];// 删掉 索引
    return YES;
}

#pragma mark - Utils
- (void)setObject:(NSString *)obj forKey:(NSString *)key persistent:(BOOL)persistent callback:(WXModuleCallback)callback {
    NSString *filePath = [StorageModule filePathForKey:key]; //storage key 对应的obj 文件(MD5名)地址
    if (obj.length <= StorageLineLimit) {// 如果string 的长度小于 1024字节 (1KB) 正常赋值
        if ([StorageNullValue isEqualToString:self.memory[key]]) {// 如果storage中原有对应的key的obj 为 StorageNullValue
            [[WXUtility globalCache] removeObjectForKey:key]; // 从内存中移除key对应的 obj
            [[NSFileManager defaultManager] removeItemAtPath:filePath error:nil]; //删除storage key 对应的obj 文件(MD5名) 文件
        }
        self.memory[key] = obj; // 将storage其对应的key 赋值
        NSDictionary *dict = [self.memory copy];
        [self write:dict toFilePath:[StorageModule filePath]]; //覆盖原有的 storage
        [self setInfo:@{@"persistent":@(persistent),@"size":@(obj.length)} ForKey:key];// 设置其key - item 对应的信息
        [self updateIndexForKey:key];//更新索引
        [self checkStorageLimit];//检查storage的大小 大于5MB的话就清理非持久化的数据
        if (callback) {
            callback(@{@"result":@"success"});
        }
        return;
    }
    
    [[WXUtility globalCache] setObject:obj forKey:key cost:obj.length];//存至内存
    
    if (![StorageNullValue isEqualToString:self.memory[key]]) { //obj大于 1kb 且 storage key 对应的obj 不为 StorageNullValue
        self.memory[key] = StorageNullValue; // 将obj 赋值为 StorageNullValue
        NSDictionary *dict = [self.memory copy];
        [self write:dict toFilePath:[StorageModule filePath]]; //覆盖storage
    }
    
    dispatch_async([StorageModule storageQueue], ^{
        [obj writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:NULL]; //异步将obj 存为单独文件 文件名为 key 的MD5
    });
    
    [self setInfo:@{@"persistent":@(persistent),@"size":@(obj.length)} ForKey:key]; //更新info
    [self updateIndexForKey:key]; //更新索引
    
    [self checkStorageLimit]; //检查storage的大小 大于5MB的话就清理非持久化的数据
    if (callback) {
        callback(@{@"result":@"success"});
    }
}

- (void)checkStorageLimit {
    //如果storage中数据的总的大小 超过 5MB限制
    NSInteger size = [self totalSize] - StorageTotalLimit;
    if (size > 0) {
        //删除非 持久化的数据
        [self removeItemsBySize:size];
    }
}

- (void)removeItemsBySize:(NSInteger)size {
    NSArray *indexs = [[self indexs] copy];
    if (size < 0 || indexs.count == 0) {
        return;
    }
    //将非持久化的key找出
    NSMutableArray *removedKeys = [NSMutableArray array];
    for (NSInteger i = 0; i < indexs.count; i++) {
        NSString *key = indexs[i];
        NSDictionary *info = [self getInfoForKey:key];
        
        // persistent data, can't be removed
        if ([info[@"persistent"] boolValue]) {
            continue;
        }
        
        [removedKeys addObject:key];
        size -= [info[@"size"] integerValue];
        
        if (size < 0) {
            break;
        }
    }
    //删除非持久化的数据
    // actually remove data
    for (NSString *key in removedKeys) {
        [self executeRemoveItem:key];
    }
}

- (void)write:(NSDictionary *)dict toFilePath:(NSString *)filePath{
    [dict writeToFile:filePath atomically:YES];
}

+ (NSString *)filePathForKey:(NSString *)key
{
    NSString *safeFileName = [WXUtility md5:key];
    
    return [[StorageModule directory] stringByAppendingPathComponent:safeFileName];
}
//创建目录结构
+ (void)setupDirectory{
    BOOL isDirectory = NO;
    BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:[StorageModule directory] isDirectory:&isDirectory];
    if (!isDirectory && !fileExists) {
        [[NSFileManager defaultManager] createDirectoryAtPath:[StorageModule directory]
                                  withIntermediateDirectories:YES
                                                   attributes:nil
                                                        error:NULL];
    }
}
//storage的所在目录
+ (NSString *)directory {
    static NSString *storageDirectory = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        storageDirectory = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
        storageDirectory = [storageDirectory stringByAppendingPathComponent:StorageDirectory];
    });
    return storageDirectory;
}
//storage 内容的文件地址
+ (NSString *)filePath {
    static NSString *storageFilePath = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        storageFilePath = [[StorageModule directory] stringByAppendingPathComponent:StorageFileName];
    });
    return storageFilePath;
}
//storage 信息的文件地址
+ (NSString *)infoFilePath {
    static NSString *infoFilePath = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        infoFilePath = [[StorageModule directory] stringByAppendingPathComponent:StorageInfoFileName];
    });
    return infoFilePath;
}
//storage 索引的文件地址
+ (NSString *)indexFilePath {
    static NSString *indexFilePath = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        indexFilePath = [[StorageModule directory] stringByAppendingPathComponent:StorageIndexFileName];
    });
    return indexFilePath;
}
//创建storage线程
+ (dispatch_queue_t)storageQueue {
    static dispatch_queue_t storageQueue;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        storageQueue = dispatch_queue_create("com.taobao.weex.storage", DISPATCH_QUEUE_SERIAL);
    });
    return storageQueue;
}
//读取 storage 存储文件
+ (HFThreadSafeMutableDictionary<NSString *, NSString *> *)memory {
    static HFThreadSafeMutableDictionary<NSString *,NSString *> *memory;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [StorageModule setupDirectory];
        
        if ([[NSFileManager defaultManager] fileExistsAtPath:[StorageModule filePath]]) {
            NSDictionary *contents = [NSDictionary dictionaryWithContentsOfFile:[StorageModule filePath]];
            if (contents) {
                memory = [[HFThreadSafeMutableDictionary alloc] initWithDictionary:contents];
            }
        }
        if (!memory) {
            memory = [HFThreadSafeMutableDictionary new];
        }
//        [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidReceiveMemoryWarningNotification object:nil queue:nil usingBlock:^(__unused NSNotification *note) {
//            [memory removeAllObjects];
//        }];
    });
    return memory;
}

+ (HFThreadSafeMutableDictionary<NSString *, NSDictionary *> *)info {
    static HFThreadSafeMutableDictionary<NSString *,NSDictionary *> *info;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [StorageModule setupDirectory];
        
        if ([[NSFileManager defaultManager] fileExistsAtPath:[StorageModule infoFilePath]]) {
            NSDictionary *contents = [NSDictionary dictionaryWithContentsOfFile:[StorageModule infoFilePath]];
            if (contents) {
                info = [[HFThreadSafeMutableDictionary alloc] initWithDictionary:contents];
            }
        }
        if (!info) {
            info = [HFThreadSafeMutableDictionary new];
        }
    });
    return info;
}

+ (HFThreadSafeMutableArray *)indexs {
    static HFThreadSafeMutableArray *indexs;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [StorageModule setupDirectory];
        
        if ([[NSFileManager defaultManager] fileExistsAtPath:[StorageModule indexFilePath]]) {
            NSArray *contents = [NSArray arrayWithContentsOfFile:[StorageModule indexFilePath]];
            if (contents) {
                indexs = [[HFThreadSafeMutableArray alloc] initWithArray:contents];
            }
        }
        if (!indexs) {
            indexs = [HFThreadSafeMutableArray new];
        }
    });
    return indexs;
}
//读取 storage 存储文件
- (HFThreadSafeMutableDictionary<NSString *, NSString *> *)memory {
    return [StorageModule memory];
}
//读取 storage 信息存储文件
- (HFThreadSafeMutableDictionary<NSString *, NSDictionary *> *)info {
    return [StorageModule info];
}
//读取 storage 索引存储文件
- (HFThreadSafeMutableArray *)indexs {
    return [StorageModule indexs];
}

- (BOOL)checkInput:(id)input{
    return !([input isKindOfClass:[NSString class]] || [input isKindOfClass:[NSNumber class]]);
}

#pragma mark
#pragma mark - Storage Info method
- (NSDictionary *)getInfoForKey:(NSString *)key {
    NSDictionary *info = [[self info] objectForKey:key];
    if (!info) {
        return nil;
    }
    return info;
}

- (void)setInfo:(NSDictionary *)info ForKey:(NSString *)key {
    NSAssert(info, @"info must not be nil");
    
    // save info for key
    NSMutableDictionary *newInfo = [NSMutableDictionary dictionaryWithDictionary:info];
    NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
    [newInfo setObject:@(interval) forKey:@"ts"];
    
    [[self info] setObject:[newInfo copy] forKey:key];
    NSDictionary *dict = [[self info] copy];
    [self write:dict toFilePath:[StorageModule infoFilePath]];
}

- (void)removeInfoForKey:(NSString *)key {
    [[self info] removeObjectForKey:key];
    NSDictionary *dict = [[self info] copy];
    [self write:dict toFilePath:[StorageModule infoFilePath]];
}

- (void)updateTimestampForKey:(NSString *)key {
    NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
    NSDictionary *info = [[self info] objectForKey:key];
    if (!info) {
        info = @{@"persistent":@(NO),@"size":@(0),@"ts":@(interval)};
    } else {
        NSMutableDictionary *newInfo = [NSMutableDictionary dictionaryWithDictionary:info];
        [newInfo setObject:@(interval) forKey:@"ts"];
        info = [newInfo copy];
    }
    
    [[self info] setObject:info forKey:key];
    NSDictionary *dict = [[self info] copy];
    [self write:dict toFilePath:[StorageModule infoFilePath]];
}
//所有保存的item所占用的空间大小
- (NSInteger)totalSize {
    NSInteger totalSize = 0;
    for (NSDictionary *info in [self info].allValues) {
        totalSize += (info[@"size"] ? [info[@"size"] integerValue] : 0);
    }
    return totalSize;
}

#pragma mark
#pragma mark - Storage Index method
- (void)updateIndexForKey:(NSString *)key {
    [[self indexs] removeObject:key];
    [[self indexs] addObject:key];
    [self write:[[self indexs] copy] toFilePath:[StorageModule indexFilePath]];
}

- (void)removeIndexForKey:(NSString *)key {
    [[self indexs] removeObject:key];
    [self write:[[self indexs] copy] toFilePath:[StorageModule indexFilePath]];
}

@end
#pragma clang diagnostic pop

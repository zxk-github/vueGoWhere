//
//  ScanIDCardViewController.swift
//  NongheMobileApp
//
//  Created by 胡鹏飞 on 2017/7/31.
//
//

import UIKit

enum CardOrientation : Int {
    case front
    case back
    case none
}
class ScanIDCardViewController: BaseViewController, WBCaptureServiceDelegate {
    var captureService = WBCaptureService()
    var photoSence = CardOrientation.front
    var landscape = false
    @objc var uploadUrl = ""
    @objc var userToken: String?
    
    
    @IBOutlet weak var discLabel: UILabel!
    @IBOutlet weak var tipLabel: UILabel!
    @IBOutlet weak var cardImageView: UIImageView!
    @objc var didDiscerned: ((Dictionary<String, Any>) -> Void)!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "身份证识别"
        self.view.isUserInteractionEnabled = false
        
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        SystemPermissionsManager.requestAuthorization(.KAVMediaTypeVideo) { (granted) in
            if granted{
                self.configCaptureService()
                self.changeSence(self.photoSence)
                self.showPreview()
            }
        }
    }
    /*
 {"images":[{"front":{"original":{"url":"pool/protected/images/unknown/yvZlnbyNy353uwPX7_BIQkRpH2ddGQfU.png","mimetype":"image/png","fieldname":"uploadfile","originalname":"001.png"}}}],"cardInfo":{"errorcode":-1308,"errormsg":"ERROR_DOWNLOAD_IMAGE_FAILED","name_confidence_all":[],"sex_confidence_all":[],"nation_confidence_all":[],"birth_confidence_all":[],"address_confidence_all":[],"id_confidence_all":[],"watermask_confidence_all":[],"valid_date_confidence_all":[],"authority_confidence_all":[],"detail_errorcode":[],"detail_errormsg":[]}}
 */
    
    @IBAction func takePic(_ sender: UIButton) {
        self.captureService.takeOneShotPicture({ (result, image) in

            if result == 0 && image != nil{

                var imageType = "front"
                if self.photoSence == .back {
                    imageType = "back"
                }
                
                GlobalUtil.showHud(for: self.view, message: "正在识别")
                self.captureService.stopRunning();
                
                NHNetWorkEngine.postFormDataRequest(self.uploadUrl, configHeaderDic: ["x-nonghe-category":"identity", "Authorization": self.userToken!], parameters: ["uploadfile_type":imageType], formData: [["file": ["input":"uploadfile","name":"001.png","data":UIImagePNGRepresentation(image!)!,"type":"image/png"]]], success: { (task, obj) in
                    
                    GlobalUtil.hudDismiss(for: self.view)
                    self.didDiscerned(obj as! Dictionary<String, Any>)
                    self.navigationController?.popViewController(animated: true)
                    
//                    self.captureService.previewLayer.removeFromSuperlayer()
//                    self.captureService.startRunning()
//                    self.showPreview()
                }, failure: { (task, error) in
                    GlobalUtil.hudDismiss(for: self.view)
                    self.didDiscerned(["state": "fail"])
                    self.navigationController?.popViewController(animated: true)
//                    self.captureService.previewLayer.removeFromSuperlayer()
//                    self.captureService.startRunning()
//                    self.showPreview()
                })
                
                
                
                
                
                
                
                
                
            }
        }, landscape: self.landscape)
        
        
    }
    @IBAction func cancle(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    func configCaptureService() {
        
//        captureService = WBCaptureService()
        self.captureService.setDelegate(self, callbackQueue: DispatchQueue.main)
//        self.captureService.renderingEnabled = true;
        self.captureService.shouldSaveToAlbum = false;
        self.captureService.shouldRecordAudio = false;
        self.captureService.preferedDevicePosition = .back;
        self.captureService.captureType = .image;
        self.captureService.startRunning()
        
       
        
    }
    func showPreview(){
        self.view.isUserInteractionEnabled = true
        self.captureService.previewLayer.frame = UIScreen.main.bounds
        self.view.layer.insertSublayer(self.captureService.previewLayer!, at: 0)
    }
    func changeSence(_ type: CardOrientation) {
        switch type {
        case .front:
            photoSence = .front
            self.cardImageView.image = #imageLiteral(resourceName: "img_idcard")
            self.tipLabel.text = "请拍摄身份证人像面"
        case .back:
            photoSence = .back
            self.cardImageView.image =  #imageLiteral(resourceName: "img_idcard1")
            self.tipLabel.text = "请拍摄身份证国徽面"
        case .none:
            photoSence = .none
            self.cardImageView.image =  #imageLiteral(resourceName: "img_nonedash")
            self.tipLabel.text = "请拍摄营业执照"
            self.discLabel.text = "请将营业执照置于虚线框内,确保文字清晰"
        }
    }
    override func viewDidLayoutSubviews() {

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

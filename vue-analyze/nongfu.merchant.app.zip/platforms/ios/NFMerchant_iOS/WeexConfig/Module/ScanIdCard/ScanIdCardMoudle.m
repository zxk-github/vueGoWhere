//
//  ScanIdCardMoudle.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/2/6.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "ScanIdCardMoudle.h"
#if DEVELOPMENT
#import "NFMerchant_iOSDev-Swift.h"
#else
#import "NFMerchant_iOS-Swift.h"
#endif
#import "SystemPermissionsManager.h"


@implementation ScanIdCardMoudle
WX_EXPORT_METHOD(@selector(takePictures:))
@synthesize weexInstance;

-(void)takePictures:(NSDictionary *)params {
    ScanIDCardViewController *scanVC = [[ScanIDCardViewController alloc] init];
    scanVC.userToken = params[@"params"][@"authorization"];

    scanVC.uploadUrl = [NSString stringWithFormat:@"http://%@/api/v1.0/multiparts/uploadIDCard/upload",params[@"params"][@"repoDomain"]];
    scanVC.fd_prefersNavigationBarHidden = YES;

    scanVC.didDiscerned = ^(NSDictionary<NSString *,id> * _Nonnull info) {
        if (![[info valueForKey:@"state"] isEqualToString:@"fail"] && info) {
            [weexInstance fireGlobalEvent:@"NongheNativeCallback" params:@{@"params":@"",@"status":@"success", @"execution":params[@"execution"],@"result":@{@"res":info} }];
        } else {
            [weexInstance fireGlobalEvent:@"NongheNativeCallback" params:@{@"params":@"",@"status":@"fail", @"execution":params[@"execution"],@"result":@{@"res":@""} }];
        }
    };
    [SystemPermissionsManager requestAuthorization:KAVMediaTypeVideo completionHandler:^(BOOL granted) {
        if (granted) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [(UINavigationController *)[[[UIApplication sharedApplication] keyWindow] rootViewController] pushViewController:scanVC animated:YES];
            });
        } else {
            [weexInstance fireGlobalEvent:@"NongheNativeCallback" params:@{@"status":@"unauthorized", @"execution":params[@"execution"],@"result":@"" }];
        }
    }];
    

    
}


@end

//
//  ContactCell.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/2.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "ContactCell.h"

@implementation ContactCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
-(void)setPerson:(Person *)person {
    self.nameLabel.text = person.name;
    self.telLabel.text = person.telNumber;
    if (person.selected.integerValue == 1) {
        _stateImageView.image = [UIImage imageNamed:@"contact_selected"];
    } else {
        _stateImageView.image = [UIImage imageNamed:@"contact_select_rest"];
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

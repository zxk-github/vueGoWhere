//
//  ContactPickerContactViewController.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/2.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "ContactPickerContactViewController.h"
#import <Contacts/Contacts.h>
#import "ContactCell.h"
#import "GlobalUtil.h"
#import "NSString+WT.h"
#import "Person.h"
#import "UIViewController+WXDemoNaviBar.h"
@interface ContactPickerContactViewController () <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UIView *topView;
@property (weak, nonatomic) IBOutlet UITextField *searchTextField;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIButton *bottomBtn;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *tableViewBottom;
@property (strong, nonatomic) NSMutableArray<Person *> *contacts;
@property (strong, nonatomic) NSMutableArray<Person *> *flitedContacts;
@property (strong, nonatomic) NSMutableArray<Person *> *selectedContacts;
@property (strong, nonatomic) CNContactStore *contactStore;
@property (nonatomic, strong) dispatch_queue_t contactQueue;
@property (assign, nonatomic) BOOL isSearchMode;
@end

@implementation ContactPickerContactViewController

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    if (_selectMode == SelectModeSingle) {
        self.title = @"通讯录导入";
    } else{
        self.title = @"批量导入";
    }
    [_bottomBtn setBackgroundColor:[UIColor lightGrayColor]];
    
    self.isSearchMode = NO;
    self.contactQueue = dispatch_queue_create("com.merchant.contact", DISPATCH_QUEUE_SERIAL);
    self.contacts = @[].mutableCopy;
    self.selectedContacts = @[].mutableCopy;
    self.flitedContacts = @[].mutableCopy;
    self.contactStore = [[CNContactStore alloc] init];
    
    
    
//    [CNContactFormatter descriptorForRequiredKeysForStyle:CNContactFormatterStyleFullName]
    dispatch_async(_contactQueue, ^{
        CNContactFetchRequest *fetchRequest = [[CNContactFetchRequest alloc] initWithKeysToFetch:@[[CNContactFormatter descriptorForRequiredKeysForStyle:CNContactFormatterStyleFullName],CNContactPhoneNumbersKey]];
        NSError *error = nil;
        __weak ContactPickerContactViewController *weakSelf = self;
        [_contactStore enumerateContactsWithFetchRequest:fetchRequest error:&error usingBlock:^(CNContact * _Nonnull contact, BOOL * _Nonnull stop1) {
            Person *person = [[Person alloc] init];
            if(contact.phoneNumbers.count > 0){//第一个有值
                [contact.phoneNumbers enumerateObjectsUsingBlock:^(CNLabeledValue<CNPhoneNumber *> * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop2) {
                    NSString *tel = [weakSelf processTelNumber: [[obj value] stringValue]];
                    if ([tel checkPhoneNumInput]) {
                        person.name = [CNContactFormatter stringFromContact:contact style:CNContactFormatterStyleFullName];
                        person.telNumber = tel;
                        person.selected = @"0";
                        person.namePinyin = person.name.getPinyin;
                        [weakSelf.contacts addObject:person];
                        *stop2 = YES;
                    }
                }];
            }
        }];
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf.tableView reloadData];
        });
    
    });
    
    [_tableView registerNib:[UINib nibWithNibName:@"ContactCell" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:@"ContactCell"];
    
    
    _searchTextField.delegate = self;
    _searchTextField.clearButtonMode = UITextFieldViewModeAlways;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textDidChange:) name:UITextFieldTextDidChangeNotification object:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)dealloc{
    NSLog(@"页面销毁");
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UITextFieldTextDidChangeNotification object:nil];
}
-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    if (self.cancleBlock) {
        self.cancleBlock();
    }
}
- (IBAction)beginImport:(id)sender {
    if (self.resultCallBack) {
        self.resultCallBack(_selectedContacts);
        [self.navigationController popViewControllerAnimated:YES];
    }
}

#pragma mark - UITableViewDelegate
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    if (_searchTextField.isFirstResponder) {
        [_searchTextField resignFirstResponder];
    }
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (_isSearchMode) {
        return _flitedContacts.count;
    }
    
    return self.contacts.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ContactCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ContactCell" forIndexPath:indexPath];
    if (_isSearchMode) {
        [cell setPerson:_flitedContacts[indexPath.row]];
    } else {
        [cell setPerson:_contacts[indexPath.row]];
    }
    
    
    return cell;
}
/*
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (_isSearchMode || _selectMode == SelectModeSingle) {
        return 0;
    }
    return 30;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    if (_isSearchMode || _selectMode == SelectModeSingle) {
        return nil;
    }
    UITableViewHeaderFooterView *header = [tableView dequeueReusableHeaderFooterViewWithIdentifier:@"header"];
    if (!header) {
        header = [[UITableViewHeaderFooterView alloc] initWithReuseIdentifier:@"header"];
        header.contentView.translatesAutoresizingMaskIntoConstraints = NO;
        
        
        
        UILabel *label = [[UILabel alloc] init];
        label.translatesAutoresizingMaskIntoConstraints = NO;
        [header.contentView addSubview:label];
        label.text = @"全选";
        NSLayoutConstraint *left = [label.leftAnchor constraintEqualToAnchor:header.leftAnchor constant:10];
        NSLayoutConstraint *top =  [label.topAnchor constraintEqualToAnchor:header.topAnchor];
        NSLayoutConstraint *height =  [label.heightAnchor constraintEqualToConstant:30];
        [header addConstraints:@[left, top, height]];
        
        
        UIButton *selectBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        selectBtn.translatesAutoresizingMaskIntoConstraints = NO;
        [selectBtn setImage:[UIImage imageNamed:@"contact_select_rest"] forState:UIControlStateNormal];
        [selectBtn setImage:[UIImage imageNamed:@"contact_selected"] forState:UIControlStateSelected];
        [selectBtn addTarget:self action:@selector(handleSelectAll:) forControlEvents:UIControlEventTouchUpInside];
        [header.contentView addSubview:selectBtn];
        
        NSLayoutConstraint *right = [selectBtn.rightAnchor constraintEqualToAnchor:header.rightAnchor constant:-10];
        NSLayoutConstraint *widthBtn =  [selectBtn.widthAnchor constraintEqualToConstant:20];
        NSLayoutConstraint *heightBtn =  [selectBtn.heightAnchor constraintEqualToConstant:20];
        NSLayoutConstraint *topBtn = [selectBtn.topAnchor constraintEqualToAnchor:header.topAnchor constant:5];
        [header addConstraints:@[right, widthBtn, heightBtn, topBtn]];
        
    }
    
    
    
    return header;
}
-(void)handleSelectAll:(UIButton *)btn {
    
    btn.selected = !btn.selected;
    [_selectedContacts removeAllObjects];
    [_contacts enumerateObjectsUsingBlock:^(Person * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        obj.selected = btn.selected ? @"1" : @"0";
        if (btn.selected) {
            [_selectedContacts addObject:obj];
        }
    }];
    [_tableView reloadData];
    if (_selectedContacts.count > 0) {
        [_bottomBtn setBackgroundColor:colorFromHex(0xF6450B)];
        [_bottomBtn setTitle:[NSString stringWithFormat:@"开始导入%ld/%ld", _selectedContacts.count, _contacts.count] forState:UIControlStateNormal];
    } else {
        [_bottomBtn setBackgroundColor:[UIColor lightGrayColor]];
        [_bottomBtn setTitle:@"开始导入" forState:UIControlStateNormal];
    }
}
*/


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    Person *contact = nil;
    if (_isSearchMode) {
        contact = _flitedContacts[indexPath.row];
    } else {
        contact = _contacts[indexPath.row];
    }
    
    if ([contact.selected integerValue] == 1) {
        if (_selectMode != SelectModeSingle) {
            contact.selected = @"0";
            [_selectedContacts removeObject:contact];
        }
    } else {
        if (_selectMode == SelectModeSingle) {
            _selectedContacts.firstObject.selected = @"0";
            [_selectedContacts removeAllObjects];
        } else {
            if (_selectedContacts.count == _maxSelected) {
                [self makeAlertForMessage:[NSString stringWithFormat:@"最多选择%ld个联系人",_maxSelected]];
                return;
            }
        }
        
        contact.selected = @"1";
        [_selectedContacts addObject:contact];
    }
    [_tableView reloadData];
    [self checkForSelected];
    
    
}

#pragma mark - Fliter
-(void)searchContactsByKeyWord:(NSString *)keyWord {
    
    if ([keyWord isEqualToString:@""]) {
        [_flitedContacts removeAllObjects];
        _isSearchMode = NO;
        [_tableView reloadData];
    } else {
        NSPredicate *predicateTemp = [NSPredicate predicateWithFormat:@"name CONTAINS[cd] $VALUE || telNumber CONTAINS $VALUE || namePinyin CONTAINS[cd] $VALUE || namePinyinAbbreviation CONTAINS[cd] $VALUE"];
        NSPredicate *predicate = [predicateTemp predicateWithSubstitutionVariables:@{@"VALUE": keyWord}];
        NSArray *result = [_contacts filteredArrayUsingPredicate:predicate];
        [_flitedContacts removeAllObjects];
        [_flitedContacts addObjectsFromArray:result];
        _isSearchMode = YES;
        [_tableView reloadData];
    }
//    [_contacts enumerateObjectsUsingBlock:^(Person * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//        if ([obj.name  rangeOfString:keyWord].length != 0 || [obj.telNumber rangeOfString:keyWord].length != 0) {
//            [_flitedContacts addObject:obj];
//        }
//    }];
    
}

#pragma mark - process
- (NSString *)processTelNumber:(NSString *)contact {
    NSString *tel = @"";
    NSString *next1 = [contact stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSString *next2 = [next1 stringByReplacingOccurrencesOfString:@"-" withString:@""];
    NSString *next3 = [[next2 stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]] stringByReplacingOccurrencesOfString:@"%C2%A0" withString:@""];
     
    tel = next3;
    if ([next2 hasPrefix:@"+"]) {
        tel = [next2 substringFromIndex:3];
    }
    
    return tel;
}

-(void)checkForSelected {

    if (_selectedContacts.count > 0) {
        [_bottomBtn setBackgroundColor:colorFromHex(0xF6450B)];
        [_bottomBtn setTitle:[NSString stringWithFormat:@"开始导入%ld/%ld", _selectedContacts.count, _contacts.count] forState:UIControlStateNormal];
    } else {
        [_bottomBtn setBackgroundColor:[UIColor lightGrayColor]];
        [_bottomBtn setTitle:@"开始导入" forState:UIControlStateNormal];
    }
   
}
-(void)makeAlertForMessage:(NSString *)message{
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"提示" message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
    [alertVC addAction:action];
    [self presentViewController:alertVC animated:YES completion:nil];
}

#pragma mark - search
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self searchContactsByKeyWord:textField.text];
    return YES;
}

-(BOOL)textFieldShouldClear:(UITextField *)textField {
    _isSearchMode = NO;
    [_tableView reloadData];
    return YES;
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    return YES;
}
-(void)textDidChange:(NSNotification *)notify{
 [self searchContactsByKeyWord:_searchTextField.text];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

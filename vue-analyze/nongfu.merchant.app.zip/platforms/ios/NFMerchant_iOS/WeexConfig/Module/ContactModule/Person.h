//
//  Person.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/9.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject
@property(nonatomic, copy) NSString *telNumber;
@property(nonatomic, copy) NSString *name;
@property(nonatomic, copy) NSString *selected;
@property(nonatomic, copy) NSString *namePinyin;
@property(nonatomic, copy) NSString *namePinyinAbbreviation;
@end

//
//  ContactCell.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/2.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Contacts/Contacts.h>
#import "Person.h"
@interface ContactCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *telLabel;
@property (strong, nonatomic) Person *person;
@property (weak, nonatomic) IBOutlet UIImageView *stateImageView;

@end

//
//  Person.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/9.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "Person.h"

@implementation Person
-(void)setNamePinyin:(NSString *)namePinyin{
    _namePinyin = [namePinyin stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSArray *result = [namePinyin componentsSeparatedByString:@" "];
    NSMutableString *abb = [NSMutableString string];
    [result enumerateObjectsUsingBlock:^(NSString *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [abb appendString:[obj substringToIndex:1]];
    }];
    self.namePinyinAbbreviation = abb;
}
@end

//
//  ContactModule.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/2.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "ContactModule.h"
#import "ContactPickerContactViewController.h"
#import "SystemPermissionsManager.h"
@implementation ContactModule
@synthesize weexInstance;

WX_EXPORT_METHOD(@selector(pickContact:callback:))

-(void)pickContact:(NSDictionary *)options callback:(WXModuleKeepAliveCallback)callback{
//    BOOL isMulti = [[options valueForKey:@"isMultiselect"] boolValue];
    NSInteger count = [[options valueForKey:@"count"] integerValue];
    
    [SystemPermissionsManager requestAuthorization:KABAddressBook completionHandler:^(BOOL granted) {
        if (granted) {
            dispatch_async(dispatch_get_main_queue(), ^{
                ContactPickerContactViewController *vc = [[ContactPickerContactViewController alloc] init];
                vc.selectMode = count > 1 ? SelectModeMulti : SelectModeSingle;
                vc.maxSelected = count ? count : 1;
                [vc setCancleBlock:^{
                    callback(@{@"result":@"cancle",@"data":@{}}, NO);
                }];
                [vc setResultCallBack:^(NSArray <Person *>*result) {
                    NSMutableArray *array = [NSMutableArray array];
                    [result enumerateObjectsUsingBlock:^(Person * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
                        [dic setObject:obj.name forKey:@"username"];
                        [dic setObject:obj.telNumber forKey:@"mobile"];
                        [array addObject:dic];
                    }];
                    callback(@{@"result":@"success",@"data":@{@"contacts": array}}, NO);
                    
                }];
                [(UINavigationController *)[[[UIApplication sharedApplication] keyWindow] rootViewController] pushViewController:vc animated:YES];
            });
        } else {
            callback(@{@"result":@"unauthorized",@"data":@{}}, NO);
        }
        
    }];
    

}

@end

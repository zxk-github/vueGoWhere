//
//  ContactModule.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/2.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WeexSDK/WeexSDK.h>
@interface ContactModule : NSObject<WXModuleProtocol>

@end

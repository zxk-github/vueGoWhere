//
//  ContactPickerContactViewController.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/2.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "BaseViewController.h"
#import "Person.h"
typedef void(^ResultBlock)(NSArray<Person *> *result);

typedef NS_ENUM(NSUInteger, SelectMode) {
    SelectModeSingle = 0,
    SelectModeMulti
};

@interface ContactPickerContactViewController : BaseViewController
@property (nonatomic, copy) ResultBlock resultCallBack;
@property (nonatomic, copy) dispatch_block_t cancleBlock;
@property (nonatomic, assign) NSInteger maxSelected;
//@property (strong, nonatomic) NSArray<NSDictionary<NSString *, NSString*> *> *preSelectedContacts;
@property (assign, nonatomic) SelectMode selectMode;
@end

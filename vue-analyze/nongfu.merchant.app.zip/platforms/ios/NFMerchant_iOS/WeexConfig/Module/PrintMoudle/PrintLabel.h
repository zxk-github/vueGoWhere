//
//  PrintLabel.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/3/12.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Printer.h"

@interface PrintLabel : NSObject
//@property (nonatomic, strong) UIImage *image;
//- (void)doPrintLabelChinaPostAirmailBPLC:(Printer*)printer;
//- (void)printImage:(UIImage *)image;
+(void) printXiaoShouKaiDanByData:(NSDictionary *)data success:(dispatch_block_t) success fail:(dispatch_block_t)fail;
+(void) printXiaoShouTuiHuoKaiDanByData:(NSDictionary *)data success:(dispatch_block_t) success fail:(dispatch_block_t)fail;
+(void) printESCXiaoShouKaiDanByData:(NSDictionary *)data success:(dispatch_block_t) success fail:(dispatch_block_t)fail;
+(void) printESCXiaoShouTuiHuoKaiDanByData:(NSDictionary *)data success:(dispatch_block_t) success fail:(dispatch_block_t)fail;
@end

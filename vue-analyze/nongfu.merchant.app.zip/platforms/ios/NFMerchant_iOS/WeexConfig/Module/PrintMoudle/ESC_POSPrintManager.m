
//
//  ESC_POSPrintManager.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/16.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "ESC_POSPrintManager.h"
#import <BabyBluetooth/BabyBluetooth.h>
#import "GlobalUtil.h"

#define kLimitLength    128
/** 往特性中写入数据的回调 */

@interface ESC_POSPrintManager()
@property (nonatomic, strong) dispatch_queue_t printQueue;
@property (nonatomic, strong) BabyBluetooth *babyBluetooth;

@property (nonatomic, strong) CBCharacteristic *writeCharacteristic;// print的写特性
@property (nonatomic, strong) NSMutableArray *all;


@property (assign, nonatomic)   NSInteger         writeCount;   /**< 写入次数 */
@property (assign, nonatomic)   NSInteger         responseCount; /**< 返回次数 */
/** 将数据写入特性中的回调 */
@property (copy, nonatomic) HLWriteToCharacteristicBlock            writeToCharacteristicBlock;
@property (copy, nonatomic) dispatch_block_t connectSuccessBlock;
@end

@implementation ESC_POSPrintManager
+(instancetype)sharedManager{
    static ESC_POSPrintManager *manger = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manger = [[ESC_POSPrintManager alloc] init];
        manger.printQueue = dispatch_queue_create("com.merchart.posprint", DISPATCH_QUEUE_SERIAL);
        manger.residueDevice = @[].mutableCopy;
        manger.printWidth = @"58";
        manger.purchasePrintable = @"1";
        manger.babyBluetooth = [BabyBluetooth shareBabyBluetooth];
        
        manger.all = @[].mutableCopy;
        [manger setBabyDelegate];
//        manger.babyBluetooth.scanForPeripherals().begin().stop(3);
    });
    return manger;
}
-(void)scan {
    [self.residueDevice removeAllObjects];
    [[ESC_POSPrintManager sharedManager].all removeAllObjects];
    self.babyBluetooth.scanForPeripherals().begin().stop(3);
}
-(void)connect:(id)deviceKey success:(dispatch_block_t) successCallBack{
    self.connectSuccessBlock = successCallBack;
    self.babyBluetooth.having(deviceKey).connectToPeripherals().discoverServices().discoverCharacteristics().readValueForCharacteristic().begin();
}

-(void)disconnect{
    if (self.currentDevice) {
        [self.babyBluetooth cancelPeripheralConnection:self.currentDevice];
    }
    
}

#pragma mark - BlueTooth

-(void)setBabyDelegate{

    //设置扫描到设备的委托
    [self.babyBluetooth setBlockOnDiscoverToPeripherals:^(CBCentralManager *central, CBPeripheral *peripheral, NSDictionary *advertisementData, NSNumber *RSSI) {
        NSLog(@"搜索到了设备:%@ id: %@",peripheral.name, peripheral.identifier);
        [[ESC_POSPrintManager sharedManager].all addObject:peripheral];
        if (![[ESC_POSPrintManager sharedManager].residueDevice containsObject:peripheral] )
            if (peripheral.state == CBPeripheralStateDisconnected) {{//为了适配 bplc 不添加已连接的设备 和 当前连接的打印机 因为bplc的扫描结果不包含已连接的设备
                [[ESC_POSPrintManager sharedManager].residueDevice addObject:peripheral];
            }
            
        }
        if ([ESC_POSPrintManager sharedManager].delegate) {
            if ([ESC_POSPrintManager sharedManager].currentDevice.state == CBPeripheralStateDisconnected) {
                [ESC_POSPrintManager sharedManager].currentDevice = nil;
            }
            [[ESC_POSPrintManager sharedManager].delegate findDeviceCurrent:[ESC_POSPrintManager sharedManager].currentDevice residue:[ESC_POSPrintManager sharedManager].residueDevice];
        }
    }];
    //状态监听
    [self.babyBluetooth setBlockOnCentralManagerDidUpdateState:^(CBCentralManager *central) {
        switch (central.state) {
                
                
            case CBManagerStateResetting:
                [ESC_POSPrintManager sharedManager].bluetoothState = central.state;
                NSLog(@"Resetting");
                break;
            case CBManagerStateUnsupported:
                [ESC_POSPrintManager sharedManager].bluetoothState = central.state;
                NSLog(@"Unsupported");
                break;
            case CBManagerStateUnauthorized:
                [ESC_POSPrintManager sharedManager].bluetoothState = central.state;
                NSLog(@"Unauthorized");
                break;
            case CBManagerStatePoweredOff:{
                [ESC_POSPrintManager sharedManager].bluetoothState = central.state;
                CBPeripheral *current = [ESC_POSPrintManager sharedManager].currentDevice;
                if (current) {
                    [[ESC_POSPrintManager sharedManager].residueDevice addObject: current];
                }
                [ESC_POSPrintManager sharedManager].currentDevice = nil;
                [ESC_POSPrintManager sharedManager].writeCharacteristic = nil;
                if ([ESC_POSPrintManager sharedManager].delegate) {
                    [[ESC_POSPrintManager sharedManager].delegate findDeviceCurrent:[ESC_POSPrintManager sharedManager].currentDevice residue:[ESC_POSPrintManager sharedManager].all];
                }
            }
                NSLog(@"PoweredOff");
                break;
            case CBManagerStatePoweredOn:
                [ESC_POSPrintManager sharedManager].bluetoothState = central.state;
                NSLog(@"PoweredOn");
                break;
                
            default:{
                [ESC_POSPrintManager sharedManager].bluetoothState = central.state;
            }
                break;
        }
    }];
    
    
    //设置设备连接成功的委托,同一个baby对象，使用不同的channel切换委托回调
    [self.babyBluetooth setBlockOnConnected:^(CBCentralManager *central, CBPeripheral *peripheral) {
        NSLog(@"设备：%@--连接成功",peripheral.name);
        if ([ESC_POSPrintManager sharedManager].connectSuccessBlock) {
            [ESC_POSPrintManager sharedManager].connectSuccessBlock();
        }
        
        [ESC_POSPrintManager sharedManager].currentDevice = peripheral;
        if ([ESC_POSPrintManager sharedManager].delegate) {
            [[ESC_POSPrintManager sharedManager].residueDevice removeObject:[ESC_POSPrintManager sharedManager].currentDevice];
            [[ESC_POSPrintManager sharedManager].delegate findDeviceCurrent:[ESC_POSPrintManager sharedManager].currentDevice residue:[ESC_POSPrintManager sharedManager].residueDevice];
            
            [[ESC_POSPrintManager sharedManager].delegate didUpdateConnectState:connectSuccess];
        }
    }];
    
    //设置设备连接失败的委托
    [self.babyBluetooth setBlockOnFailToConnect:^(CBCentralManager *central, CBPeripheral *peripheral, NSError *error) {
        NSLog(@"设备：%@--连接失败",peripheral.name);
        
    }];
    
    //设置设备断开连接的委托
    [self.babyBluetooth setBlockOnDisconnect:^(CBCentralManager *central, CBPeripheral *peripheral, NSError *error) {
        NSLog(@"设备：%@--断开连接",peripheral.name);
        [ESC_POSPrintManager sharedManager].currentDevice = nil;
        [ESC_POSPrintManager sharedManager].writeCharacteristic = nil;
        if ([ESC_POSPrintManager sharedManager].delegate) {
            [[ESC_POSPrintManager sharedManager].residueDevice addObject: peripheral];
            [[ESC_POSPrintManager sharedManager].delegate findDeviceCurrent:[ESC_POSPrintManager sharedManager].currentDevice residue:[ESC_POSPrintManager sharedManager].residueDevice];
            [[ESC_POSPrintManager sharedManager].delegate didUpdateConnectState:disconnected];
        }
    }];


    //调用 cancelScan 断开链接的回调
    [self.babyBluetooth setBlockOnCancelScanBlock:^(CBCentralManager *centralManager) {
        
    }];
    //设置发现设备的Services的委托
    [self.babyBluetooth setBlockOnDiscoverServices:^(CBPeripheral *peripheral, NSError *error) {
        for (CBService *s in peripheral.services) {
            //每个service
        }
    }];
    //设置发现设service的Characteristics的委托
    [self.babyBluetooth setBlockOnDiscoverCharacteristics:^(CBPeripheral *peripheral, CBService *service, NSError *error) {
        NSLog(@"===service name:%@",service.UUID);
    }];
    //设置读取characteristics的委托
    [self.babyBluetooth setBlockOnReadValueForCharacteristic:^(CBPeripheral *peripheral, CBCharacteristic *characteristics, NSError *error) {
        NSLog(@"characteristic name:%@ value is:%@",characteristics.UUID,characteristics.value);
        if(characteristics.properties & CBCharacteristicPropertyWrite){
            [ESC_POSPrintManager sharedManager].writeCharacteristic = characteristics;
        }
        if (![ESC_POSPrintManager sharedManager].writeCharacteristic) {
            if(characteristics.properties & CBCharacteristicPropertyWriteWithoutResponse){
                [ESC_POSPrintManager sharedManager].writeCharacteristic = characteristics;
            }
        }
        
    }];
    
    
    [self.babyBluetooth setBlockOnDidWriteValueForCharacteristic:^(CBCharacteristic *characteristic, NSError *error) {
        if (![ESC_POSPrintManager sharedManager].writeToCharacteristicBlock) {
            return;
        }
        
        [ESC_POSPrintManager sharedManager].responseCount ++;
        if ([ESC_POSPrintManager sharedManager].writeCount != [ESC_POSPrintManager sharedManager].responseCount) {
            return;
        }
        
        [ESC_POSPrintManager sharedManager].writeToCharacteristicBlock(characteristic,error);
    }];
    

    
    
}

- (void)writeValue:(NSData *)data completionBlock:(HLWriteToCharacteristicBlock)completionBlock
{
    _writeToCharacteristicBlock = completionBlock;
    if ([ESC_POSPrintManager sharedManager].writeCharacteristic.properties & CBCharacteristicPropertyWrite) {
        [self writeValue:data forCharacteristic:[ESC_POSPrintManager sharedManager].writeCharacteristic type:CBCharacteristicWriteWithResponse];
    } else {
        [self writeValue:data forCharacteristic:[ESC_POSPrintManager sharedManager].writeCharacteristic type:CBCharacteristicWriteWithoutResponse];
    }
    
}

- (void)writeValue:(NSData *)data forCharacteristic:(CBCharacteristic *)characteristic type:(CBCharacteristicWriteType)type
{
    _writeCount = 0;
    _responseCount = 0;
    // iOS 9 以后，系统添加了这个API来获取特性能写入的最大长度
    //    if ([_connectedPerpheral respondsToSelector:@selector(maximumWriteValueLengthForType:)]) {
    //        _limitLength = [_connectedPerpheral maximumWriteValueLengthForType:type];
    //    }
    
    // 如果_limitLength 小于等于0，则表示不用分段发送
    if (kLimitLength <= 0) {
        [[ESC_POSPrintManager sharedManager].currentDevice writeValue:data forCharacteristic:characteristic type:type];
        _writeCount ++;
        return;
    }
    
    if (data.length <= kLimitLength) {
        [[ESC_POSPrintManager sharedManager].currentDevice writeValue:data forCharacteristic:characteristic type:type];
        _writeCount ++;
    } else {
        NSInteger index = 0;
        for (index = 0; index < data.length - kLimitLength; index += kLimitLength) {
            NSData *subData = [data subdataWithRange:NSMakeRange(index, kLimitLength)];
            [[ESC_POSPrintManager sharedManager].currentDevice writeValue:subData forCharacteristic:characteristic type:type];
            _writeCount++;
        }
        NSData *leftData = [data subdataWithRange:NSMakeRange(index, data.length - index)];
        if (leftData) {
            [[ESC_POSPrintManager sharedManager].currentDevice writeValue:leftData forCharacteristic:characteristic type:type];
            _writeCount++;
        }
    }
}

-(BOOL)isConnected{
    return [ESC_POSPrintManager sharedManager].currentDevice ? YES : NO;
}


-(NSInteger)printPointsCount{
    if ([self.printWidth isEqualToString:@"58"]) {
        return 384;
    } else if ([self.printWidth isEqualToString:@"80"]) {
        return 576;
    } else if ([self.printWidth isEqualToString:@"76"]) {
        return 528;
    }
    return 384;
}


@end

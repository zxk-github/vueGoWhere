//
//  SetCellData.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/10.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol SetCellData <NSObject>
-(void)setCellData:(id)data;
@end

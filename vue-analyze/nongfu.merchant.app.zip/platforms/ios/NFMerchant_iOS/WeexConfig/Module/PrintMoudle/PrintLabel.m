//
//  PrintLabel.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/3/12.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "PrintLabel.h"
#import "BPLCPrintManager.h"
#import "ExceptionSDK.h"
#import "HLPrinter.h"
#import "ESC_POSPrintManager.h"

@interface PrintLabel()
@end

@implementation PrintLabel


/*
- (void)doPrintLabelChinaPostAirmailBPLC:(Printer*)printer{
//    @try {
//        Printer *printer = [[ConnectivityViewController sharedController] printer];
        [[printer printerConfigure] setPrintDirection:PRINT_DIRECTION_NORAML];
        LabelEdit *labelEdit = [printer labelEdit];
        
        [labelEdit setColumn:1 space:0];
        CGFloat printWidth = 567;
        [labelEdit setLabelSize:printWidth height:1000];
        
        NSString *fontName = @"HelveticaNeue";
        CGFloat fontSizeMin = 30;
        CGFloat fontSizeMax = 34;
        CGFloat marginMin = 15;
        CGFloat marginMax = 25;
        
        // line1-1 居中 占1行
        NSString *text1 = @"天通苑农药店";
        CGFloat marginTop1 = 50;
        CGSize size1 = [self cacularSizeForText:text1 useFont:[UIFont fontWithName:fontName size:fontSizeMin] maxWidth:printWidth];
        CGRect rect1 = CGRectMake((printWidth - size1.width) / 2, marginTop1, size1.width, size1.height);
        [labelEdit printTextUseTTF:(UInt32)rect1.origin.x y:(UInt32)rect1.origin.y  fontName:fontName fontSize:(UInt32)fontSizeMin content:text1];
        
        // Line2-1 居中占1行
        NSString *text2 = @"销售单据";
        CGFloat marginTop2 = marginMin;
        CGSize size2 = [self cacularSizeForText:text2 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect2 = CGRectMake((printWidth - size2.width) / 2, CGRectGetMaxY(rect1) + marginTop2, size2.width, size2.height);
        [labelEdit printTextUseTTF:(UInt32)rect2.origin.x y:(UInt32)rect2.origin.y fontName:fontName fontSize:(UInt32)fontSizeMax content:text2];
        
        // line3-1 靠左
        
        NSString *text3_1 = @"订单编号:";
        CGFloat marginTop3_1 = marginMin;
        CGSize size3_1 = [self cacularSizeForText:text3_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect3_1 = CGRectMake(0, CGRectGetMaxY(rect2) + marginTop3_1, size3_1.width, size3_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect3_1.origin.x y:(UInt32)rect3_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text3_1];
        
        // line3-2 靠右
        NSString *text3_2 = @"XS1213213000021";
        CGFloat marginTop3_2 = marginMin;
        CGSize size3_2 = [self cacularSizeForText:text3_2 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect3_2 = CGRectMake(printWidth - size3_2.width, CGRectGetMaxY(rect2) + marginTop3_2, size3_2.width, size3_2.height);
        [labelEdit printTextUseTTF:(UInt32)rect3_2.origin.x y:(UInt32)rect3_2.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text3_2];
        
        //line 4-1 靠左
        NSString *text4_1 = @"开单日期:";
        CGFloat marginTop4_1 = marginMin;
        CGSize size4_1 = [self cacularSizeForText:text4_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect4_1 = CGRectMake(0, CGRectGetMaxY(rect3_1) + marginTop4_1, size4_1.width, size4_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect4_1.origin.x y:(UInt32)rect4_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text4_1];
        
        //line 4-2 靠右
        NSString *text4_2 = @"XS121321321";
        CGFloat marginTop4_2 = marginMin;
        CGSize size4_2 = [self cacularSizeForText:text4_2 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect4_2 = CGRectMake(printWidth - size4_2.width, CGRectGetMaxY(rect3_1) + marginTop4_2, size4_2.width, size4_2.height);
        [labelEdit printTextUseTTF:(UInt32)rect4_2.origin.x y:(UInt32)rect4_2.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text4_2];
        
        //line 5-1 分割线
        
        NSString *text5_1 = @"- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ";
        CGFloat marginTop5_1 = marginMax;
        CGSize size5_1 = [self cacularSizeForText:text5_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect5_1 = CGRectMake(0, CGRectGetMaxY(rect4_1) + marginTop5_1, size5_1.width, size5_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect5_1.origin.x y:(UInt32)rect5_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text5_1];
        
        //line 6-1 靠左
        NSString *text6_1 = @"会员姓名:";
        CGFloat marginTop6_1 = marginMax;
        CGSize size6_1 = [self cacularSizeForText:text6_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect6_1 = CGRectMake(0, CGRectGetMaxY(rect5_1) + marginTop6_1, size6_1.width, size6_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect6_1.origin.x y:(UInt32)rect6_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text6_1];
        
        //line 6-2 靠右
        NSString *text6_2 = @"XS121321321";
        CGFloat marginTop6_2 = marginMin;
        CGSize size6_2 = [self cacularSizeForText:text4_2 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect6_2 = CGRectMake(printWidth - size6_2.width, CGRectGetMaxY(rect5_1) + marginTop6_2, size6_2.width, size6_2.height);
        [labelEdit printTextUseTTF:(UInt32)rect6_2.origin.x y:(UInt32)rect6_2.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text6_2];
        
        
    
        //line 7-1 靠左
        NSString *text7_1 = @"联系方式:";
        CGFloat marginTop7_1 = marginMin;
        CGSize size7_1 = [self cacularSizeForText:text7_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect7_1 = CGRectMake(0, CGRectGetMaxY(rect6_1) + marginTop7_1, size7_1.width, size7_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect7_1.origin.x y:(UInt32)rect7_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text7_1];
        
        //line 7-2 靠右
        NSString *text7_2 = @"XS121321321";
        CGFloat marginTop7_2 = marginMin;
        CGSize size7_2 = [self cacularSizeForText:text7_2 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect7_2 = CGRectMake(printWidth - size6_2.width, CGRectGetMaxY(rect6_1) + marginTop7_2, size7_2.width, size7_2.height);
        [labelEdit printTextUseTTF:(UInt32)rect7_2.origin.x y:(UInt32)rect7_2.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text7_2];
        
        
        
        //line 8-1 分割线
        
        NSString *text8_1 = @"- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ";
        CGFloat marginTop8_1 = marginMax;
        CGSize size8_1 = [self cacularSizeForText:text8_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect8_1 = CGRectMake(0, CGRectGetMaxY(rect7_1) + marginTop8_1, size8_1.width, size8_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect8_1.origin.x y:(UInt32)rect8_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text8_1];
        
        
        
        //line 9-1 靠左
        NSString *text9_1 = @"商品";
        CGFloat marginTop9_1 = marginMax;
        CGSize size9_1 = [self cacularSizeForText:text9_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect9_1 = CGRectMake(0, CGRectGetMaxY(rect8_1) + marginTop9_1, size9_1.width, size9_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect9_1.origin.x y:(UInt32)rect9_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text9_1];
        
        //line 10-1 靠左 占 1/2
        NSString *text10_1 = @"项目";
        CGFloat marginTop10_1 = marginMin;
        CGSize size10_1 = [self cacularSizeForText:text10_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth / 2];
        CGRect rect10_1 = CGRectMake(0, CGRectGetMaxY(rect9_1) + marginTop10_1, size10_1.width, size10_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect10_1.origin.x y:(UInt32)rect10_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text10_1];
        
        //line 10-2 中列 占 1/4
        NSString *text10_2 = @"数量";
        CGFloat marginTop10_2 = marginMin;
        CGSize size10_2 = [self cacularSizeForText:text10_2 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth / 4];
        CGRect rect10_2 = CGRectMake((printWidth / 2) + (printWidth / 8) - (size10_2.width / 2), CGRectGetMaxY(rect9_1) + marginTop10_2, size10_2.width, size10_2.height);
        [labelEdit printTextUseTTF:(UInt32)rect10_2.origin.x y:(UInt32)rect10_2.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text10_2];
        
        //line 10-3 右列 占 1/4
        NSString *text10_3 = @"数量";
        CGFloat marginTop10_3 = marginMin;
        CGSize size10_3 = [self cacularSizeForText:text10_3 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth / 4];
        CGRect rect10_3 = CGRectMake((printWidth * 3 / 4) + (printWidth / 8) - (size10_3.width / 2), CGRectGetMaxY(rect9_1) + marginTop10_3, size10_3.width, size10_3.height);
        [labelEdit printTextUseTTF:(UInt32)rect10_3.origin.x y:(UInt32)rect10_3.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text10_3];
        
        //line 11-1 分割线
        
        NSString *text11_1 = @"- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ";
        CGFloat marginTop11_1 = marginMax;
        CGSize size11_1 = [self cacularSizeForText:text11_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect11_1 = CGRectMake(0, CGRectGetMaxY(rect10_1) + marginTop11_1, size11_1.width, size11_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect11_1.origin.x y:(UInt32)rect11_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text11_1];
        
        // 商品 列表
        NSArray *goodsArray = @[@{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}];
        __block CGFloat lastMaxY = CGRectGetMaxY(rect11_1);
        [goodsArray enumerateObjectsUsingBlock:^(NSDictionary   * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            CGFloat marginTopGoods = marginMin;
            if (idx == 0) {
                marginTopGoods = marginMax;
            }
            //商品名  占1行
            NSString *textName = obj[@"name"];
            
            CGSize sizeName = [self cacularSizeForText:textName useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
            CGRect rectName = CGRectMake(0, lastMaxY + marginTopGoods, sizeName.width, sizeName.height);
            [labelEdit printTextUseTTF:(UInt32)rectName.origin.x y:(UInt32)rectName.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:textName];
            
            //单价 占1/2
            NSString *textSinglePrice = obj[@"price"];
            CGSize sizeSinglePrice = [self cacularSizeForText:textSinglePrice useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth / 2];
            CGRect rectSinglePrice = CGRectMake(0, CGRectGetMaxY(rectName) + marginTopGoods, sizeSinglePrice.width, sizeSinglePrice.height);
            [labelEdit printTextUseTTF:(UInt32)rectSinglePrice.origin.x y:(UInt32)rectSinglePrice.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:textSinglePrice];
            
            //数量 占1/4
            NSString *textNum = obj[@"num"];
            CGSize sizeNum = [self cacularSizeForText:textNum useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth / 4];
            CGRect rectNum = CGRectMake((printWidth / 2) + (printWidth / 8) - (sizeNum.width / 2), CGRectGetMaxY(rectName) + marginTopGoods, sizeNum.width, sizeNum.height);
            [labelEdit printTextUseTTF:(UInt32)rectNum.origin.x y:(UInt32)rectNum.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:textNum];
            
            //金额 占1/4
            NSString *textPrice = obj[@"price"];
            CGSize sizePrice = [self cacularSizeForText:textPrice useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth / 4];
            CGRect rectPrice = CGRectMake((printWidth * 3 / 4) + (printWidth / 8) - (sizePrice.width / 2), CGRectGetMaxY(rectName) + marginTopGoods, sizePrice.width, sizePrice.height);
            [labelEdit printTextUseTTF:(UInt32)rectPrice.origin.x y:(UInt32)rectPrice.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:textPrice];
            
            lastMaxY = CGRectGetMaxY(rectPrice);
            
            
        }];
        
        
        //line 12-1 分割线
        NSString *text12_1 = @"- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ";
        CGFloat marginTop12_1 = marginMax;
        CGSize size12_1 = [self cacularSizeForText:text12_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect12_1 = CGRectMake(0, lastMaxY + marginTop12_1, size12_1.width, size12_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect12_1.origin.x y:(UInt32)rect12_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text12_1];
        
        //line 13-1 靠左 占2/1
        NSString *text13_1 = @"合计";
        CGFloat marginTop13_1 = marginMin;
        CGSize size13_1 = [self cacularSizeForText:text13_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth / 2];
        CGRect rect13_1 = CGRectMake(0, CGRectGetMaxY(rect12_1) + marginTop13_1, size13_1.width, size13_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect13_1.origin.x y:(UInt32)rect13_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text13_1];
        //line 13-2 靠中 占 1/4
        NSString *text13_2 = @"20";
        CGFloat marginTop13_2 = marginMin;
        CGSize size13_2 = [self cacularSizeForText:text13_2 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth / 4];
        CGRect rect13_2 = CGRectMake((printWidth / 2) + (printWidth / 8) - (size13_2.width / 2), CGRectGetMaxY(rect12_1) + marginTop13_2, size13_2.width, size13_2.height);
        [labelEdit printTextUseTTF:(UInt32)rect13_2.origin.x y:(UInt32)rect13_2.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text13_2];
        
        //line 13-3 靠右 占 1/4
        NSString *text13_3 = @"460.00";
        CGFloat marginTop13_3 = marginMin;
        CGSize size13_3 = [self cacularSizeForText:text13_3 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth / 4];
        CGRect rect13_3 = CGRectMake((printWidth * 3 / 4) + (printWidth / 8) - (size13_3.width / 2), CGRectGetMaxY(rect12_1) + marginTop13_3, size10_3.width, size13_3.height);
        [labelEdit printTextUseTTF:(UInt32)rect13_3.origin.x y:(UInt32)rect13_3.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text13_3];
        
        //line 14 靠右 占 1行
        
        NSString *text14_1 = @"结算方式: 支付宝";
        CGFloat marginTop14_1 = marginMin;
        CGSize size14_1 = [self cacularSizeForText:text14_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect14_1 = CGRectMake(0, CGRectGetMaxY(rect13_1) + marginTop14_1, size14_1.width, size14_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect14_1.origin.x y:(UInt32)rect14_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text14_1];
        
        //line 15-1 靠左 占2/1
        NSString *text15_1 = @"折扣率: 50%";
        CGFloat marginTop15_1 = marginMin;
        CGSize size15_1 = [self cacularSizeForText:text15_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth / 2];
        CGRect rect15_1 = CGRectMake(0, CGRectGetMaxY(rect14_1) + marginTop15_1, size15_1.width, size15_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect15_1.origin.x y:(UInt32)rect15_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text15_1];
        //line 15-2 靠中 占 1/4
        NSString *text15_2 = @"优惠";
        CGFloat marginTop15_2 = marginMin;
        CGSize size15_2 = [self cacularSizeForText:text15_2 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth / 4];
        CGRect rect15_2 = CGRectMake((printWidth / 2) + (printWidth / 8) - (size15_2.width / 2), CGRectGetMaxY(rect14_1) + marginTop15_2, size15_2.width, size15_2.height);
        [labelEdit printTextUseTTF:(UInt32)rect15_2.origin.x y:(UInt32)rect15_2.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text15_2];
        
        //line 15-3 靠右 占 1/4
        NSString *text15_3 = @"230.00";
        CGFloat marginTop15_3 = marginMin;
        CGSize size15_3 = [self cacularSizeForText:text15_3 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth / 4];
        CGRect rect15_3 = CGRectMake((printWidth * 3 / 4) + (printWidth / 8) - (size15_3.width / 2), CGRectGetMaxY(rect14_1) + marginTop15_3, size10_3.width, size15_3.height);
        [labelEdit printTextUseTTF:(UInt32)rect13_3.origin.x y:(UInt32)rect15_3.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text15_3];
        
        //line 16-1 靠右 占1行
        
        NSString *text16_1 = @"实际支付230";
        CGFloat marginTop16_1 = marginMin;
        CGSize size16_1 = [self cacularSizeForText:text16_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect16_1 = CGRectMake(0, CGRectGetMaxY(rect15_1) + marginTop16_1, size16_1.width, size16_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect16_1.origin.x y:(UInt32)rect16_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text16_1];
        
        
        //line 17-1 分割线
        NSString *text17_1 = @"- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ";
        CGFloat marginTop17_1 = marginMax;
        CGSize size17_1 = [self cacularSizeForText:text17_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect17_1 = CGRectMake(0, CGRectGetMaxY(rect16_1) + marginTop17_1, size17_1.width, size17_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect17_1.origin.x y:(UInt32)rect17_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text17_1];
        
        //line 18-1 一段话
        
        NSString *text18_1 = @"上述商品清淡涉及商品,本人已收货,本人确认以上交易\r\n 客户签名:";
        CGFloat marginTop18_1 = marginMin;
        CGSize size18_1 = [self cacularSizeForText:text18_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect18_1 = CGRectMake(0, CGRectGetMaxY(rect17_1) + marginTop18_1, size18_1.width, size18_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect18_1.origin.x y:(UInt32)rect18_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text18_1];
        
        //line 19-1 分割线
        NSString *text19_1 = @"- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ";
        CGFloat marginTop19_1 = 70;
        CGSize size19_1 = [self cacularSizeForText:text19_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect19_1 = CGRectMake(0, CGRectGetMaxY(rect18_1) + marginTop19_1, size19_1.width, size19_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect19_1.origin.x y:(UInt32)rect19_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text19_1];
        
        
        //line 20-1 靠右 占1行
        
        NSString *text20_1 = @"实际支付230";
        CGFloat marginTop20_1 = marginMin;
        CGSize size20_1 = [self cacularSizeForText:text20_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect20_1 = CGRectMake(0, CGRectGetMaxY(rect19_1) + marginTop20_1, size20_1.width, size20_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect20_1.origin.x y:(UInt32)rect20_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text20_1];
        
        //line 21-1 靠右 占1行
        
        NSString *text21_1 = @"实际支付230";
        CGFloat marginTop21_1 = marginMin;
        CGSize size21_1 = [self cacularSizeForText:text21_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect21_1 = CGRectMake(0, CGRectGetMaxY(rect20_1) + marginTop21_1, size21_1.width, size21_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect21_1.origin.x y:(UInt32)rect21_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text21_1];
        
        //line 22-1 居中 占1行
        
        NSString *text22_1 = @"实际支付230";
        CGFloat marginTop22_1 = marginMax;
        CGSize size22_1 = [self cacularSizeForText:text22_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect22_1 = CGRectMake((printWidth - size22_1.width) / 2, CGRectGetMaxY(rect21_1) + marginTop22_1, size22_1.width, size22_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect22_1.origin.x y:(UInt32)rect22_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text22_1];
        
        
        // 二维码 23-1 居中
        NSString *text23_1 = @"实际支付230";
        CGFloat marginTop23_1 = marginMax;
        CGRect qrRect = CGRectMake((printWidth - 200) / 2, CGRectGetMaxY(rect22_1) + marginTop23_1, 200, 200);
        [labelEdit printBarcodeQR:(UInt32)qrRect.origin.x y:(UInt32)qrRect.origin.y angle:ROTATED_0 content:[text23_1 dataUsingEncoding:NSUTF8StringEncoding] ECCLever:QR_LEVEL_H cellWidth:200 model:QR_MODE_ORIGINAL];
        
//        [labelEdit printBarcode1D:60 y:CGRectGetMaxY(rect22_1) + marginMax barcodeType:BARCODE_CODE128 angle:ROTATED_0 content:[@"LK002325888CN" dataUsingEncoding:NSUTF8StringEncoding] height:80 HRIPostion:HRI_ALIGN_CENTER narrowbarWidth:2 wideBarwidth:5];
        
        
        
        //line 24-1 居中 占1行
        
        NSString *text24_1 = @"实际支付230";
        CGFloat marginTop24_1 = marginMax;
        CGSize size24_1 = [self cacularSizeForText:text24_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect24_1 = CGRectMake((printWidth - size24_1.width) / 2, CGRectGetMaxY(rect22_1) + 200 + marginTop24_1, size24_1.width, size24_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect24_1.origin.x y:(UInt32)rect24_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text24_1];
        
        
        
        //line 25-1 居中 占1行
        
        NSString *text25_1 = @"********农夫掌柜***********\r\n\r\n\r\n\r\n\r\n";
        CGFloat marginTop25_1 = marginMax;
        CGSize size25_1 = [self cacularSizeForText:text25_1 useFont:[UIFont fontWithName:fontName size:fontSizeMax] maxWidth:printWidth];
        CGRect rect25_1 = CGRectMake((printWidth - size25_1.width) / 2, CGRectGetMaxY(rect24_1) + 200 + marginTop25_1, size25_1.width, size25_1.height);
        [labelEdit printTextUseTTF:(UInt32)rect25_1.origin.x y:(UInt32)rect25_1.origin.y fontName:fontName fontSize:(UInt32)fontSizeMin content:text24_1];
        
        
        
        
        
        
        [[printer printerControl] print:1 copyNum:1];
//    }@catch (ExceptionSDK *e){
//        NSString *msg =[NSString stringWithFormat:@"%@: %@: errorCode=%u(%@)", [e name],[e reason],[e errorCode],[e errorDecsription]];
//        NSLog(@"%@", msg);
//
//    }@finally{
//    }
}


- (void)printImage:(UIImage *)image{
 
    Printer *printer = [[ConnectivityViewController sharedController] printer];
    [[printer printerConfigure] setPrintDirection:PRINT_DIRECTION_NORAML];
    LabelEdit *labelEdit = [printer labelEdit];
    
    [labelEdit setColumn:1 space:0];
    CGFloat printWidth = 567;
    [labelEdit setLabelSize:printWidth height:1000];
    
    [labelEdit printImage:0 y:0 image:image method:IMAGE_BINARIZE_AUTO_THRESHOLD customThreshold:0];
    [[printer printerControl] print:1 copyNum:1];
 
}
*/

//80毫米最多25个字
+(NSArray *)dealWithLongString:(NSString *)string maxLength:(NSInteger)maxLength{
    NSMutableArray *tempArr = [NSMutableArray array];
    NSInteger subStrNum = string.length / maxLength;
    
    if (subStrNum == 0) {
        [tempArr addObject:string];
    } else {
        for (NSInteger i = 0; i < subStrNum; i++) {
            NSRange range = NSMakeRange((maxLength * i), maxLength);
            NSString *subStr = [string substringWithRange:range];
            [tempArr addObject:subStr];
        }
        NSString *lastStr = [string substringFromIndex:subStrNum * maxLength];
        [tempArr addObject:lastStr];
    }
    
    return tempArr;
}


//新北洋打印机不做适配了  因为新北洋太贵了o(╯□╰)o
+(void) printXiaoShouKaiDanByData:(NSDictionary *)data success:(dispatch_block_t) success fail:(dispatch_block_t)fail{

    @try{
        if (![BPLCPrintManager sharedManager].isConnected) {
            fail();
            return;
        }
        
        
        
        //打印设置 
        BOOL isCompany = [[[data objectForKey:@"member"] objectForKey:@"enterpriseName"] isKindOfClass:[NSString class]]? YES : NO;// 是否是企业会员 (需要<加/减>一行 企业会员信息)
        BOOL isCash = [[data objectForKey:@"paymentType"] integerValue] == 2 ? YES : NO; //是否是现金(现金 减) (需要<加/减>两行 实付金额 和 找零金额信息信息)

        
        Printer *printer = [[BPLCPrintManager sharedManager] printer];
        [[printer printerConfigure] setPrintDirection:PRINT_DIRECTION_NORAML];
        LabelEdit *labelEdit = [printer labelEdit];
        [labelEdit setColumn:1 space:0];
        CGFloat printWidth = 576;
        // 商品 列表
        NSArray *products = [data objectForKey:@"products"];
        NSMutableArray *goodsArray = @[].mutableCopy;
        [products enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSMutableDictionary *good = @{}.mutableCopy;
            
            [good setObject:obj[@"name"] forKey:@"name"];
            [good setObject: [NSString stringWithFormat:@"%@",obj[@"price"]]  forKey:@"singlePrice"];
            [good setObject: [NSString stringWithFormat:@"%@",obj[@"count"]] forKey:@"num"];
            [good setObject: [NSString stringWithFormat:@"%@",obj[@"subtotal"]] forKey:@"price"];
//            [good setObject:@"" forKey:@"price"];
            [good setObject:obj[@"spec"] forKey:@"sepc"];
            [goodsArray addObject: good];
            
        }];
        
        
//        NSArray *goodsArray = @[@{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}, @{@"name":@"敌敌畏12g/袋", @"singlePrice": @"23.00", @"num": @"10", @"price": @"230.00"}];
        
        //开始 排版 (行数[基本行数 <放大的字体 占 1行 * 放大倍数>] * (行高 + 间距) + 二维码 + 走纸
        
        
        NSInteger lineNumber = 24 + (isCompany ? 1 : 0) + (isCash ? 0 : 2);
        
        
        UInt32 labelHeight = (UInt32)((lineNumber + goodsArray.count * 2) * (24 + 5) + 170 + 300);
        [labelEdit setLabelSize:printWidth height:labelHeight];
        NSString *fontName = @"7";
        UInt32 fontSizeMax = 3;
        UInt32 fontSizeMin = 0;
        
        UInt32 lineSpaceMin = 5;
        UInt32 lineSpaceMax = 15;
        
        UInt32 row1x = 0;
        UInt32 row2x = (UInt32) (printWidth / 2);
        UInt32 row3x = (UInt32) (printWidth * 3 / 4);
        
        NSMutableArray *printInfos = @[].mutableCopy;
        CGPoint tempPoint = CGPointZero;
        
        
        
        //开始每一行文案
        //第一行
        CGPoint orign1_1 = CGPointMake(0, 30);
        NSString *text1_1 = [NSString stringWithFormat:@"%@销售单据",data[@"merchant"][@"name"]] ;
        
        NSDictionary *printInfo1_1 = @{@"orign": NSStringFromCGPoint(orign1_1), @"content": text1_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo1_1];
        tempPoint = orign1_1;
        //第二行 干掉

        //第三行
        CGPoint orign3_1 = CGPointMake(0, tempPoint.y + (fontSizeMax) * 24 + lineSpaceMax);
        NSString *text3_1 = [NSString stringWithFormat:@"开单时间: %@",data[@"createdTime"]];
        
        NSDictionary *printInfo3_1 = @{@"orign": NSStringFromCGPoint(orign3_1), @"content": text3_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo3_1];
        tempPoint = orign3_1;
        //第四行
        CGPoint orign4_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text4_1 = [NSString stringWithFormat:@"订单编号: %@",data[@"sn"]];
        
        NSDictionary *printInfo4_1 = @{@"orign": NSStringFromCGPoint(orign4_1), @"content": text4_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo4_1];
        tempPoint = orign4_1;
        //第五行
        CGPoint orign5_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text5_1 = @"----------------客户信息-------------------------";
        
        NSDictionary *printInfo5_1 = @{@"orign": NSStringFromCGPoint(orign5_1), @"content": text5_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo5_1];
        tempPoint = orign5_1;
        
        
        //插行 1 判断是否是企业会员
        if (isCompany) {
            CGPoint chaPoint1_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
            NSString *chaText1_1 = [NSString stringWithFormat:@"企业名称 %@",data[@"member"][@"enterpriseName"]];
            
            NSDictionary *chaPrintInfo1_1 = @{@"orign": NSStringFromCGPoint(chaPoint1_1), @"content": chaText1_1, @"fontSize": @(fontSizeMin)};
            [printInfos addObject:chaPrintInfo1_1];
            tempPoint = chaPoint1_1;
        }
        
        
        
        
        //第六行
        CGPoint orign6_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text6_1 = [@"会员姓名: " stringByAppendingString: data[@"member"][@"name"]];
        
        NSDictionary *printInfo6_1 = @{@"orign": NSStringFromCGPoint(orign6_1), @"content": text6_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo6_1];
        tempPoint = orign6_1;
        //第七行
        CGPoint orign7_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text7_1 = [@"联系方式: " stringByAppendingString:data[@"member"][@"mobile"]];
        
        NSDictionary *printInfo7_1 = @{@"orign": NSStringFromCGPoint(orign7_1), @"content": text7_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo7_1];
        tempPoint = orign7_1;
        //第八行
        CGPoint orign8_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text8_1 = @"-------------------------------------------------";
        
        NSDictionary *printInfo8_1 = @{@"orign": NSStringFromCGPoint(orign8_1), @"content": text8_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo8_1];
        tempPoint = orign8_1;
        //第九行
        CGPoint orign9_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text9_1 = @"商品";
        
        NSDictionary *printInfo9_1 = @{@"orign": NSStringFromCGPoint(orign9_1), @"content": text9_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo9_1];
        tempPoint = orign9_1;
        
        //第十行
        CGPoint orign10_1 = CGPointMake(row1x, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text10_1 = @"单价";
        
        NSDictionary *printInfo10_1 = @{@"orign": NSStringFromCGPoint(orign10_1), @"content": text10_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo10_1];
        tempPoint = orign10_1;
        
        CGPoint orign10_2 = CGPointMake(row2x, tempPoint.y);
        NSString *text10_2 = @"数量";
        
        NSDictionary *printInfo10_2 = @{@"orign": NSStringFromCGPoint(orign10_2), @"content": text10_2, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo10_2];
        
        CGPoint orign10_3 = CGPointMake(row3x, tempPoint.y);
        NSString *text10_3 = @"小计";
        
        NSDictionary *printInfo10_3 = @{@"orign": NSStringFromCGPoint(orign10_3), @"content": text10_3, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo10_3];
        //第十一行
        CGPoint orign11_1 = CGPointMake(row1x, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text11_1 = @"----------------商品信息-------------------------";
        
        NSDictionary *printInfo11_1 = @{@"orign": NSStringFromCGPoint(orign11_1), @"content": text11_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo11_1];
        tempPoint = orign11_1;
        // 商品列表
        __block CGFloat lastLineY = orign11_1.y;
        [goodsArray enumerateObjectsUsingBlock:^(NSDictionary * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            
            CGPoint orign1x_1 = CGPointMake(row1x, lastLineY + (fontSizeMin + 1) * 24 + lineSpaceMin);
            NSString *text1x_1 = [NSString stringWithFormat:@"%@(%@%@/%@)",obj[@"name"], obj[@"sepc"][@"count"],obj[@"sepc"][@"unit"],obj[@"sepc"][@"pkgUnit"]];
            
            NSDictionary *printInfo1x_1 = @{@"orign": NSStringFromCGPoint(orign1x_1), @"content": text1x_1, @"fontSize": @(fontSizeMin)};
            [printInfos addObject:printInfo1x_1];
            
            CGPoint orign1x_2 = CGPointMake(row1x, orign1x_1.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
            NSString *text1x_2 = obj[@"singlePrice"];
            
            NSDictionary *printInfo1x_2 = @{@"orign": NSStringFromCGPoint(orign1x_2), @"content": text1x_2, @"fontSize": @(fontSizeMin)};
            [printInfos addObject:printInfo1x_2];
            
            CGPoint orign1x_3 = CGPointMake(row2x, orign1x_1.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
            NSString *text1x_3 = [NSString stringWithFormat:@"%@(%@)",obj[@"num"], obj[@"sepc"][@"pkgUnit"]] ;
            
            NSDictionary *printInfo1x_3 = @{@"orign": NSStringFromCGPoint(orign1x_3), @"content": text1x_3, @"fontSize": @(fontSizeMin)};
            [printInfos addObject:printInfo1x_3];
            
            CGPoint orign1x_4 = CGPointMake(row3x, orign1x_1.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
            NSString *text1x_4 = obj[@"price"];
            
            NSDictionary *printInfo1x_4 = @{@"orign": NSStringFromCGPoint(orign1x_4), @"content": text1x_4, @"fontSize": @(fontSizeMin)};
            [printInfos addObject:printInfo1x_4];
            
            lastLineY = orign1x_4.y;
        }];
        tempPoint = CGPointMake(0, lastLineY);
        
        //第十三行
        CGPoint orign13_1 = CGPointMake(row1x, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text13_1 = @"合计";
        
        NSDictionary *printInfo13_1 = @{@"orign": NSStringFromCGPoint(orign13_1), @"content": text13_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo13_1];

        
        CGPoint orign13_3 = CGPointMake(row3x, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text13_3 = [NSString stringWithFormat:@"%@", data[@"totalPrice"]];
        
        NSDictionary *printInfo13_3 = @{@"orign": NSStringFromCGPoint(orign13_3), @"content": text13_3, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo13_3];
        tempPoint = orign13_1;
        
        //第十二行
        CGPoint orign12_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text12_1 = @"----------------结账信息-------------------------";
        
        NSDictionary *printInfo12_1 = @{@"orign": NSStringFromCGPoint(orign12_1), @"content": text12_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo12_1];
        tempPoint = orign12_1;
        
        //第十四行
        CGPoint orign14_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text14_1 = [NSString stringWithFormat:@"合计金额: %@元", data[@"totalPrice"]];
        NSDictionary *printInfo14_1 = @{@"orign": NSStringFromCGPoint(orign14_1), @"content": text14_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo14_1];
        tempPoint = orign14_1;
        
        //第十五行
        CGPoint orign15_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text15_1 = [NSString stringWithFormat:@"优惠金额: %@元", data[@"couponPrice"]];
        
        NSDictionary *printInfo15_1 = @{@"orign": NSStringFromCGPoint(orign15_1), @"content": text15_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo15_1];
        tempPoint = orign15_1;
        
        //第十六行
        CGPoint orign16_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text16_1 = [NSString stringWithFormat:@"待付金额: %.2f元", [data[@"totalPrice"] floatValue] - [data[@"couponPrice"] floatValue]];
        
        NSDictionary *printInfo16_1 = @{@"orign": NSStringFromCGPoint(orign16_1), @"content": text16_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo16_1];
        tempPoint = orign16_1;
        
        //第十七行
        CGPoint orign17_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSInteger type = [data[@"paymentType"] integerValue];
        NSString *text17_1Temp = @"";
        if (type == 1) {
            text17_1Temp =  @"结算方式: 赊欠";
        } else if (type == 2) {
            text17_1Temp =  @"结算方式: 现金";
        } else if (type == 3) {
            text17_1Temp =  @"结算方式: 赊欠";
        }
        
        NSString *text17_1 = text17_1Temp;
        
        NSDictionary *printInfo17_1 = @{@"orign": NSStringFromCGPoint(orign17_1), @"content": text17_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo17_1];
        tempPoint = orign17_1;
        
        //第十八行 ------------------根据判断是否是现金支付而显示或不显示
        
        if (!isCash) {
            CGPoint orign18_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
            NSString *text18_1 = [NSString stringWithFormat:@"实付金额: %@元", [data objectForKey:@"realPrice"] ? [data objectForKey:@"realPrice"] : @"0.00" ];
            
            NSDictionary *printInfo18_1 = @{@"orign": NSStringFromCGPoint(orign18_1), @"content": text18_1, @"fontSize": @(fontSizeMin)};
            [printInfos addObject:printInfo18_1];
            tempPoint = orign18_1;
            
            //第十九行
            float shePrice = fabs(([data[@"realPrice"] floatValue] - ( [data[@"totalPrice"] floatValue] - [data[@"couponPrice"] floatValue] )));
            CGPoint orign19_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
            NSString *text19_1 = [NSString stringWithFormat:@"赊欠金额: %.2f元", shePrice];
            
            NSDictionary *printInfo19_1 = @{@"orign": NSStringFromCGPoint(orign19_1), @"content": text19_1, @"fontSize": @(fontSizeMin)};
            [printInfos addObject:printInfo19_1];
            tempPoint = orign19_1;
        }
        
        //-------------------------
        //第二十行 干掉了
        
        //第二十一行
        CGPoint orign21_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text21_1 = [@"备注: " stringByAppendingString:data[@"comments"]];
        
        NSDictionary *printInfo21_1 = @{@"orign": NSStringFromCGPoint(orign21_1), @"content": text21_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo21_1];
        tempPoint = orign21_1;
        
        //第22行
        CGPoint orign22_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text22_1 = @"----------------店铺信息-------------------------";
        
        NSDictionary *printInfo22_1 = @{@"orign": NSStringFromCGPoint(orign22_1), @"content": text22_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo22_1];
        tempPoint = orign22_1;
        
        //23
        CGPoint orign23_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text23_1 = [@"店铺名称: " stringByAppendingString:data[@"merchant"][@"name"]];
        
        NSDictionary *printInfo23_1 = @{@"orign": NSStringFromCGPoint(orign23_1), @"content": text23_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo23_1];
        tempPoint = orign23_1;
        //24
        CGPoint orign24_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text24_1 = [@"联系方式: " stringByAppendingString: data[@"merchant"][@"mobile"]];
        
        NSDictionary *printInfo24_1 = @{@"orign": NSStringFromCGPoint(orign24_1), @"content": text24_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo24_1];
        tempPoint = orign24_1;
        //25
        NSString *address = [NSString stringWithFormat:@"店铺地址: %@%@%@%@",data[@"merchant"][@"region"][@"province"],data[@"merchant"][@"region"][@"city"],data[@"merchant"][@"region"][@"district"],data[@"merchant"][@"address"]];
        lastLineY = tempPoint.y;
        [[self dealWithLongString:address maxLength:25] enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            CGPoint orignAddress = CGPointMake(0, lastLineY + (fontSizeMin + 1) * 24 + lineSpaceMin);
            NSString *textAddress = obj;
            NSDictionary *printInfoAddress = @{@"orign": NSStringFromCGPoint(orignAddress), @"content": textAddress, @"fontSize": @(fontSizeMin)};
            [printInfos addObject:printInfoAddress];
            lastLineY = orignAddress.y;
        }];
        tempPoint.y = lastLineY;
        
        
        
//        CGPoint orign25_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
//        NSString *text25_1 = [@"店铺地址: " stringByAppendingString:data[@"merchant"][@"address"]];
//
//        NSDictionary *printInfo25_1 = @{@"orign": NSStringFromCGPoint(orign25_1), @"content": text25_1, @"fontSize": @(fontSizeMin)};
//        [printInfos addObject:printInfo25_1];
//        tempPoint = orign25_1;
        
        
        //第26行 二维码大概高 170
        CGPoint orign26_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text26_1 = data[@"sn"];

        [labelEdit printBarcodeQR:(UInt32)orign26_1.x y:(UInt32)orign26_1.y angle:0 content:[text26_1 dataUsingEncoding:NSUTF8StringEncoding] ECCLever:QR_LEVEL_M cellWidth:6 model:QR_MODE_ENHANCED];
        tempPoint = orign26_1;
        //第27行
        CGPoint orign27_1 = CGPointMake(0, tempPoint.y + 170 + lineSpaceMin);
        NSString *text27_1 = @"扫描二维码, 查看订单";
        
        NSDictionary *printInfo27_1 = @{@"orign": NSStringFromCGPoint(orign27_1), @"content": text27_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo27_1];
        tempPoint = orign27_1;
        
        CGPoint orign28_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text28_1 = @"****************神州农掌柜**********************";
        
        NSDictionary *printInfo28_1 = @{@"orign": NSStringFromCGPoint(orign28_1), @"content": text28_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo28_1];
        tempPoint = orign28_1;
        

        //目前共26行
        [printInfos enumerateObjectsUsingBlock:^(NSDictionary *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            CGPoint orign = CGPointFromString(obj[@"orign"]);
            [labelEdit printText:(UInt32)orign.x y:(UInt32)orign.y fontName:fontName content:obj[@"content"] angle:ROTATED_0 sizeHorizontal:(UInt32)([obj[@"fontSize"] intValue]) sizeVertical:(UInt32)([obj[@"fontSize"] intValue])];
        }];
        
        
        [[printer printerControl] print:1 copyNum:1];
        success();
    } @catch(ExceptionSDK *e) {
        fail();
    } @finally{
    
    }
}
+(void) printXiaoShouTuiHuoKaiDanByData:(NSDictionary *)data success:(dispatch_block_t) success fail:(dispatch_block_t)fail{
    @try{
        if (![BPLCPrintManager sharedManager].isConnected) {
            fail();
            return;
        }
        //打印设置
        BOOL isCompany = [[data objectForKey:@"member"] objectForKey:@"enterpriseName"] ? YES : NO;// 是否是企业会员 (需要<加/减>一行 企业会员信息)
        BOOL isCash = [[data objectForKey:@"paymentType"] integerValue] == 2 ? YES : NO; //是否是现金 (需要<加/减>两行 实付金额 和 找零金额信息信息)
        
        Printer *printer = [[BPLCPrintManager sharedManager] printer];
        [[printer printerConfigure] setPrintDirection:PRINT_DIRECTION_NORAML];
        LabelEdit *labelEdit = [printer labelEdit];
        [labelEdit setColumn:1 space:0];
        CGFloat printWidth = 576;
        // 商品 列表
        
        //开始 排版 (行数(基本行数 放大的字体 占 1行 * 放大倍数) * (行高 + 间距) + 二维码 + 走纸
        NSArray *products = [data objectForKey:@"products"];
        NSMutableArray *goodsArray = @[].mutableCopy;
        [products enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSMutableDictionary *good = @{}.mutableCopy;
            
            [good setObject:obj[@"name"] forKey:@"name"];
            [good setObject: [NSString stringWithFormat:@"%@",obj[@"price"]]  forKey:@"singlePrice"];
            [good setObject: [NSString stringWithFormat:@"%@",obj[@"count"]] forKey:@"num"];
            [good setObject: [NSString stringWithFormat:@"%@",obj[@"subtotal"]] forKey:@"price"];
//            [good setObject:@"" forKey:@"price"];
            [good setObject:obj[@"spec"] forKey:@"sepc"];
            [goodsArray addObject: good];
            
        }];
        
        
        //开始 排版 (行数[基本行数 <放大的字体 占 1行 * 放大倍数>] * (行高 + 间距) + 二维码 + 走纸
        
        
        NSInteger lineNumber = 22 + (isCompany ? 1 : 0) + (isCash ? 0 : 2);
        
        
        UInt32 labelHeight = (UInt32)((lineNumber + goodsArray.count * 2) * (24 + 5) + 170 + 300);
        [labelEdit setLabelSize:printWidth height:labelHeight];
        NSString *fontName = @"7";
        UInt32 fontSizeMax = 3;
        UInt32 fontSizeMin = 0;
        
        UInt32 lineSpaceMin = 5;
        UInt32 lineSpaceMax = 15;
        
        UInt32 row1x = 0;
        UInt32 row2x = (UInt32) (printWidth / 2);
        UInt32 row3x = (UInt32) (printWidth * 3 / 4);
        
        NSMutableArray *printInfos = @[].mutableCopy;
        CGPoint tempPoint = CGPointZero;
        
        //开始每一行文案
        //第一行
        CGPoint orign1_1 = CGPointMake(0, 30);
        NSString *text1_1 = [NSString stringWithFormat:@"%@销售退货单据",data[@"merchant"][@"name"]];
        
        NSDictionary *printInfo1_1 = @{@"orign": NSStringFromCGPoint(orign1_1), @"content": text1_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo1_1];
        tempPoint = orign1_1;
        //第二行 干掉

        //第三行
        CGPoint orign3_1 = CGPointMake(0, tempPoint.y + (fontSizeMax) * 24 + lineSpaceMax);
        NSString *text3_1 = [NSString stringWithFormat:@"开单时间: %@",data[@"createdTime"]];
        
        NSDictionary *printInfo3_1 = @{@"orign": NSStringFromCGPoint(orign3_1), @"content": text3_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo3_1];
        tempPoint = orign3_1;
        //第四行
        CGPoint orign4_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text4_1 = [NSString stringWithFormat:@"订单编号: %@",data[@"sn"]];
        
        NSDictionary *printInfo4_1 = @{@"orign": NSStringFromCGPoint(orign4_1), @"content": text4_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo4_1];
        tempPoint = orign4_1;
        //第五行
        CGPoint orign5_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text5_1 = @"----------------客户信息-------------------------";
        
        NSDictionary *printInfo5_1 = @{@"orign": NSStringFromCGPoint(orign5_1), @"content": text5_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo5_1];
        tempPoint = orign5_1;
        
        
        //插行 1 判断是否是企业会员
        if (isCompany) {
            CGPoint chaPoint1_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
            NSString *chaText1_1 = [NSString stringWithFormat:@"企业名称 %@",data[@"member"][@"enterpriseName"]];
            
            NSDictionary *chaPrintInfo1_1 = @{@"orign": NSStringFromCGPoint(chaPoint1_1), @"content": chaText1_1, @"fontSize": @(fontSizeMin)};
            [printInfos addObject:chaPrintInfo1_1];
            tempPoint = chaPoint1_1;
        }
        
        
        
        
        //第六行
        CGPoint orign6_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text6_1 = [@"会员姓名: " stringByAppendingString: data[@"member"][@"name"]];
        
        NSDictionary *printInfo6_1 = @{@"orign": NSStringFromCGPoint(orign6_1), @"content": text6_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo6_1];
        tempPoint = orign6_1;
        //第七行
        CGPoint orign7_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text7_1 = [@"联系方式: " stringByAppendingString:data[@"member"][@"mobile"]];
        
        NSDictionary *printInfo7_1 = @{@"orign": NSStringFromCGPoint(orign7_1), @"content": text7_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo7_1];
        tempPoint = orign7_1;
        //第八行
        CGPoint orign8_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text8_1 = @"-------------------------------------------------";
        
        NSDictionary *printInfo8_1 = @{@"orign": NSStringFromCGPoint(orign8_1), @"content": text8_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo8_1];
        tempPoint = orign8_1;
        //第九行
        CGPoint orign9_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text9_1 = @"商品";
        
        NSDictionary *printInfo9_1 = @{@"orign": NSStringFromCGPoint(orign9_1), @"content": text9_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo9_1];
        tempPoint = orign9_1;
        
        //第十行
        CGPoint orign10_1 = CGPointMake(row1x, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text10_1 = @"单价";
        
        NSDictionary *printInfo10_1 = @{@"orign": NSStringFromCGPoint(orign10_1), @"content": text10_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo10_1];
        tempPoint = orign10_1;
        
        CGPoint orign10_2 = CGPointMake(row2x, tempPoint.y);
        NSString *text10_2 = @"数量";
        
        NSDictionary *printInfo10_2 = @{@"orign": NSStringFromCGPoint(orign10_2), @"content": text10_2, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo10_2];
        
        CGPoint orign10_3 = CGPointMake(row3x, tempPoint.y);
        NSString *text10_3 = @"小计";
        
        NSDictionary *printInfo10_3 = @{@"orign": NSStringFromCGPoint(orign10_3), @"content": text10_3, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo10_3];
        //第十一行
        CGPoint orign11_1 = CGPointMake(row1x, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text11_1 = @"----------------商品信息-------------------------";
        
        NSDictionary *printInfo11_1 = @{@"orign": NSStringFromCGPoint(orign11_1), @"content": text11_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo11_1];
        tempPoint = orign11_1;
        // 商品列表
        __block CGFloat lastLineY = tempPoint.y;
        [goodsArray enumerateObjectsUsingBlock:^(NSDictionary * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            
            CGPoint orign1x_1 = CGPointMake(row1x, lastLineY + (fontSizeMin + 1) * 24 + lineSpaceMin);
            NSString *text1x_1 = [NSString stringWithFormat:@"%@(%@%@/%@)",obj[@"name"], obj[@"sepc"][@"count"],obj[@"sepc"][@"unit"],obj[@"sepc"][@"pkgUnit"]];
            
            NSDictionary *printInfo1x_1 = @{@"orign": NSStringFromCGPoint(orign1x_1), @"content": text1x_1, @"fontSize": @(fontSizeMin)};
            [printInfos addObject:printInfo1x_1];
            
            CGPoint orign1x_2 = CGPointMake(row1x, orign1x_1.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
            NSString *text1x_2 = obj[@"singlePrice"];
            
            NSDictionary *printInfo1x_2 = @{@"orign": NSStringFromCGPoint(orign1x_2), @"content": text1x_2, @"fontSize": @(fontSizeMin)};
            [printInfos addObject:printInfo1x_2];
            
            CGPoint orign1x_3 = CGPointMake(row2x, orign1x_1.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
            NSString *text1x_3 = [NSString stringWithFormat:@"%@(%@)",obj[@"num"], obj[@"sepc"][@"pkgUnit"]];
            
            NSDictionary *printInfo1x_3 = @{@"orign": NSStringFromCGPoint(orign1x_3), @"content": text1x_3, @"fontSize": @(fontSizeMin)};
            [printInfos addObject:printInfo1x_3];
            
            CGPoint orign1x_4 = CGPointMake(row3x, orign1x_1.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
            NSString *text1x_4 = obj[@"price"];
            
            NSDictionary *printInfo1x_4 = @{@"orign": NSStringFromCGPoint(orign1x_4), @"content": text1x_4, @"fontSize": @(fontSizeMin)};
            [printInfos addObject:printInfo1x_4];
            
            lastLineY = orign1x_4.y;
        }];
        tempPoint = CGPointMake(0, lastLineY);
        
        //第十三行
        CGPoint orign13_1 = CGPointMake(row1x, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text13_1 = @"合计";
        
        NSDictionary *printInfo13_1 = @{@"orign": NSStringFromCGPoint(orign13_1), @"content": text13_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo13_1];
        

        
        CGPoint orign13_3 = CGPointMake(row3x, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text13_3 = [NSString stringWithFormat:@"%@", data[@"totalPrice"]];
        
        NSDictionary *printInfo13_3 = @{@"orign": NSStringFromCGPoint(orign13_3), @"content": text13_3, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo13_3];
        tempPoint = orign13_1;
        
        //第十二行
        CGPoint orign12_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text12_1 = @"----------------结账信息-------------------------";
        
        NSDictionary *printInfo12_1 = @{@"orign": NSStringFromCGPoint(orign12_1), @"content": text12_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo12_1];
        tempPoint = orign12_1;
        
        //第十四行
        CGPoint orign14_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text14_1 = [NSString stringWithFormat:@"退款总金额: %@元", data[@"totalPrice"]];
        NSDictionary *printInfo14_1 = @{@"orign": NSStringFromCGPoint(orign14_1), @"content": text14_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo14_1];
        tempPoint = orign14_1;
        
        //第十五行
        CGPoint orign15_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text15_1 = [NSString stringWithFormat:@"抵充欠款金额: %@元", data[@"couponPrice"]];
        
        NSDictionary *printInfo15_1 = @{@"orign": NSStringFromCGPoint(orign15_1), @"content": text15_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo15_1];
        tempPoint = orign15_1;
        
        //第十六行
        CGPoint orign16_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text16_1 = [NSString stringWithFormat:@"实退金额: %.2f元", [data[@"totalPrice"] floatValue] - [data[@"couponPrice"] floatValue]];
        
        NSDictionary *printInfo16_1 = @{@"orign": NSStringFromCGPoint(orign16_1), @"content": text16_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo16_1];
        tempPoint = orign16_1;
        
        //第十七行
        CGPoint orign17_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSInteger type = [data[@"paymentType"] integerValue];
        NSString *text17_1Temp = @"";
        if (type == 1) {
            text17_1Temp =  @"结算方式: 赊欠";
        } else if (type == 2) {
            text17_1Temp =  @"结算方式: 现金";
        } else if (type == 3) {
            text17_1Temp =  @"结算方式: 赊欠";
        }
        
        NSString *text17_1 = text17_1Temp;
        
        NSDictionary *printInfo17_1 = @{@"orign": NSStringFromCGPoint(orign17_1), @"content": text17_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo17_1];
        tempPoint = orign17_1;
        
        //第十八行
        CGPoint orign18_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text18_1 = [@"备注: " stringByAppendingString:data[@"comments"]];
        
        NSDictionary *printInfo18_1 = @{@"orign": NSStringFromCGPoint(orign18_1), @"content": text18_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo18_1];
        tempPoint = orign18_1;
        
        //第19行
        CGPoint orign19_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text19_1 = @"----------------店铺信息-------------------------";
        
        NSDictionary *printInfo19_1 = @{@"orign": NSStringFromCGPoint(orign19_1), @"content": text19_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo19_1];
        tempPoint = orign19_1;
        
        //20
        CGPoint orign20_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text20_1 = [@"店铺名称: " stringByAppendingString:data[@"merchant"][@"name"]];
        
        NSDictionary *printInfo20_1 = @{@"orign": NSStringFromCGPoint(orign20_1), @"content": text20_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo20_1];
        tempPoint = orign20_1;
        //21
        CGPoint orign21_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text21_1 = [@"联系方式: " stringByAppendingString: data[@"merchant"][@"mobile"]];
        
        NSDictionary *printInfo21_1 = @{@"orign": NSStringFromCGPoint(orign21_1), @"content": text21_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo21_1];
        tempPoint = orign21_1;
        //22
        lastLineY = tempPoint.y;
        NSString *address = [NSString stringWithFormat:@"店铺地址: %@%@%@%@",data[@"merchant"][@"region"][@"province"],data[@"merchant"][@"region"][@"city"],data[@"merchant"][@"region"][@"district"],data[@"merchant"][@"address"]];
        [[self dealWithLongString:address maxLength:25] enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            CGPoint orignAddress = CGPointMake(0, lastLineY + (fontSizeMin + 1) * 24 + lineSpaceMin);
            NSString *textAddress = obj;
            NSDictionary *printInfoAddress = @{@"orign": NSStringFromCGPoint(orignAddress), @"content": textAddress, @"fontSize": @(fontSizeMin)};
            [printInfos addObject:printInfoAddress];
            lastLineY = orignAddress.y;
        }];
        tempPoint.y = lastLineY;
        
        
//        CGPoint orign22_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
//        NSString *text22_1 = [@"店铺地址: " stringByAppendingString:data[@"merchant"][@"address"]];
//
//        NSDictionary *printInfo22_1 = @{@"orign": NSStringFromCGPoint(orign22_1), @"content": text22_1, @"fontSize": @(fontSizeMin)};
//        [printInfos addObject:printInfo22_1];
//        tempPoint = orign22_1;
        
        //第23行 二维码大概高 170
        CGPoint orign23_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text23_1 = data[@"sn"];
    
        [labelEdit printBarcodeQR:(UInt32)orign23_1.x y:(UInt32)orign23_1.y angle:0 content:[text23_1 dataUsingEncoding:NSUTF8StringEncoding] ECCLever:QR_LEVEL_M cellWidth:6 model:QR_MODE_ENHANCED];
        tempPoint = orign23_1;

        
        //第24
        CGPoint orign24_1 = CGPointMake(0, tempPoint.y + 170 + lineSpaceMin);
        NSString *text24_1 = @"扫描二维码, 查看订单";
        
        NSDictionary *printInfo24_1 = @{@"orign": NSStringFromCGPoint(orign24_1), @"content": text24_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo24_1];
        tempPoint = orign24_1;
        
        
        CGPoint orign25_1 = CGPointMake(0, tempPoint.y + (fontSizeMin + 1) * 24 + lineSpaceMin);
        NSString *text25_1 = @"****************神州农掌柜**********************";
        
        NSDictionary *printInfo25_1 = @{@"orign": NSStringFromCGPoint(orign25_1), @"content": text25_1, @"fontSize": @(fontSizeMin)};
        [printInfos addObject:printInfo25_1];
        tempPoint = orign25_1;
        
        
        
        [printInfos enumerateObjectsUsingBlock:^(NSDictionary *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            CGPoint orign = CGPointFromString(obj[@"orign"]);
            [labelEdit printText:(UInt32)orign.x y:(UInt32)orign.y fontName:fontName content:obj[@"content"] angle:ROTATED_0 sizeHorizontal:(UInt32)([obj[@"fontSize"] intValue]) sizeVertical:(UInt32)([obj[@"fontSize"] intValue])];
        }];
        
        
        [[printer printerControl] print:1 copyNum:1];
        
        
        success();
        
    } @catch(ExceptionSDK *e) {
        fail();
    } @finally{
        
    }
   
}

// esc

+(void) printESCXiaoShouKaiDanByData:(NSDictionary *)data success:(dispatch_block_t) success fail:(dispatch_block_t)fail{
    
    if (![ESC_POSPrintManager sharedManager].isConnected) {
        fail();
        return;
    }
    
    HLPrinter *printer = [[HLPrinter alloc] init];
    printer.width = [ESC_POSPrintManager sharedManager].printPointsCount;//设置打印纸宽度
    
    //打印设置
    BOOL isCompany = [[[data objectForKey:@"member"] objectForKey:@"enterpriseName"] isKindOfClass:[NSString class]]? YES : NO;// 是否是企业会员 (需要<加/减>一行 企业会员信息)
    BOOL isCash = [[data objectForKey:@"paymentType"] integerValue] == 2 ? YES : NO; //是否是现金(现金 减) (需要<加/减>两行 实付金额 和 找零金额信息信息)
    
    
    // 商品 列表
    NSArray *products = [data objectForKey:@"products"];
    NSMutableArray *goodsArray = @[].mutableCopy;
    [products enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSMutableDictionary *good = @{}.mutableCopy;
        
        [good setObject:obj[@"name"] forKey:@"name"];
        [good setObject: [NSString stringWithFormat:@"%@",obj[@"price"]]  forKey:@"singlePrice"];
        [good setObject: [NSString stringWithFormat:@"%@",obj[@"count"]] forKey:@"num"];
        [good setObject: [NSString stringWithFormat:@"%@",obj[@"subtotal"]] forKey:@"price"];
        //            [good setObject:@"" forKey:@"price"];
        [good setObject:obj[@"spec"] forKey:@"sepc"];
        [goodsArray addObject: good];
        
    }];
    
    
    NSString *text1_1 = [NSString stringWithFormat:@"%@销售单据",data[@"merchant"][@"name"]] ;
    [printer appendText:text1_1 alignment:HLTextAlignmentCenter];
    NSString *text3_1 = [NSString stringWithFormat:@"开单时间: %@",data[@"createdTime"]];
    [printer appendText:text3_1 alignment:HLTextAlignmentLeft];
    NSString *text4_1 = [NSString stringWithFormat:@"订单编号: %@",data[@"sn"]];
    [printer appendText:text4_1 alignment:HLTextAlignmentLeft];
    
    
    NSString *text5_1 = @"-----------客户信息-----------";
    [printer appendText:text5_1 alignment:HLTextAlignmentLeft];
    if (isCompany) {
        NSString *chaText1_1 = [NSString stringWithFormat:@"企业名称 %@",data[@"member"][@"enterpriseName"]];
        [printer appendText:chaText1_1 alignment:HLTextAlignmentLeft];
    }
    NSString *text6_1 = [@"会员姓名: " stringByAppendingString: data[@"member"][@"name"]];
    [printer appendText:text6_1 alignment:HLTextAlignmentLeft];
    
    NSString *text7_1 = [@"联系方式: " stringByAppendingString:data[@"member"][@"mobile"]];
    [printer appendText:text7_1 alignment:HLTextAlignmentLeft];
    
    
    
    
    NSString *text8_1 = @"----------------------------";
    [printer appendText:text8_1 alignment:HLTextAlignmentLeft];
    NSString *text9_1 = @"商品名称/规格";
    [printer appendText:text9_1 alignment:HLTextAlignmentLeft];
    [printer appendLeftText:@"单价" middleText:@"数量" rightText:@"小计" isTitle:YES];
    
    
    
    
    NSString *text10_1 = @"-----------商品信息-----------";
    [printer appendText:text10_1 alignment:HLTextAlignmentLeft];

    [goodsArray enumerateObjectsUsingBlock:^(NSDictionary * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSString *text1x_1 = [NSString stringWithFormat:@"%@(%@%@/%@)",obj[@"name"], obj[@"sepc"][@"count"],obj[@"sepc"][@"unit"],obj[@"sepc"][@"pkgUnit"]];
        [printer appendText:text1x_1 alignment:HLTextAlignmentLeft];
        
        NSString *text1x_2 = obj[@"singlePrice"];
        NSString *text1x_3 = [NSString stringWithFormat:@"%@(%@)",obj[@"num"], obj[@"sepc"][@"pkgUnit"]] ;
        NSString *text1x_4 = obj[@"price"];
        [printer appendLeftText:text1x_2 middleText:text1x_3 rightText:text1x_4 isTitle:NO];
    }];
    NSString *text13_1 = @"合计";
    NSString *text13_3 = [NSString stringWithFormat:@"%@", data[@"totalPrice"]];
    [printer appendTitle:text13_1 value:text13_3];
    
    
    
    
    
    NSString *text11_1 = @"-----------结账信息-----------";
    [printer appendText:text11_1 alignment:HLTextAlignmentLeft];
    NSString *text14_1 = [NSString stringWithFormat:@"合计金额: %@元", data[@"totalPrice"]];
    [printer appendText:text14_1 alignment:HLTextAlignmentLeft];
    NSString *text15_1 = [NSString stringWithFormat:@"优惠金额: %@元", data[@"couponPrice"]];
    [printer appendText:text15_1 alignment:HLTextAlignmentLeft];
    NSString *text16_1 = [NSString stringWithFormat:@"待付金额: %.2f元", [data[@"totalPrice"] floatValue] - [data[@"couponPrice"] floatValue]];
    [printer appendText:text16_1 alignment:HLTextAlignmentLeft];
    NSInteger type = [data[@"paymentType"] integerValue];
    NSString *text17_1Temp = @"";
    if (type == 1) {
        text17_1Temp =  @"结算方式: 赊欠";
    } else if (type == 2) {
        text17_1Temp =  @"结算方式: 现金";
    } else if (type == 3) {
        text17_1Temp =  @"结算方式: 赊欠";
    }
    
    NSString *text17_1 = text17_1Temp;
    [printer appendText:text17_1 alignment:HLTextAlignmentLeft];
    if (!isCash) {
        NSString *text18_1 = [NSString stringWithFormat:@"实付金额: %@元", [data objectForKey:@"realPrice"] ? [data objectForKey:@"realPrice"] : @"0.00" ];
        [printer appendText:text18_1 alignment:HLTextAlignmentLeft];
        float shePrice = fabs(([data[@"realPrice"] floatValue] - ( [data[@"totalPrice"] floatValue] - [data[@"couponPrice"] floatValue] )));
        NSString *text19_1 = [NSString stringWithFormat:@"赊欠金额: %.2f元", shePrice];
        [printer appendText:text19_1 alignment:HLTextAlignmentLeft];

    }
    NSString *text21_1 = [@"备注: " stringByAppendingString:data[@"comments"]];
    [printer appendText:text21_1 alignment:HLTextAlignmentLeft];
    
    
    
    
    NSString *text22_1 = @"-----------店铺信息-----------";
    [printer appendText:text22_1 alignment:HLTextAlignmentLeft];
    NSString *text23_1 = [@"店铺名称: " stringByAppendingString:data[@"merchant"][@"name"]];
    [printer appendText:text23_1 alignment:HLTextAlignmentLeft];
    NSString *text24_1 = [@"联系方式: " stringByAppendingString: data[@"merchant"][@"mobile"]];
    [printer appendText:text24_1 alignment:HLTextAlignmentLeft];
    NSString *address = [NSString stringWithFormat:@"店铺地址: %@%@%@%@",data[@"merchant"][@"region"][@"province"],data[@"merchant"][@"region"][@"city"],data[@"merchant"][@"region"][@"district"],data[@"merchant"][@"address"]];
    [printer appendText:address alignment:HLTextAlignmentLeft];
//    NSString *text26_1 = data[@"sn"];
//    [printer appendQRCodeWithInfo:text26_1 size:16 alignment:HLTextAlignmentCenter];
//    NSString *text27_1 = @"扫描二维码, 查看订单";
//    [printer appendText:text27_1 alignment:HLTextAlignmentLeft];
    NSString *text28_1 = @"***********店铺信息***********";
    [printer appendText:text28_1 alignment:HLTextAlignmentLeft];
    [printer appendNewLine];
    [printer appendNewLine];
    [printer appendNewLine];
    [[ESC_POSPrintManager sharedManager] writeValue:[printer getFinalData] completionBlock:^(CBCharacteristic *characteristic, NSError *error) {
        if (!error) {
            NSLog(@"写入成功");
            success();
        } else {
            fail();
        }
    }];
}

+(void) printESCXiaoShouTuiHuoKaiDanByData:(NSDictionary *)data success:(dispatch_block_t) success fail:(dispatch_block_t)fail{
    
    if (![ESC_POSPrintManager sharedManager].isConnected) {
        fail();
        return;
    }
    
    HLPrinter *printer = [[HLPrinter alloc] init];
    printer.width = [ESC_POSPrintManager sharedManager].printPointsCount;//设置打印纸宽度
    
    //打印设置
    BOOL isCompany = [[[data objectForKey:@"member"] objectForKey:@"enterpriseName"] isKindOfClass:[NSString class]]? YES : NO;// 是否是企业会员 (需要<加/减>一行 企业会员信息)
//    BOOL isCash = [[data objectForKey:@"paymentType"] integerValue] == 2 ? YES : NO; //是否是现金(现金 减) (需要<加/减>两行 实付金额 和 找零金额信息信息)
    
    
    // 商品 列表
    NSArray *products = [data objectForKey:@"products"];
    NSMutableArray *goodsArray = @[].mutableCopy;
    [products enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSMutableDictionary *good = @{}.mutableCopy;
        
        [good setObject:obj[@"name"] forKey:@"name"];
        [good setObject: [NSString stringWithFormat:@"%@",obj[@"price"]]  forKey:@"singlePrice"];
        [good setObject: [NSString stringWithFormat:@"%@",obj[@"count"]] forKey:@"num"];
        [good setObject: [NSString stringWithFormat:@"%@",obj[@"subtotal"]] forKey:@"price"];
        //            [good setObject:@"" forKey:@"price"];
        [good setObject:obj[@"spec"] forKey:@"sepc"];
        [goodsArray addObject: good];
        
    }];
    
    
    NSString *text1_1 = [NSString stringWithFormat:@"%@销售退货单据",data[@"merchant"][@"name"]] ;
    [printer appendText:text1_1 alignment:HLTextAlignmentCenter];
    NSString *text3_1 = [NSString stringWithFormat:@"开单时间: %@",data[@"createdTime"]];
    [printer appendText:text3_1 alignment:HLTextAlignmentLeft];
    NSString *text4_1 = [NSString stringWithFormat:@"订单编号: %@",data[@"sn"]];
    [printer appendText:text4_1 alignment:HLTextAlignmentLeft];
    
    
    NSString *text5_1 = @"-----------客户信息-----------";
    [printer appendText:text5_1 alignment:HLTextAlignmentLeft];
    if (isCompany) {
        NSString *chaText1_1 = [NSString stringWithFormat:@"企业名称 %@",data[@"member"][@"enterpriseName"]];
        [printer appendText:chaText1_1 alignment:HLTextAlignmentLeft];
    }
    NSString *text6_1 = [@"会员姓名: " stringByAppendingString: data[@"member"][@"name"]];
    [printer appendText:text6_1 alignment:HLTextAlignmentLeft];
    
    NSString *text7_1 = [@"联系方式: " stringByAppendingString:data[@"member"][@"mobile"]];
    [printer appendText:text7_1 alignment:HLTextAlignmentLeft];
    
    
    
    
    NSString *text8_1 = @"----------------------------";
    [printer appendText:text8_1 alignment:HLTextAlignmentLeft];
    NSString *text9_1 = @"商品名称/规格";
    [printer appendText:text9_1 alignment:HLTextAlignmentLeft];
    [printer appendLeftText:@"单价" middleText:@"数量" rightText:@"小计" isTitle:YES];
    
    
    
    
    NSString *text10_1 = @"-----------商品信息-----------";
    [printer appendText:text10_1 alignment:HLTextAlignmentLeft];
    
    [goodsArray enumerateObjectsUsingBlock:^(NSDictionary * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSString *text1x_1 = [NSString stringWithFormat:@"%@(%@%@/%@)",obj[@"name"], obj[@"sepc"][@"count"],obj[@"sepc"][@"unit"],obj[@"sepc"][@"pkgUnit"]];
        [printer appendText:text1x_1 alignment:HLTextAlignmentLeft];
        
        NSString *text1x_2 = obj[@"singlePrice"];
        NSString *text1x_3 = [NSString stringWithFormat:@"%@(%@)",obj[@"num"], obj[@"sepc"][@"pkgUnit"]] ;
        NSString *text1x_4 = obj[@"price"];
        [printer appendLeftText:text1x_2 middleText:text1x_3 rightText:text1x_4 isTitle:NO];
    }];
    NSString *text13_1 = @"合计";
    NSString *text13_3 = [NSString stringWithFormat:@"%@", data[@"totalPrice"]];
    [printer appendTitle:text13_1 value:text13_3];
    
    
    
    
    
    NSString *text11_1 = @"-----------结账信息-----------";
    [printer appendText:text11_1 alignment:HLTextAlignmentLeft];
    NSString *text14_1 = [NSString stringWithFormat:@"退款总金额: %@元", data[@"totalPrice"]];
    [printer appendText:text14_1 alignment:HLTextAlignmentLeft];
    NSString *text15_1 = [NSString stringWithFormat:@"抵充欠款金额: %@元", data[@"couponPrice"]];
    [printer appendText:text15_1 alignment:HLTextAlignmentLeft];
    NSString *text16_1 = [NSString stringWithFormat:@"实退金额: %.2f元", [data[@"totalPrice"] floatValue] - [data[@"couponPrice"] floatValue]];
    [printer appendText:text16_1 alignment:HLTextAlignmentLeft];
    NSInteger type = [data[@"paymentType"] integerValue];
    NSString *text17_1Temp = @"";
    if (type == 1) {
        text17_1Temp =  @"结算方式: 赊欠";
    } else if (type == 2) {
        text17_1Temp =  @"结算方式: 现金";
    } else if (type == 3) {
        text17_1Temp =  @"结算方式: 赊欠";
    }
    
    NSString *text17_1 = text17_1Temp;
    [printer appendText:text17_1 alignment:HLTextAlignmentLeft];
//    if (!isCash) {
//        NSString *text18_1 = [NSString stringWithFormat:@"实付金额: %@元", [data objectForKey:@"realPrice"] ? [data objectForKey:@"realPrice"] : @"0.00" ];
//        [printer appendText:text18_1 alignment:HLTextAlignmentLeft];
//        float shePrice = fabs(([data[@"realPrice"] floatValue] - ( [data[@"totalPrice"] floatValue] - [data[@"couponPrice"] floatValue] )));
//        NSString *text19_1 = [NSString stringWithFormat:@"赊欠金额: %.2f元", shePrice];
//        [printer appendText:text19_1 alignment:HLTextAlignmentLeft];
//
//    }
    NSString *text21_1 = [@"备注: " stringByAppendingString:data[@"comments"]];
    [printer appendText:text21_1 alignment:HLTextAlignmentLeft];
    
    
    
    
    NSString *text22_1 = @"-----------店铺信息-----------";
    [printer appendText:text22_1 alignment:HLTextAlignmentLeft];
    NSString *text23_1 = [@"店铺名称: " stringByAppendingString:data[@"merchant"][@"name"]];
    [printer appendText:text23_1 alignment:HLTextAlignmentLeft];
    NSString *text24_1 = [@"联系方式: " stringByAppendingString: data[@"merchant"][@"mobile"]];
    [printer appendText:text24_1 alignment:HLTextAlignmentLeft];
    NSString *address = [NSString stringWithFormat:@"店铺地址: %@%@%@%@",data[@"merchant"][@"region"][@"province"],data[@"merchant"][@"region"][@"city"],data[@"merchant"][@"region"][@"district"],data[@"merchant"][@"address"]];
    [printer appendText:address alignment:HLTextAlignmentLeft];
//    NSString *text26_1 = data[@"sn"];
//    [printer appendQRCodeWithInfo:text26_1 size:16 alignment:HLTextAlignmentCenter];
//    NSString *text27_1 = @"扫描二维码, 查看订单";
//    [printer appendText:text27_1 alignment:HLTextAlignmentLeft];
    NSString *text28_1 = @"***********神州农掌柜***********";
    [printer appendText:text28_1 alignment:HLTextAlignmentLeft];
    [printer appendNewLine];
    [printer appendNewLine];
    [printer appendNewLine];
    [[ESC_POSPrintManager sharedManager] writeValue:[printer getFinalData] completionBlock:^(CBCharacteristic *characteristic, NSError *error) {
        if (!error) {
            NSLog(@"写入成功");
            success();
        } else {
            fail();
        }
    }];
}







@end

//
//  PrintManager.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/9.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FactoryPrinter.h"
#import "FactoryConnection.h"
#import "Printer.h"
#import "SDKBase.h"

typedef void(^SearchBlock)(NSDictionary *current, NSArray *residue);

@interface BPLCPrintManager : NSObject
@property (nonatomic, strong) Printer *printer;
@property (nonatomic, strong) NSString *printWidth;
@property (nonatomic, strong) NSDictionary *deviceList;
@property (nonatomic, strong) NSDictionary *connectedDeviceInfo;
@property (nonatomic, strong) NSMutableArray *residueDeviceKeys;
@property (nonatomic, strong) NSString *purchasePrintable;//进货开单打印开关
+(instancetype)sharedManager;
-(BOOL)isConnected;
-(void)connect:(id)deviceKey success:(dispatch_block_t) successCallBack fail:(dispatch_block_t)failCallBack;
-(void)disconnect;
-(void)search:(SearchBlock) searchCallBack;
-(NSString *)findDiviceForKey:(NSString *) key;
@end

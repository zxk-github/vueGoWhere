//
//  PrintMoudle.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/3/11.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "PrintMoudle.h"
#import "PrintLabel.h"
#import "PrintControlViewController.h"
#import "BPLCPrintManager.h"
#import "ESC_POSPrintManager.h"



@implementation PrintMoudle
@synthesize weexInstance;


WX_EXPORT_METHOD(@selector(print:callback:))
WX_EXPORT_METHOD(@selector(getSaleOrderPrintDefaultState:))
-(void)print:(NSDictionary *)options callback:(WXModuleKeepAliveCallback)callback {
    if([options[@"printType"] isEqualToString:@"print_type_salesOrder"]){
        
        [PrintLabel printESCXiaoShouKaiDanByData:options[@"data"] success:^{
             callback(@{@"result": @"success"}, NO);
        } fail:^{
            if ([[ESC_POSPrintManager sharedManager] isConnected]) {
                //已连接 是因打印失败
                callback(@{@"result": @"error"}, NO);
            } else {
                //因 未连接 而打印失败
                callback(@{@"result": @"disconnected"}, NO);
            }
        }];
        
//        [PrintLabel printXiaoShouKaiDanByData:options[@"data"] success:^{
//           callback(@{@"result": @"success"}, NO);
//        } fail:^{
//            if ([[ESC_POSPrintManager sharedManager] isConnected]) {
//                //已连接 是因打印失败
//                callback(@{@"result": @"error"}, NO);
//            } else {
//               //因 未连接 而打印失败
//                callback(@{@"result": @"disconnected"}, NO);
//            }
//
//
//
//        }];
    }
    if([options[@"printType"] isEqualToString:@"print_type_salesReturnOrder"]){
        
        [PrintLabel printESCXiaoShouTuiHuoKaiDanByData:options[@"data"] success:^{
            callback(@{@"result": @"success"}, NO);
        } fail:^{
            if ([[ESC_POSPrintManager sharedManager] isConnected]) {
                //已连接 是因打印失败
                callback(@{@"result": @"error"}, NO);
            } else {
                //因 未连接 而打印失败
                callback(@{@"result": @"disconnected"}, NO);
            }
        }];
        
        
        
//        [PrintLabel printXiaoShouTuiHuoKaiDanByData:options[@"data"] success:^{
//            
//        } fail:^{
//            if ([[BPLCPrintManager sharedManager] isConnected]) {
//                //已连接 是因打印失败
//                callback(@{@"result": @"error"}, NO);
//            } else {
//                //因 未连接 而打印失败
//                callback(@{@"result": @"disconnected"}, NO);
//            }
//        }];
    }
}


-(void)getSaleOrderPrintDefaultState:(WXKeepAliveCallback)callback {
    NSString *state = [[NSUserDefaults standardUserDefaults] stringForKey:@"PrintDefaultState"];
    if ([state isEqualToString:@"1"]) {
        callback(@{@"result": @"success", @"data": @{@"state": @"1"}}, NO);
    } else {
        callback(@{@"result": @"success", @"data": @{@"state": @"0"}}, NO);
    }
}

@end

//
//  PrintManager.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/9.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "BPLCPrintManager.h"
#import "ExceptionSDK.h"
#import "GlobalUtil.h"
#import "ESC_POSPrintManager.h"
@interface BPLCPrintManager(){
    PortInfo portInfo;
}
@property (readonly, nonatomic) FactoryConnection *factoryConnection;
@property (readonly, nonatomic) FactoryPrinter *factoryPrinter;
@property (readwrite, nonatomic) Connection* connection;
@property (nonatomic, strong) dispatch_queue_t printQueue;
@property (nonatomic, strong) NSMutableArray *allDeviceKeys;
@end

@implementation BPLCPrintManager
@synthesize factoryConnection = _factoryConnection;
@synthesize factoryPrinter = _factoryPrinter;


+(instancetype)sharedManager{
    static BPLCPrintManager *manger = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manger = [[BPLCPrintManager alloc] init];
        manger.printQueue = dispatch_queue_create("com.merchart.print", DISPATCH_QUEUE_SERIAL);
        //固定死通过蓝牙链接
        memset(&manger->portInfo, 0x00, sizeof(PortInfo));
        manger->portInfo.portType = PORT_TYPE_BLUETOOTH_BLE;
        manger->portInfo.bluetoothBLE.selfSize = sizeof(PortInfoBluetoothBLE);
        manger.connection = [manger.factoryConnection createConnection:&manger->portInfo];
        manger.printWidth = @"56";
        manger.purchasePrintable = @"1";
        
    });
    return manger;
}
#pragma mark - setter
- (FactoryConnection*)factoryConnection{
    if(_factoryConnection == nil){
        _factoryConnection = [[FactoryConnection alloc] init];
    }
    return _factoryConnection;
}

- (FactoryPrinter*)factoryPrinter{
    if(_factoryPrinter == nil){
        _factoryPrinter = [[FactoryPrinter alloc] init];
    }
    return _factoryPrinter;
}



#pragma mark - util
-(void)search:(SearchBlock) searchCallBack{
    
    dispatch_async(_printQueue, ^{
        @try{
//            memset(&portInfo, 0x00, sizeof(PortInfo));
//            portInfo.portType = PORT_TYPE_BLUETOOTH_BLE;
//            portInfo.bluetoothBLE.selfSize = sizeof(PortInfoBluetoothBLE);
//            self.connection = [self.factoryConnection createConnection:&portInfo];
            
            [self.connection setDiscoverDeviceTimeout:2000];
            [self.connection setCreateConectTimeout:1000];
            self.deviceList = [self.connection discoverDevice];
            
            id key;
            EAAccessory *value;
            self.allDeviceKeys = [self.deviceList allKeys].mutableCopy;
            self.residueDeviceKeys = [NSMutableArray array];
            for(int index = 0; index < [_allDeviceKeys count]; index++){
                key = [_allDeviceKeys objectAtIndex:index];
                value = [self.deviceList objectForKey:key];

                [_residueDeviceKeys addObject:key];
                NSLog(@"%@", value);
//                [self.deviceNames addObject:[NSString stringWithFormat:@"%@", value.name]];
                
            }
            
            dispatch_async(dispatch_get_main_queue(), ^{
                if (searchCallBack) {
                    searchCallBack(self.connectedDeviceInfo, _residueDeviceKeys);
                }
            });
            

        }@catch (ExceptionSDK *e){
            NSString *msg =[NSString stringWithFormat:@"%@: %@: errorCode=%u(%@)", [e name],[e reason],[e errorCode],[e errorDecsription]];
            [GlobalUtil makeAlertForMessage: msg];
        }@finally{
            
        }
        
    });
    
}

-(void)connect:(id)deviceKey success:(dispatch_block_t) successCallBack fail:(dispatch_block_t)failCallBack {
    //调用connect 前需改变 portInfo
    NSMutableString *connectMsg = nil;
    @try{
        NSString *value = [self.deviceList objectForKey:deviceKey];
        self->portInfo.portType = PORT_TYPE_BLUETOOTH_BLE;
        self->portInfo.bluetoothBLE.selfSize = sizeof(PortInfoBluetoothBLE);
        strcpy(self->portInfo.bluetoothBLE.deviceName, [(NSString*)value UTF8String]);
        
        [self.connection connect:&portInfo];
        self.printer = [self.factoryPrinter createPrinter:self.connection printerLanguage:PRINTER_LANGUAGE_BPLC];
        [[self.printer labelEdit] setStringEncoding:CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000)];
        self.connectedDeviceInfo = @{@"key" : deviceKey, @"name": [NSString stringWithFormat:@"%@ %@", value, deviceKey]};
//       __block NSString *value1 = nil;
//        [self.residueDeviceKeys enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//            if ([obj isEqualToString:deviceKey]) {
//                value1 = obj;
//                *stop = YES;
//            }
//        }];
//        if (value) {
//            [self.residueDeviceKeys removeObject:value1];
//        }
        
        
        [self.residueDeviceKeys removeObject:deviceKey];
        
        
        connectMsg = [NSMutableString stringWithFormat:@"连接成功!"];
        if (successCallBack) {
            successCallBack();
        }
    }@catch (ExceptionSDK *e){
        connectMsg = [NSMutableString stringWithFormat:@"连接失败,请重试"];
//        NSString *msg =[NSString stringWithFormat:@"%@: %@: errorCode=%u(%@)", [e name],[e reason],[e errorCode],[e errorDecsription]];
        if (failCallBack) { // 没有定义失败要干什么
            failCallBack();
        }
    }@finally{
        [GlobalUtil makeAlertForMessage:connectMsg];
    }
}

-(void)disconnect {
    [self.connection disconnect];
    _connectedDeviceInfo = nil;
    _printer = nil;
    _residueDeviceKeys = nil;
}


-(BOOL)isConnected{
    if (self.connection.isConnected && self.connectedDeviceInfo && [ESC_POSPrintManager sharedManager].bluetoothState == CBManagerStatePoweredOn) {
        return YES;
    }
    _printer = nil;
    _residueDeviceKeys = nil;
    _connectedDeviceInfo = nil;
    return NO;
}

-(NSString *)findDiviceForKey:(NSString *) key{
    return [NSString stringWithFormat:@"%@ %@", [self.deviceList objectForKey:key], key];
}











@end

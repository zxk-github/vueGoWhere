//
//  PrintControlViewController.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/10.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "PrintControlViewController.h"
#import "PrintControlTitleCell.h"
#import "ReceiptInfoCell.h"
#import "CurrentConnectCell.h"
#import "OperationTipsCell.h"
#import "PageSizeCell.h"

#import "BPLCPrintManager.h"
#import "GlobalUtil.h"
#import "ESC_POSPrintManager.h"
#import "UINavigationController+FDFullscreenPopGesture.h"


@interface PrintControlViewController ()<UITableViewDelegate, UITableViewDataSource, ESC_POSPrintManagerDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) NSMutableArray<NSArray<NSDictionary<NSString *, NSString*>*>*> *dataSource;
@property (strong, nonatomic) BPLCPrintManager *printManger;
@property (strong, nonatomic) ESC_POSPrintManager *escPrintManger;
@end

@implementation PrintControlViewController

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.escPrintManger = [ESC_POSPrintManager sharedManager];
    self.escPrintManger.delegate = self;
    self.fd_prefersNavigationBarHidden = NO;
    self.title = @"打印设置";
//    self.printManger = [BPLCPrintManager sharedManager];
    //右边的搜索设备按钮
    UIButton *rightBarButton = [UIButton buttonWithType:UIButtonTypeSystem];
    rightBarButton.tintColor = [UIColor whiteColor];
    rightBarButton.frame = CGRectMake(0, 0, 70, 30);
    rightBarButton.layer.cornerRadius = 3;
    rightBarButton.layer.masksToBounds = YES;
    rightBarButton.layer.borderWidth = 1;
    rightBarButton.layer.borderColor = [UIColor whiteColor].CGColor;
    [rightBarButton setTitle:@" 搜索设备 " forState:UIControlStateNormal];
    [rightBarButton addTarget:self action:@selector(handleSearch:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightBarButton];

    
    [_tableView registerNib:[UINib nibWithNibName:@"PrintControlTitleCell" bundle:nil] forCellReuseIdentifier:@"PrintControlTitleCell"];
    [_tableView registerNib:[UINib nibWithNibName:@"PageSizeCell" bundle:nil] forCellReuseIdentifier:@"PageSizeCell"];
    [_tableView registerNib:[UINib nibWithNibName:@"ReceiptInfoCell" bundle:nil] forCellReuseIdentifier:@"ReceiptInfoCell"];
    [_tableView registerNib:[UINib nibWithNibName:@"CurrentConnectCell" bundle:nil] forCellReuseIdentifier:@"CurrentConnectCell"];
    [_tableView registerNib:[UINib nibWithNibName:@"OperationTipsCell" bundle:nil] forCellReuseIdentifier:@"OperationTipsCell"];

    
    // 显示数据
//    [self processBPLCDataByCurrent:_printManger.isConnected ? _printManger.connectedDeviceInfo : nil residue:_printManger.residueDeviceKeys];
    
    [self processESCDataByCurrent:_escPrintManger.currentDevice residue:_escPrintManger.residueDevice];
   
}

//处理数据 BPLC新北洋
-(void)processBPLCDataByCurrent:(NSDictionary *)current residue:(NSArray *)residue{
    NSArray *currentConnect =  currentConnect = @[@{@"cellID": @"PrintControlTitleCell",@"title": @"已连接设备"}];;
    NSArray *residueList = @[@{@"cellID": @"PrintControlTitleCell", @"title": @"未连接设备"}];;
    if (current) {
        NSString *name = current[@"name"];
        currentConnect = @[@{@"cellID": @"PrintControlTitleCell", @"title": @"已连接设备"}, @{@"printerName": name, @"cellID": @"CurrentConnectCell", @"connectState": @"1", @"key": current }];
    }
    if (residue) {
        NSMutableArray *tempArr = @[].mutableCopy;
        [tempArr addObject:@{@"cellID": @"PrintControlTitleCell", @"title": @"未连接设备"}];
        [residue enumerateObjectsUsingBlock:^(NSString *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSString *name = [self.printManger findDiviceForKey: obj];
            NSDictionary *tempDic = @{@"printerName": name, @"cellID": @"CurrentConnectCell", @"connectState": @"0", @"key": obj};
            [tempArr addObject:tempDic];

        }];
        residueList = tempArr;
    }
    self.dataSource = @[
                    @[@{@"switchState": _printManger.purchasePrintable, @"selectWidth": _printManger.printWidth, @"cellID": @"ReceiptInfoCell"}.mutableCopy],
                    currentConnect,
                    residueList,
                    @[@{@"cellID": @"OperationTipsCell"}]
                    ].mutableCopy;
    [self.tableView reloadData];
}


// esc 指令集的其他打印机
-(void)processESCDataByCurrent:(CBPeripheral *)current residue:(NSArray<CBPeripheral*> *)residue{
    NSArray *currentConnect =  currentConnect = @[@{@"cellID": @"PrintControlTitleCell",@"title": @"已连接设备"}];;
    NSArray *residueList = @[@{@"cellID": @"PrintControlTitleCell", @"title": @"未连接设备"}];;
    if (current) {
        NSString *name = [NSString stringWithFormat:@"%@ %@",backStr(current.name) , backStr(current.identifier.UUIDString) ];
        currentConnect = @[@{@"cellID": @"PrintControlTitleCell", @"title": @"已连接设备"}, @{@"printerName": name, @"cellID": @"CurrentConnectCell", @"connectState": @"1", @"key": current }];
    }
    if (residue) {
        NSMutableArray *tempArr = @[].mutableCopy;
        [tempArr addObject:@{@"cellID": @"PrintControlTitleCell", @"title": @"未连接设备"}];
        [residue enumerateObjectsUsingBlock:^(CBPeripheral *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSString *name = [NSString stringWithFormat:@"%@ %@", backStr(obj.name) , backStr(obj.identifier.UUIDString) ];
            NSDictionary *tempDic = @{@"printerName": name, @"cellID": @"CurrentConnectCell", @"connectState": @"0", @"key": obj};
            [tempArr addObject:tempDic];
            
        }];
        residueList = tempArr;
    }
    self.dataSource = @[
                        @[@{@"switchState": _escPrintManger.purchasePrintable, @"cellID": @"ReceiptInfoCell"}, @{@"cellID": @"PageSizeCell", @"selectWidth": _escPrintManger.printWidth}],
                        currentConnect,
                        residueList,
                        @[@{@"cellID": @"OperationTipsCell"}]
                        ].mutableCopy;
    [self.tableView reloadData];

}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//搜索
-(void)handleSearch:(UIButton *)btn {
    if([ESC_POSPrintManager sharedManager].bluetoothState == CBManagerStatePoweredOff){
        [GlobalUtil makeAlertForMessage:@"请打先开手机蓝牙"];
        return;
    }
    
    
    //bplc 新北洋
//    [GlobalUtil showHudForView:self.view message:@"请稍后"];
//    __weak PrintControlViewController *weakSelf = self;
//    [self.printManger search:^(NSDictionary *current, NSArray *residue) {
//        [GlobalUtil hudDismissForView:self.view];
//        [weakSelf processBPLCDataByCurrent:current residue:residue];
//    }];
    //esc 其他
    [GlobalUtil showHudForView:self.view message:@"请稍后"];
    [self.escPrintManger scan];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [GlobalUtil hudDismissForView:self.view];
    });
}
#pragma mark - takeView
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return _dataSource.count;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [_dataSource[section] count];
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 10;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0.01;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:_dataSource[indexPath.section][indexPath.row][@"cellID"] forIndexPath:indexPath];
    if ([cell conformsToProtocol:@protocol(SetCellData)]) {
        [cell performSelector:@selector(setCellData:) withObject:_dataSource[indexPath.section][indexPath.row]];
    }

    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if ((indexPath.section == 2) && indexPath.row > 0) {
        //链接 bplc
//        [_printManger disconnect];
//        NSString *key = _dataSource[indexPath.section][indexPath.row][@"key"];
//        __weak PrintControlViewController *weakSelf = self;
//        [GlobalUtil showHudForView:self.view message:@"请稍后"];
//        [_printManger connect:key success:^{
//            [GlobalUtil hudDismissForView:self.view];
//            [weakSelf handleSearch:nil];
//        } fail:^{
//            [GlobalUtil hudDismissForView:self.view];
//        }];
//链接esc
        [GlobalUtil showHudForView:self.view message:@"请稍后"];
        CBPeripheral *perConnect = _escPrintManger.residueDevice[indexPath.row - 1];
        [_escPrintManger disconnect];
        [_escPrintManger connect:perConnect success: ^{
            [GlobalUtil hudDismissForView:self.view];
            [GlobalUtil makeAlertForMessage:@"连接成功"];
        }];
        
    }
    if (indexPath.section == 1) {
        //断开链接 bplc
//        [_printManger disconnect];
//        [self handleSearch:nil];
        //断开 esc
        [_escPrintManger disconnect];
        
    }
}
#pragma mark - esc
-(void)findDeviceCurrent:(CBPeripheral *)current residue:(NSArray<CBPeripheral *> *)residue{
    NSLog(@"current:----%@ residue:-----%@",current, residue);
    [self processESCDataByCurrent:current residue:residue];
}
-(void)didUpdateConnectState:(ESC_ConnectionState)state{
    switch (state) {
        case connectFail:
        {
            
        }
            break;
        case connectSuccess:
        {
            //刷新table
            [self processESCDataByCurrent:_escPrintManger.currentDevice residue:_escPrintManger.residueDevice];
        }
            break;
        case disconnected:
        {
            //刷新table
            [self processESCDataByCurrent:_escPrintManger.currentDevice residue:_escPrintManger.residueDevice];
        }
            break;
            
        default:
            break;
    }
}
-(void)didUpdateBlueToothState:(CBManagerState)state{
    switch (state) {
        case CBManagerStateResetting:
            NSLog(@"Resetting");
            break;
        case CBManagerStateUnsupported:
            NSLog(@"Unsupported");
            break;
        case CBManagerStateUnauthorized:
            NSLog(@"Unauthorized");
            break;
        case CBManagerStatePoweredOff:{
    
        }
            NSLog(@"PoweredOff");
            break;
        case CBManagerStatePoweredOn:
            NSLog(@"PoweredOn");
            break;
            
        default:
            break;
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

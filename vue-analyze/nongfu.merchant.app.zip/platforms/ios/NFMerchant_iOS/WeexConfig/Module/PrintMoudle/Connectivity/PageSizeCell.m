//
//  PageSizeCell.m
//  NFMerchant_iOS
//
//  Created by 胡鹏飞 on 2018/5/30.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "PageSizeCell.h"
#import "GlobalUtil.h"
@interface PageSizeCell()
@property (weak, nonatomic) IBOutlet UIButton *widthBtn1;
//@property (weak, nonatomic) IBOutlet UIButton *widthBtn2;
@property (weak, nonatomic) IBOutlet UIButton *widthBtn3;

@end
@implementation PageSizeCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    [@[_widthBtn1, _widthBtn3] enumerateObjectsUsingBlock:^(UIButton *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        obj.layer.cornerRadius = 3;
        obj.layer.masksToBounds = YES;
        obj.layer.borderWidth = 1;
        obj.layer.borderColor = [UIColor lightGrayColor].CGColor;
    }];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (IBAction)widthBtnClick:(UIButton *)sender {
    [@[_widthBtn1, _widthBtn3] enumerateObjectsUsingBlock:^(UIButton *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        
        if (obj == sender) {
            obj.selected = YES;
            [sender setBackgroundColor:colorFromHex(0xF6450B)];
        } else {
            obj.selected = NO;
            [obj setBackgroundColor:[UIColor whiteColor]];
        }
    }];
    
    
    
}


-(void)setCellData:(id)data{
    if ([data isKindOfClass:[NSDictionary class]]) {
        _data = data;
        NSInteger tag = [[(NSDictionary *)data valueForKey:@"selectWidth"] integerValue];
        UIButton *selectBtn = [self.contentView viewWithTag:tag];
        selectBtn.selected = YES;
        [selectBtn setBackgroundColor:colorFromHex(0xF6450B)];

        
    }
}

@end

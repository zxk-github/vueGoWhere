//
//  PrintControlTitleCell.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/10.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SetCellData.h"
@interface PrintControlTitleCell : UITableViewCell<SetCellData>
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@end

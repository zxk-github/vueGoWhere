//
//  ReceiptInfoCell.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/10.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SetCellData.h"

typedef void(^SwitchBlock)(BOOL on);

@interface ReceiptInfoCell : UITableViewCell<SetCellData>
@property (nonatomic, strong) NSMutableDictionary *data;
@property (nonatomic, copy) SwitchBlock switchValueChange;
@end

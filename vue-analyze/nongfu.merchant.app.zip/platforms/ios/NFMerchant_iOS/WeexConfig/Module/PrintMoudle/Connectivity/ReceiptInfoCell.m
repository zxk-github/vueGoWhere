//
//  ReceiptInfoCell.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/10.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "ReceiptInfoCell.h"
#import "GlobalUtil.h"
@interface ReceiptInfoCell()
@property (weak, nonatomic) IBOutlet UIButton *openSwitch;

@end

@implementation ReceiptInfoCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code

}
- (IBAction)clickSwitch:(id)sender {
    _openSwitch.selected = !_openSwitch.selected;
//    [_data setObject: _openSwitch.selected ? @"1" : @"0" forKey:@"switchState"];
    
    [[NSUserDefaults standardUserDefaults] setObject:_openSwitch.selected ? @"1" : @"0" forKey:@"PrintDefaultState"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    
    
    
//    if (self.switchValueChange) {
//        self.switchValueChange(_openSwitch.selected);
//    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setCellData:(id)data{
    if ([data isKindOfClass:[NSDictionary class]]) {
        _data = data;
        
        NSString *state = [[NSUserDefaults standardUserDefaults] stringForKey:@"PrintDefaultState"];
        if ([state isEqualToString:@"1"]) {
            _openSwitch.selected = YES;
        } else {
            _openSwitch.selected = NO;
        }
        
    }
}
@end

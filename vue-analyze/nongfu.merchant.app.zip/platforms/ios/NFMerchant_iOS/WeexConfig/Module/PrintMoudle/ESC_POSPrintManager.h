//
//  ESC_POSPrintManager.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/16.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

typedef NS_ENUM(NSUInteger, ESC_ConnectionState) {
    connectSuccess,
    disconnected,
    connectFail
};
typedef void(^HLWriteToCharacteristicBlock)(CBCharacteristic *characteristic, NSError *error);


@protocol ESC_POSPrintManagerDelegate

-(void)findDeviceCurrent:(CBPeripheral *)current residue:(NSArray<CBPeripheral*> *)residue;
//-(void)connectSuccess:(CBPeripheral *)currentDevice;
//-(void)disconnectSuccess;
-(void)didUpdateConnectState:(ESC_ConnectionState)state;
-(void)didUpdateBlueToothState:(CBManagerState)state;


@end

@interface ESC_POSPrintManager : NSObject
@property (nonatomic, assign) CBManagerState bluetoothState;
@property (nonatomic, strong) NSMutableArray<CBPeripheral*> *residueDevice;//未连接的设备name
@property (nonatomic, strong) CBPeripheral *currentDevice;// 当前已连接
@property (nonatomic, weak) id<ESC_POSPrintManagerDelegate> delegate;
@property (nonatomic, strong) NSString *printWidth;
@property (nonatomic, assign) NSInteger printPointsCount;//对应不同宽度纸有一行几个点
@property (nonatomic, strong) NSString *purchasePrintable;//进货开单打印开关

+(instancetype)sharedManager;
-(void)connect:(id)deviceKey success:(dispatch_block_t) successCallBack;
-(void)scan;
-(void)disconnect;
- (void)writeValue:(NSData *)data completionBlock:(HLWriteToCharacteristicBlock)completionBlock;
-(BOOL)isConnected;
@end

//
//
//
//
//  Created by lbxia on 15/10/21.
//  Copyright © 2015年 lbxia. All rights reserved.
//

#import "ScanQRViewController.h"
//#import "CreateBarCodeViewController.h"
//#import "ScanResultViewController.h"
#import <LBXScan/LBXScanVideoZoomView.h>
#import "LBXPermission.h"
#import "LBXPermissionSetting.h"
#import "GlobalUtil.h"
#import <UMAnalytics/MobClick.h>
@interface ScanQRViewController ()
@property (nonatomic, strong) LBXScanVideoZoomView *zoomView;
@property (nonatomic, strong) UIButton *flashBtn;
@property (nonatomic, strong) NSDictionary *selectDataInfo;
@end

@implementation ScanQRViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
//    self.pereviewFrame = CGRectMake(0, 0, UI_SCREEN_WIDTH, 300);
    
    if ([self respondsToSelector:@selector(setEdgesForExtendedLayout:)]) {
        
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    self.view.backgroundColor = [UIColor blackColor];
    
    //设置扫码后需要扫码图像
    self.isNeedScanImage = YES;
    
    
    
    
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    
    
    [self drawTopItems];
    [self drawTitle];
    [self.view bringSubviewToFront:_topTitle];
    [self drawBottomBtn];
    
    
}

//绘制扫描区域
- (void)drawTitle
{
    if (!_topTitle)
    {
        self.topTitle = [[UILabel alloc]init];
        _topTitle.bounds = CGRectMake(0, 0, 200, 20);
        _topTitle.center = CGPointMake(CGRectGetWidth(self.view.frame)/2, 130);
        
//        3.5inch iphone
        if ([UIScreen mainScreen].bounds.size.height <= 568 )
        {
            _topTitle.center = CGPointMake(CGRectGetWidth(self.view.frame)/2, 48);
//            _topTitle.font = [UIFont systemFontOfSize:14];
        }
        
         _topTitle.font = [UIFont systemFontOfSize:12];
        _topTitle.textAlignment = NSTextAlignmentCenter;
        _topTitle.numberOfLines = 0;
        _topTitle.text = @"请将条码/二维码放入框内";
        _topTitle.textColor = [UIColor whiteColor];
        _topTitle.backgroundColor = RGBA(0, 0, 0, 0.5);
        _topTitle.layer.masksToBounds = YES;
        _topTitle.layer.cornerRadius = 10;
        [self.view addSubview:_topTitle];
    }    
}


//绘制扫描区域
- (void)drawScanView
{
#ifdef LBXScan_Define_UI
    
    if (!self.qRScanView)
    {
        CGRect rect = self.view.frame;
        rect.origin = CGPointMake(0, 0);
//        rect = CGRectMake(0, 0, UI_SCREEN_WIDTH, 300);
        
        self.qRScanView = [[LBXScanView alloc]initWithFrame:rect style:self.style];
        
        [self.view addSubview:self.qRScanView];
    }
    
    if (!self.cameraInvokeMsg) {
        
        //        _cameraInvokeMsg = NSLocalizedString(@"wating...", nil);
    }
    
    [self.qRScanView startDeviceReadyingWithText:self.cameraInvokeMsg];
#endif
}


- (void)tap
{
    _zoomView.hidden = !_zoomView.hidden;
}

- (void)drawTopItems
{

    UIButton *libiaryBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [libiaryBtn setTintColor:[UIColor whiteColor]];
    [libiaryBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [libiaryBtn setTitle:@"相册" forState:UIControlStateNormal];
    libiaryBtn.backgroundColor = RGBA(0, 0, 0, 0.7);
    libiaryBtn.layer.masksToBounds = YES;
    libiaryBtn.layer.cornerRadius = 17.5;
    libiaryBtn.frame = CGRectMake(0, 0, 30, 30);
    libiaryBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    [libiaryBtn addTarget:self action:@selector(openPhoto) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    UIButton *flashLightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [flashLightBtn setTintColor:[UIColor whiteColor]];
    [flashLightBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    flashLightBtn.backgroundColor = RGBA(0, 0, 0, 0.7);
    flashLightBtn.layer.masksToBounds = YES;
    flashLightBtn.layer.cornerRadius = 17.5;
    flashLightBtn.frame = CGRectMake(0, 0, 30, 30);
    flashLightBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    [flashLightBtn setImage:[UIImage imageNamed:@"flash_close"] forState:UIControlStateNormal];
    [flashLightBtn setImage:[UIImage imageNamed:@"flash_open"] forState:UIControlStateSelected];
    [flashLightBtn addTarget:self action:@selector(openOrCloseFlash) forControlEvents:UIControlEventTouchUpInside];
    _flashBtn = flashLightBtn;
    
    UIStackView *stackView = [[UIStackView alloc] initWithArrangedSubviews:@[libiaryBtn, flashLightBtn]];
    stackView.axis = UILayoutConstraintAxisHorizontal;
    stackView.alignment = UIStackViewAlignmentFill;
    stackView.distribution = UIStackViewDistributionFillEqually;
    stackView.spacing = 20;
    stackView.frame = CGRectMake(UI_SCREEN_WIDTH - 90 - 20, 40, 90, 36);
    
    [self.view addSubview:stackView];

    UIButton *backBtn = [[UIButton alloc] initWithFrame:CGRectMake(10, 40, 30, 30)];
    [backBtn setImage:[UIImage imageNamed:@"ic_back"] forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(handleBack:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:backBtn];
    
}

-(void)drawBottomBtn{
    
    
    if(!_bottomItemsView & _shouldShowBottomBtns){
        _bottomItemsView = [[UIView alloc] initWithFrame:CGRectMake(0, UI_SCREEN_HEIGHT - UI_TabbarSafeBottomMargin - 50, UI_SCREEN_WIDTH, 50)];
        
        UIButton *inBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [inBtn setTintColor:[UIColor whiteColor]];
        [inBtn setBackgroundColor: RGBA(0, 0, 0, 0.7)];
        if ([[_typeArr[0] valueForKey:@"selected"] boolValue]) {
            [inBtn setBackgroundColor: colorFromHex(0x01BD73)];
            _selectDataInfo = _typeArr[0];
        }
        [inBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [inBtn setTitle:@"进货开单" forState:UIControlStateNormal];
        //    inBtn.titleLabel.font
        inBtn.tag = 100;
        inBtn.frame = CGRectMake(0, 0, UI_SCREEN_WIDTH / 2.0, 50);
        [inBtn addTarget:self action:@selector(inBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        
        [_bottomItemsView addSubview:inBtn];
        
        
        UIButton *outBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [outBtn setTintColor:[UIColor whiteColor]];
        [outBtn setBackgroundColor: RGBA(0, 0, 0, 0.7)];
        if ([[_typeArr[1] valueForKey:@"selected"] boolValue]) {
            [outBtn setBackgroundColor: colorFromHex(0x01BD73)];
            _selectDataInfo = _typeArr[1];
        }
        [outBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [outBtn setTitle:@"销售开单" forState:UIControlStateNormal];
        outBtn.tag = 101;
        //    inBtn.titleLabel.font
        outBtn.frame = CGRectMake(UI_SCREEN_WIDTH / 2.0, 0, UI_SCREEN_WIDTH / 2.0, 50);
        [outBtn addTarget:self action:@selector(outBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        [_bottomItemsView addSubview:outBtn];
        
        [self.view addSubview:_bottomItemsView];
    }
    
    
    
}



- (void)showError:(NSString*)str
{
    [LBXAlertAction showAlertWithTitle:@"提示" msg:str buttonsStatement:@[@"知道了"] chooseBlock:nil];
}

- (void)scanResultWithArray:(NSArray<LBXScanResult*>*)array
{

    
    if (self.qqScanCallback) {
        self.qqScanCallback(array, _selectDataInfo);
        [self.navigationController popViewControllerAnimated:YES];
    }
    
    //震动提醒
   // [LBXScanWrapper systemVibrate];
    //声音提醒
    //[LBXScanWrapper systemSound];

   
}

- (void)popAlertMsgWithScanResult:(NSString*)strResult
{
    if (!strResult) {
        
        strResult = @"识别失败";
    }
    
    __weak __typeof(self) weakSelf = self;
    [LBXAlertAction showAlertWithTitle:@"扫码内容" msg:strResult buttonsStatement:@[@"知道了"] chooseBlock:^(NSInteger buttonIdx) {
        
        [weakSelf reStartDevice];
    }];
}


-(void) handleBack:(UIButton *)btn {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -底部功能项
//打开相册
- (void)openPhoto
{
    __weak __typeof(self) weakSelf = self;
    [LBXPermission authorizeWithType:LBXPermissionType_Photos completion:^(BOOL granted, BOOL firstTime) {
        if (granted) {
            [weakSelf openLocalPhoto:NO];
        }
        else
        {
            
            UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"提示" message:@"没有相册权限，是前往设置允许app访问相册" preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
            [alertVC addAction:action];
            [self presentViewController:alertVC animated:YES completion:nil];
            
//            [LBXPermissionSetting showAlertToDislayPrivacySettingWithTitle:@"提示" msg:@"没有相册权限，是否前往设置" cancel:@"取消" setting:@"设置"];
        }
    }];
}

//开关闪光灯
- (void)openOrCloseFlash
{
    [super openOrCloseFlash];
   
    _flashBtn.selected = self.isOpenFlash;
}
-(void)inBtnClick:(UIButton *)btn{
    UIButton *outBtn = [_bottomItemsView viewWithTag:101];
    outBtn.backgroundColor = RGBA(0, 0, 0, 0.7);
    btn.backgroundColor = colorFromHex(0x01BD73);
    _selectDataInfo = _typeArr[0];
    [MobClick event:@"index_scan_purchase"];
}
-(void)outBtnClick:(UIButton *)btn{
    UIButton *inBtn = [_bottomItemsView viewWithTag:100];
    inBtn.backgroundColor = RGBA(0, 0, 0, 0.7);
    btn.backgroundColor = colorFromHex(0x01BD73);
    _selectDataInfo = _typeArr[1];
    [MobClick event:@"index_scan_sale"];
}


#pragma mark -底部功能项


//- (void)myQRCode
//{
//    CreateBarCodeViewController *vc = [CreateBarCodeViewController new];
//    [self.navigationController pushViewController:vc animated:YES];
//}



@end

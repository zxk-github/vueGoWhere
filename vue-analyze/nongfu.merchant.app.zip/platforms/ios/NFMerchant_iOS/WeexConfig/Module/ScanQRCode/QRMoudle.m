//
//  QRMoudle.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/2/1.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "QRMoudle.h"
#import "ScanQRViewController.h"
#import <LBXScan/LBXScanViewStyle.h>
#import "SystemPermissionsManager.h"
#import "ContactPickerContactViewController.h"
#import "PrintControlViewController.h"
#if DEVELOPMENT
#import "NFMerchant_iOSDev-Swift.h"
#else
#import "NFMerchant_iOS-Swift.h"
#endif
#import <UMAnalytics/MobClick.h>
@interface QRMoudle() <LBXScanViewControllerDelegate>
@property (nonatomic, strong) NSDictionary *params;
@end


@implementation QRMoudle

//WX_EXPORT_METHOD(@selector(qrcode:))
WX_EXPORT_METHOD(@selector(qrcode:callback:))
@synthesize weexInstance;

#pragma mark -模仿qq界面
+ (LBXScanViewStyle*)qqStyle
{
    //设置扫码区域参数设置

    //创建参数对象
    LBXScanViewStyle *style = [[LBXScanViewStyle alloc]init];

    //矩形区域中心上移，默认中心点为屏幕中心点
    style.centerUpOffset = 20;

    //扫码框周围4个角的类型,设置为外挂式
    style.photoframeAngleStyle = LBXScanViewPhotoframeAngleStyle_Inner;

    //扫码框周围4个角绘制的线条宽度
    style.photoframeLineW = 6;

    //扫码框周围4个角的宽度
    style.photoframeAngleW = 24;

    //扫码框周围4个角的高度
    style.photoframeAngleH = 24;

    //扫码框内 动画类型 --线条上下移动
    style.anmiationStyle = LBXScanViewAnimationStyle_LineMove;

    //线条上下移动图片
    style.animationImage = [UIImage imageNamed:@"qrcode_scan_light_green"];

    style.xScanRetangleOffset = 44;
//    style.whRatio = 1.3;
    style.colorRetangleLine = [UIColor clearColor];
    style.notRecoginitonArea = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.6];
    
    /*
    //设置扫码区域参数设置
    
    //创建参数对象
    LBXScanViewStyle *style = [[LBXScanViewStyle alloc]init];
    
    //矩形区域中心上移，默认中心点为屏幕中心点
    style.centerUpOffset = 44;
    
    //扫码框周围4个角的类型,设置为外挂式
    style.photoframeAngleStyle = LBXScanViewPhotoframeAngleStyle_Outer;
    
    //扫码框周围4个角绘制的线条宽度
    style.photoframeLineW = 6;
    
    //扫码框周围4个角的宽度
    style.photoframeAngleW = 24;
    
    //扫码框周围4个角的高度
    style.photoframeAngleH = 24;
    
    //扫码框内 动画类型 --线条上下移动
    style.anmiationStyle = LBXScanViewAnimationStyle_LineMove;
    
    //线条上下移动图片
    style.animationImage = [UIImage imageNamed:@"CodeScan.bundle/qrcode_scan_light_green"];
    
    style.notRecoginitonArea = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.6];
    */
    
    return style;
}


-(void)qrcode:(NSDictionary *)options callback:(WXKeepAliveCallback)callback{
    
//    PickPointViewController *pickVc = [[PickPointViewController alloc] init];
    
//    [(UINavigationController *)[[[UIApplication sharedApplication] keyWindow] rootViewController] pushViewController:pickVc animated:YES];
    
    
    ScanQRViewController *vc = [[ScanQRViewController alloc] init];
    vc.qqScanCallback = ^(NSArray<LBXScanResult *> *results, NSDictionary *typeInfo) {
        if (results && results.count > 0){
            callback(@{@"result": @"success",@"data":@{@"type": [typeInfo objectForKey:@"type"] ? [typeInfo objectForKey:@"type"] : @"", @"qrcode": results.firstObject.strScanned}}, NO);
            
        } else {
            callback(@{@"result": @"error",@"data":@{}}, NO);
        }
        
    };
    if ([options[@"showTypes"] boolValue]) {
        vc.shouldShowBottomBtns = YES;
        vc.typeArr = options[@"types"];
    } else {
        vc.shouldShowBottomBtns = NO;
    }
    
    vc.style = [QRMoudle qqStyle];
    vc.fd_prefersNavigationBarHidden = YES;
    vc.libraryType = SLT_Native;
    [SystemPermissionsManager requestAuthorization:KAVMediaTypeVideo completionHandler:^(BOOL granted) {
        if (granted) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [(UINavigationController *)[[[UIApplication sharedApplication] keyWindow] rootViewController] pushViewController:vc animated:YES];
            });
        } else {
            callback(@{@"result": @"unauthorized",@"data":@{}}, NO);;
        }
        
    }];
     
    
}





#pragma mark - scan result
- (void)scanResultWithArray:(NSArray<LBXScanResult*>*)array {
    if (array.count > 0 && self.params) {
        [weexInstance fireGlobalEvent:@"NongheNativeCallback" params:@{@"status":@"success", @"execution":self.params[@"execution"],@"result":@{@"res": @{@"result": array.firstObject.strScanned}} }];
    } else {
        [weexInstance fireGlobalEvent:@"NongheNativeCallback" params:@{@"status":@"fail", @"execution":self.params[@"execution"],@"result":@"" }];
    }
}















@end

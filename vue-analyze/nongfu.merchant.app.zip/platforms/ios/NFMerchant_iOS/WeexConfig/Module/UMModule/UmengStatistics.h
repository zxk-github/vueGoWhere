//
//  UmengStatistics.h
//  NFMerchant_iOS
//
//  Created by 胡鹏飞 on 2018/5/31.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WeexSDK/WeexSDK.h>
@interface UmengStatistics : NSObject<WXModuleProtocol>

@end

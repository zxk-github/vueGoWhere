//
//  UIViewController+UM.m
//  NFMerchant_iOS
//
//  Created by 胡鹏飞 on 2018/7/3.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "UIViewController+UM.h"
#import <UMCommon/UMCommon.h>
#import <UMAnalytics/MobClick.h>
#import <UMCommonLog/UMCommonLogHeaders.h>
#import <objc/objc.h>
#import <objc/runtime.h>
#import "NativeWXExchangeBridge.h"
#if DEVELOPMENT
#import "NFMerchant_iOSDev-Swift.h"
#else
#import "NFMerchant_iOS-Swift.h"
#endif
//友盟统计
@implementation UIViewController (UM)

-(NSString *)pageType{
    return objc_getAssociatedObject(self, _cmd) ? objc_getAssociatedObject(self, _cmd) : @"native";
}
-(void)setPageType:(NSString *)pageType{
    objc_setAssociatedObject(self, @selector(pageType), pageType, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        Class class = [self class];
        SEL originalSelector = @selector(viewWillAppear:);
        SEL swizzledSelector = @selector(mrc_viewWillAppear:);
        Method originalMethod = class_getInstanceMethod(class, originalSelector);
        Method swizzledMethod = class_getInstanceMethod(class, swizzledSelector);
        BOOL success = class_addMethod(class, originalSelector, method_getImplementation(swizzledMethod), method_getTypeEncoding(swizzledMethod));
        if (success) {//添加成功
            class_replaceMethod(class, swizzledSelector, method_getImplementation(originalMethod), method_getTypeEncoding(originalMethod));
        } else {//已存在自己写的方法则会添加失败
            method_exchangeImplementations(originalMethod, swizzledMethod);
        }
        
        SEL originalSelectorDisappear = @selector(viewWillDisappear:);
        SEL swizzledSelectorDisappear = @selector(mrc_viewWillDisappear:);
        Method originalMethodDisappear = class_getInstanceMethod(class, originalSelectorDisappear);
        Method swizzledMethodDisappear = class_getInstanceMethod(class, swizzledSelectorDisappear);
        BOOL successDisappear = class_addMethod(class, originalSelectorDisappear, method_getImplementation(swizzledMethodDisappear), method_getTypeEncoding(swizzledMethodDisappear));
        if (successDisappear) {//添加成功 则将实现替换为 原有的 viewWillDisappear 的实现
            class_replaceMethod(class, swizzledSelectorDisappear, method_getImplementation(originalMethodDisappear), method_getTypeEncoding(originalMethodDisappear));
        } else {//已存在自己写的方法则会添加失败 交换实现
            method_exchangeImplementations(originalMethodDisappear, swizzledMethodDisappear);
        }
        
    });
}
#pragma mark - Method Swizzling
- (void)mrc_viewWillAppear:(BOOL)animated {
    [self mrc_viewWillAppear:animated];
    NSArray *className = [NSStringFromClass([self class]) componentsSeparatedByString:@"."];
    if (className.lastObject && ([className.lastObject isEqualToString:@"BaseNavigationController"] ||  [className.lastObject isEqualToString:@"AVPlayerViewController"])) {
        return;
    }
    //判断是否是包含weexpage 的vc 是的话 需要调用 begin
    if (className.lastObject && ![self.pageType isEqualToString:@"native"]) {
        //是 weex 页面的话 就特殊处理
        NSString *pageName = [[NativeWXExchangeBridge shardBridge] getPageNameByWXInstance:[(MainHomeViewController *)self instance]];
        if (pageName) {
            [MobClick beginLogPageView: pageName];
        }
    } else {
        //native
        [MobClick beginLogPageView:className.lastObject];
    }
    
    
}

- (void)mrc_viewWillDisappear:(BOOL)animated{
    [self mrc_viewWillDisappear:animated];
    NSArray *className = [NSStringFromClass([self class]) componentsSeparatedByString:@"."];
    //不统计 nav 和 weex组件中用到的 ViewController
    if (className.lastObject && ([className.lastObject isEqualToString:@"BaseNavigationController"] ||  [className.lastObject isEqualToString:@"AVPlayerViewController"])) {
        return;
    }
    //判断是否是包含weexpage 的vc 是的话 需要调用 end
    if (![self.pageType isEqualToString:@"native"]) {
        //是 weex 页面的话 就特殊处理
        NSString *pageName = [[NativeWXExchangeBridge shardBridge] getPageNameByWXInstance:[(MainHomeViewController *)self instance]];
        if (pageName) {
            [MobClick endLogPageView: pageName];
        }
    } else {
        //native
        [MobClick endLogPageView: className.lastObject];
    }
   
}
@end

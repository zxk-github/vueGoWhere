//
//  UIViewController+UM.h
//  NFMerchant_iOS
//
//  Created by 胡鹏飞 on 2018/7/3.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (UM)
//友盟统计
@property (nonatomic, copy) NSString* pageType;
@end

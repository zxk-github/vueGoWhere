//
//  UmengStatistics.m
//  NFMerchant_iOS
//
//  Created by 胡鹏飞 on 2018/5/31.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "UmengStatistics.h"

#import <UMAnalytics/MobClick.h>
#import "NativeWXExchangeBridge.h"
@implementation UmengStatistics
WX_EXPORT_METHOD(@selector(addCustomEvents:options:))
WX_EXPORT_METHOD(@selector(pageStart:))
WX_EXPORT_METHOD(@selector(pageEnd:))
@synthesize weexInstance;
-(void)addCustomEvents:(NSString *)eventId options:(NSArray <NSDictionary <NSString * ,NSString *> *>*)options{
    NSMutableDictionary *attr = @{}.mutableCopy;
    [options enumerateObjectsUsingBlock:^(NSDictionary<NSString *,NSString *> * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [attr setObject:obj[@"value"] forKey:obj[@"key"]];
    }];
    [MobClick event:eventId attributes:attr];
    
}
-(void)pageStart:(NSString *)viewName{
    [MobClick beginLogPageView:viewName];
    [[NativeWXExchangeBridge shardBridge] setInstancePage:viewName forWXInstance:weexInstance];
    
}
-(void)pageEnd:(NSString *)viewName{
    [MobClick endLogPageView:viewName];
}

@end

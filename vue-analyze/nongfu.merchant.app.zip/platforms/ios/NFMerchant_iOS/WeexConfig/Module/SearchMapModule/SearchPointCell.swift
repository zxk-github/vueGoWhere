//
//  SearchPointCell.swift
//  NFMerchant_iOS
//
//  Created by 胡鹏飞 on 2018/6/22.
//  Copyright © 2018年 taobao. All rights reserved.
//

import UIKit

class SearchPointCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var detailLabel: UILabel!
    
    var poi: AMapPOI? {
        willSet(newValue) {
            titleLabel.text = newValue?.name
            detailLabel.text = newValue?.address
        }
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

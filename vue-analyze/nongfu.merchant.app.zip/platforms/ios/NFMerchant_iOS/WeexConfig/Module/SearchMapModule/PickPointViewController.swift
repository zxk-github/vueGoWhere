//
//  PickPointViewController.swift
//  NFMerchant_iOS
//
//  Created by 胡鹏飞 on 2018/6/22.
//  Copyright © 2018年 taobao. All rights reserved.
//

import UIKit

class PickPointViewController: BaseViewController {
    var search: AMapSearchAPI!
//    var mapView: MAMapView!
    @IBOutlet weak var mapView: MAMapView!
    @IBOutlet weak var changeBtn: UIButton!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var detailTextFied: UITextField!
    @IBOutlet weak var submitBtn: UIButton!
    @IBOutlet weak var userLocation: UIButton!
    
    @IBOutlet weak var centerAnnotationView: UIImageView!
    @IBOutlet weak var inputCardBottomConstrant: NSLayoutConstraint!
    
    var isLocated: Bool = false
    var searchPage: Int = 0
    
    var imageLocated: UIImage = #imageLiteral(resourceName: "gpssearchbutton")
    var imageNotLocate: UIImage = #imageLiteral(resourceName: "gpsnormal")

    var searchPoiArray: Array<AMapPOI> = Array()
    var currentCoordinite: CLLocationCoordinate2D?
    var currentGeo :AMapReGeocode?
    
    var isFromSearchPage = false
    
    @objc var didSubmitAddress: ((AMapReGeocode?, String?, Dictionary<String, String>)->Void)?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "门店地址"
        self.fd_prefersNavigationBarHidden = false
        AMapServices.shared().apiKey = "d6a8dc6c0adbba5c37cbf17cbeda5485"
        initSearch()
        initMapView()

        changeBtn.layer.borderWidth = 1;
        changeBtn.layer.borderColor = colorFromHex(0xE9E9E9).cgColor
        changeBtn.layer.cornerRadius = 5;
        changeBtn.layer.masksToBounds = true
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        mapView.bringSubview(toFront: userLocation);
        mapView.bringSubview(toFront: centerAnnotationView);
        
        self.mapView.zoomLevel = 17
        self.mapView.showsUserLocation = true
    }
    
    //Mark - listener
    func addListener() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyBoardWillShow(notify:)), name: Notification.Name.UIKeyboardDidShow, object: nil);
        NotificationCenter.default.addObserver(self, selector: #selector(keyBoardWillHide(notify:)), name: Notification.Name.UIKeyboardWillHide, object: nil);
    }
    
    @objc func keyBoardWillShow(notify: Notification){
        if let userInfo = notify.userInfo {
            let endRect = (userInfo[UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue;
            inputCardBottomConstrant.constant = endRect.size.height
        }
    }
    
    @objc func keyBoardWillHide(notify: Notification){
        inputCardBottomConstrant.constant = 0;
    }
    
    //MARK - init map
    func initSearch() {
        search = AMapSearchAPI()
        search.delegate = self
    }
    
    func initMapView() {
        mapView.delegate = self
        
    }

    func centerAnnotationAnimimate() {
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {() -> Void in
            var center = self.centerAnnotationView.center
            center.y -= 20
            self.centerAnnotationView.center = center
        }, completion: { _ in })
        UIView.animate(withDuration: 0.45, delay: 0, options: .curveEaseIn, animations: {() -> Void in
            var center = self.centerAnnotationView.center
            center.y += 20
            self.centerAnnotationView.center = center
        }, completion: { _ in })
    }
    
    func actionSearchAround(at coordinate: CLLocationCoordinate2D) {
//        GlobalUtil.showHud(for: self.view, message: "请稍候")
        currentCoordinite = coordinate;
        self.searchReGeocode(withCoordinate: coordinate)
        self.searchPoi(withCoordinate: coordinate)
        self.searchPage = 1
        self.centerAnnotationAnimimate()
    }
    func searchPoi(withCoordinate coord: CLLocationCoordinate2D) {
        let request = AMapPOIAroundSearchRequest()
        request.location = AMapGeoPoint.location(withLatitude: CGFloat(coord.latitude), longitude: CGFloat(coord.longitude))
        request.radius = 1000
        request.sortrule = 0
        request.page = self.searchPage
        self.search.aMapPOIAroundSearch(request)
    }
    
    func searchReGeocode(withCoordinate coord: CLLocationCoordinate2D) {
        let request = AMapReGeocodeSearchRequest()
        request.location = AMapGeoPoint.location(withLatitude: CGFloat(coord.latitude), longitude: CGFloat(coord.longitude))
        request.requireExtension = true
        self.search.aMapReGoecodeSearch(request)
    }

    
    func actionLocation() {
        if self.mapView.userTrackingMode == .follow {
            self.mapView.setUserTrackingMode(.none, animated: true)
        }
        else {
            self.searchPage = 1
            self.mapView.setCenter(self.mapView.userLocation.coordinate, animated: true)
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(0.5 * Double(NSEC_PER_SEC)) / Double(NSEC_PER_SEC), execute: {() -> Void in
                // 因为下面这句的动画有bug，所以要延迟0.5s执行，动画由上一句产生
                self.mapView.setUserTrackingMode(.follow, animated: true)
            })
        }
    }
    func setAddress(reGeo: AMapReGeocode) {
        addressLabel.text = reGeo.addressComponent.township + reGeo.addressComponent.streetNumber.street + reGeo.addressComponent.streetNumber.number;
    }
    
    
    
    //Mark - target-action
    
    
    @IBAction func reachUserLocation(_ sender: UIButton) {
        actionLocation()
    }
    
    @IBAction func changeAddress(_ sender: UIButton) {
        let searchVC = SearchPointViewController()
        searchVC.pois = searchPoiArray
        searchVC.city = currentGeo?.addressComponent.city
        searchVC.poiDidSelected = {[weak self]  poi in
            self?.isFromSearchPage = true
            let currentRegion = self?.mapView.region
            let poiCenter = CLLocationCoordinate2D(latitude: CLLocationDegrees(poi.location.latitude), longitude: CLLocationDegrees(poi.location.longitude))
            self?.currentCoordinite = poiCenter
            self?.mapView.setRegion(MACoordinateRegion(center: poiCenter, span: (currentRegion?.span)!), animated: true)
            self?.addressLabel.text = poi.name
            self?.searchReGeocode(withCoordinate: poiCenter)
        }
        self.navigationController?.pushViewController(searchVC, animated: true)
    }
    
    @IBAction func submit(_ sender: UIButton) {
        if let block = didSubmitAddress {
            
            let coord = ["latitude": String(format: "%lf", currentCoordinite?.latitude ?? 0),
                         "longitude": String(format: "%lf", currentCoordinite?.longitude ?? 0),
                         ]
            
            
            block(currentGeo, addressLabel.text, coord)
        }
        self.navigationController?.popViewController(animated: true)
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardDidShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension PickPointViewController: MAMapViewDelegate ,AMapSearchDelegate {
    
    func mapView(_ mapView: MAMapView!, didChange mode: MAUserTrackingMode, animated: Bool) {
        if mode == .none {
            self.userLocation.setImage(self.imageNotLocate, for: .normal)
        }
        else {
            self.userLocation.setImage(self.imageLocated, for: .normal)
        }
    }
    func mapView(_ mapView: MAMapView!, mapWillMoveByUser wasUserAction: Bool) {
        if wasUserAction {//用户移动地图的话 将 isFromSearchPage 变为false
            isFromSearchPage = false
        }
    }
    
    func mapView(_ mapView: MAMapView!, didUpdate userLocation: MAUserLocation!, updatingLocation: Bool) {
        if !updatingLocation {
            return
        }
        if userLocation.location.horizontalAccuracy < 0 {
            return
        }
        // only the first locate used.
        if !self.isLocated {
            self.isLocated = true
            self.mapView.userTrackingMode = .follow
            self.mapView.centerCoordinate = userLocation.location.coordinate
            self.actionSearchAround(at: userLocation.location.coordinate)
        }
    }
    
    
    func mapView(_ mapView: MAMapView!, regionDidChangeAnimated animated: Bool) {
        if !isFromSearchPage && self.mapView.userTrackingMode == .none {
            self.actionSearchAround(at: self.mapView.centerCoordinate)
        }
    }
    
    //MARK:- AMapSearchDelegate
    
    func aMapSearchRequest(_ request: Any!, didFailWithError error: Error!) {
        GlobalUtil.hudDismiss(for: self.view)
        print("error :\(error)")
    }
    
    /* POI 搜索回调. */
    func onPOISearchDone(_ request: AMapPOISearchBaseRequest!, response: AMapPOISearchResponse!) {
        
        self.searchPoiArray.removeAll()
        self.searchPoiArray.append(contentsOf: response.pois)

    }
    
    func onReGeocodeSearchDone(_ request: AMapReGeocodeSearchRequest!, response: AMapReGeocodeSearchResponse!) {
//        GlobalUtil.hudDismiss(for: self.view)
        currentGeo = response.regeocode;
        if !isFromSearchPage {
            setAddress(reGeo: response.regeocode)
        }
        
        
    }
    
    
    
    
}

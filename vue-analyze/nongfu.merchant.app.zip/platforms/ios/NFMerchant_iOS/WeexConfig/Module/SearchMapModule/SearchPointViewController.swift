//
//  SearchPointViewController.swift
//  NFMerchant_iOS
//
//  Created by 胡鹏飞 on 2018/6/22.
//  Copyright © 2018年. All rights reserved.
//

import UIKit

class SearchPointViewController: BaseViewController {

    @IBOutlet weak var naviViewHeightContraint: NSLayoutConstraint!
    
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var searchBtn: UIButton!
    var pois:[AMapPOI] = []
    var selected: AMapPOI?
    
    var poiDidSelected: ((AMapPOI)->Void)?
    var searchPage = 0
    
    var debounceSearch: (()->Void)?
    
    var city: String?
    
    
    
    
    private var search: AMapSearchAPI!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.fd_prefersNavigationBarHidden = true
        
        initTableView()
        
        initSearch()
        addListener()
        
        debounceSearch = debounce(delay:DispatchTimeInterval.seconds(1) , action: {[weak self] in
            self?.searchAction(searchPage: 1);
        })
        
        searchBtn.layer.borderWidth = 1;
        searchBtn.layer.borderColor = UIColor.white.cgColor
        searchBtn.layer.cornerRadius = 5;
        searchBtn.layer.masksToBounds = true


    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    deinit {
        NotificationCenter.default.removeObserver(self, name: Notification.Name.UITextFieldTextDidChange, object: nil)
    }
    
    
    
    func addListener() {
        NotificationCenter.default.addObserver(forName: Notification.Name.UITextFieldTextDidChange, object: searchTextField, queue: OperationQueue.main) { (notify) in
            let textField = notify.object as! UITextField
            printLog(message: textField.text)
//            if let debounceFun = self.debounceSearch {
//                debounceFun()
//            }
            self.searchAction(searchPage: 1)
            
        }
    }
    

    func debounceSearch(searchPage: Int) {
        
    }
    
    //MARK - init map
    func initSearch() {
        search = AMapSearchAPI()
        search.delegate = self
    }
    func initTableView() {
        tableView.register(UINib(nibName: "SearchPointCell", bundle: Bundle(for: SearchPointCell.self)), forCellReuseIdentifier: "SearchPointCell")
        tableView.delegate = self;
        tableView.dataSource = self;
        searchTextField.delegate = self
    }
    
    func searchAction(searchPage: Int) {
        
        let request = AMapPOIKeywordsSearchRequest()
        request.requireExtension = true
        request.city = city
        request.sortrule = 0
        request.page = searchPage
        request.cityLimit = true
        request.requireSubPOIs = true
        request.keywords = searchTextField.text
        self.searchPage = searchPage
        search.aMapPOIKeywordsSearch(request)
        
        
    }

    @IBAction func backAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func searchBtnClick(_ sender: Any) {
        searchAction(searchPage: 0)
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension SearchPointViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 65;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pois.count;
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SearchPointCell", for: indexPath)
        let poiCell = cell as! SearchPointCell
        poiCell.poi = pois[indexPath.row]
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selected = pois[indexPath.row]
        if let selectBlock = poiDidSelected {
            selectBlock(selected!)
            backAction("")
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        searchTextField.resignFirstResponder()
    }
}

extension SearchPointViewController: AMapSearchDelegate {
    //MARK:- AMapSearchDelegate
    
    func aMapSearchRequest(_ request: Any!, didFailWithError error: Error!) {
        print("error :\(error)")
    }
    
    /* POI 搜索回调. */
    func onPOISearchDone(_ request: AMapPOISearchBaseRequest!, response: AMapPOISearchResponse!) {
        
        self.pois.removeAll()
        self.pois.append(contentsOf: response.pois)
        tableView.reloadData()
        
    }
    
    func onReGeocodeSearchDone(_ request: AMapReGeocodeSearchRequest!, response: AMapReGeocodeSearchResponse!) {
        
        if response.regeocode != nil {
        }
    }
}

extension SearchPointViewController: UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        searchAction(searchPage: 1)
        return true
    }
    
}




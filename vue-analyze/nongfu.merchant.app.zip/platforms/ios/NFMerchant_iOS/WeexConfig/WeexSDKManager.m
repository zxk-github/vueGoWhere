//
//  WeexSDKManager.m
//  WeexDemo
//
//  Created by yangshengtao on 16/11/14.
//  Copyright © 2016年 taobao. All rights reserved.
//


#if DEVELOPMENT
#import "NFMerchant_iOSDev-Swift.h"
#else
#import "NFMerchant_iOS-Swift.h"
#endif


#import "WeexSDKManager.h"
#import "DemoDefine.h"
#import "WeexBundleUrlLoder.h"
#import <WeexSDK/WeexSDK.h>
#import "NFMainHomeViewController.h"
#import "WeexPluginManager.h"
#import "WXImgLoaderDefaultImpl.h"
#import "WXEventModule.h"
#import "WXNetWork.h"
#import "CallModel.h"
#import "ChooseImageModel.h"
#import "AppUtil.h"
#import "PayModule.h"
#import "AppStorage.h"
#import "QRMoudle.h"
#import "ScanIdCardMoudle.h"
#import "PickerMoudle.h"
#import "LocationMoudle.h"
#import "MultilevelPickerModule.h"
#import "ContactModule.h"
#import "PrintMoudle.h"
#import "GlobalUtil.h"
#import "Navigator.h"
#import "MarketChartComponent.h"
#import "StorageModule.h"
#import "UmengStatistics.h"


@implementation WeexSDKManager

+ (void)setup;
{
    NSURL *url = nil;
#if DEBUG
    //If you are debugging in device , please change the host to current IP of your computer.
    WeexBundleUrlLoder *loader = [WeexBundleUrlLoder new];
    url = [loader jsBundleURL];
    if (!url) {
        url = [NSURL URLWithString:BUNDLE_URL];
    }
#else
    url = [NSURL URLWithString:BUNDLE_URL];
#endif
    
#ifdef UITEST
    url = [NSURL URLWithString:UITEST_HOME_URL];
#endif
    
    [self initWeexSDK];
    [WeexPluginManager registerWeexPlugin];
    [self loadCustomContainWithScannerWithUrl:url];
}

+ (void)initWeexSDK
{
    [WXAppConfiguration setAppGroup:@"NongFuApp"];
    [WXAppConfiguration setAppName:@"NongFuMerchantApp"];
    [WXAppConfiguration setAppVersion:[GlobalUtil getAppVersion]];
    [WXAppConfiguration setExternalUserAgent:@"ExternalUA"];
    
    [WXSDKEngine initSDKEnvironment];
    
    [WXSDKEngine registerHandler:[WXImgLoaderDefaultImpl new] withProtocol:@protocol(WXImgLoaderProtocol)];
    [WXSDKEngine registerModule:@"call" withClass:[CallModel class]];
    [WXSDKEngine registerModule:@"image" withClass:[ChooseImageModel class]];
    [WXSDKEngine registerModule:@"appUtil" withClass:[AppUtil class]];
    [WXSDKEngine registerModule:@"payUtil" withClass:[PayModule class]];
    [WXSDKEngine registerModule:@"appStorage" withClass:[AppStorage class]];
    [WXSDKEngine registerModule:@"qrcode" withClass:[QRMoudle class]];
    [WXSDKEngine registerModule:@"idCard" withClass:[ScanIdCardMoudle class]];
    [WXSDKEngine registerModule:@"regionPicker" withClass:[PickerMoudle class]];
    [WXSDKEngine registerModule:@"multilevelPicker" withClass:[MultilevelPickerModule class]];
    [WXSDKEngine registerModule:@"location" withClass:[LocationMoudle class]];
    [WXSDKEngine registerModule:@"contact" withClass:[ContactModule class]];
    [WXSDKEngine registerModule:@"print" withClass:[PrintMoudle class]];
    [WXSDKEngine registerModule:@"navigator" withClass:[Navigator class]];
    [WXSDKEngine registerModule:@"storage" withClass:[StorageModule class]];
    [WXSDKEngine registerModule:@"statistics" withClass:[UmengStatistics class]];
    
    
    [WXSDKEngine registerComponent:@"nfLineChart" withClass:[MarketChartComponent class]];
    
    
    [WXSDKEngine registerHandler:[WXEventModule new] withProtocol:@protocol(WXEventModuleProtocol)];
    [WXSDKEngine registerHandler:[WXNetWork new] withProtocol:@protocol(WXResourceRequestHandler)];
    
#ifdef DEBUG
    [WXLog setLogLevel:WXLogLevelLog];
#endif
}

+ (void)loadCustomContainWithScannerWithUrl:(NSURL *)url
{
//    UIViewController *home = [[NFMainHomeViewController alloc] init];
//    ((NFMainHomeViewController *)home).url = url;
//    [[UIApplication sharedApplication] delegate].window.rootViewController = [[WXRootViewController alloc] initWithRootViewController:home];
    [MainHomeViewController showWithUrl:url];
    
    
}

@end

//
//  WXImageEmpty.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2017/8/15.
//  Copyright © 2017年 taobao. All rights reserved.
//

#import "WXImageEmpty.h"

@implementation WXImageEmpty
-(void)cancel{
    
}
@end

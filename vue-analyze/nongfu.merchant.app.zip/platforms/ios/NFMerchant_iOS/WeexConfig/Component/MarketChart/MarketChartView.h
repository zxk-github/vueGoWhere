//
//  MarketChartView.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/5/7.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChartOptions.h"

typedef void(^ValueSelectedBlock)(double x, double y);

@interface MarketChartView : UIView
@property (nonatomic, strong) ChartOptions *chartOptions;
@property (nonatomic, copy) ValueSelectedBlock chartValueSelected;
@end

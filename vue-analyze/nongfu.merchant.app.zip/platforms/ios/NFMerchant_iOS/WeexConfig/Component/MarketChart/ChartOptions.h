//
//  ChartOptions.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/5/8.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface AxisLabel : NSObject
@property (nonatomic, strong) NSNumber *show;
@property (nonatomic, copy) NSString *formatter;
@property (nonatomic, copy) NSString *fontSize;
@property (nonatomic, copy) NSString *color;
@end

@interface NameTextStyle : NSObject
@property (nonatomic, copy) NSString *color;
@end

@interface LineStyle : NSObject
@property (nonatomic, copy) NSString *color;
@end
@interface SerieLable : NSObject
@property (nonatomic, strong) NSNumber *show;
@end
@interface AreaStyle : NSObject
@property (nonatomic, copy) NSArray *color;
@end

@interface Tooltip : NSObject
@property (nonatomic, strong) NSNumber *show;

@end


@interface Serie : NSObject
@property (nonatomic, strong) NSNumber *smooth;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, strong) LineStyle *lineStyle;
@property (nonatomic, strong) SerieLable *lable;
@property (nonatomic, strong) AreaStyle *areaStyle;
@property (nonatomic, copy) NSArray *data;
@end

@interface Axis : NSObject
@property (nonatomic, strong) NSNumber *show;
@property (nonatomic, copy) NSString *name;

@property (nonatomic, strong) AxisLabel *axisLabel;
@property (nonatomic, strong) NameTextStyle *nameTextStyle;
@property (nonatomic, copy) NSArray *data;
@end


@interface ChartOptions : NSObject
@property (nonatomic, copy) NSArray *series;
@property (nonatomic, copy) NSArray *legend;
@property (nonatomic, strong) Axis *xAxis;
@property (nonatomic, strong) Axis *yAxis;
@property (nonatomic, strong) Tooltip *tooltip;
@end



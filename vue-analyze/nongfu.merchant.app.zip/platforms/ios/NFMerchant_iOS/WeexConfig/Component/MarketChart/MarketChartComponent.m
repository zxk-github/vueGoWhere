//
//  MarketChartComponent.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/5/7.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "MarketChartComponent.h"
#import "MarketChartView.h"
#import "Colours.h"
#import <YYModel/YYModel.h>
#import "ChartOptions.h"
@interface MarketChartComponent()
@property (nonatomic, strong) ChartOptions *chartOptions;
@property (nonatomic, assign) BOOL chartValueSelected;
@end


@implementation MarketChartComponent

- (instancetype)initWithRef:(NSString *)ref type:(NSString *)type styles:(NSDictionary *)styles attributes:(NSDictionary *)attributes events:(NSArray *)events weexInstance:(WXSDKInstance *)weexInstance {
    if(self = [super initWithRef:ref type:type styles:styles attributes:attributes events:events weexInstance:weexInstance]) {
        self.chartOptions = [ChartOptions yy_modelWithDictionary: attributes[@"options"]];
    }
    return self;
}

- (void)updateAttributes:(NSDictionary *)attributes
{
    [super updateAttributes:attributes];
    if (attributes[@"options"]) {
        self.chartOptions = [ChartOptions yy_modelWithDictionary: attributes[@"options"]];
        ((MarketChartView *)self.view).chartOptions = self.chartOptions;
    }
}


- (UIView *)loadView {
    MarketChartView *chartView = [[MarketChartView alloc] init];
//    chartView.backgroundColor = [UIColor colorFromHexString:[self.styles[@"background"] suebstringFromIndex:1]] ;
    chartView.chartOptions = self.chartOptions;
    __weak MarketChartComponent *weakSelf = self;
    [chartView setChartValueSelected:^(double x, double y) {
        [weakSelf fireEvent:@"chartValueSelected" params:@{@"x": @(x), @"y": @(y)}];
    }];
//    chartView.backgroundColor = [UIColor orangeColor];
    return chartView;
}

- (void)viewDidLoad {
    
}
- (void)addEvent:(NSString *)eventName {
    if ([eventName isEqualToString:@"chartValueSelected"]) {
        _chartValueSelected = YES;
    }
}

- (void)removeEvent:(NSString *)eventName
{
    if ([eventName isEqualToString:@"chartValueSelected"]) {
        _chartValueSelected = NO;
    }
}

@end

//
//  MarketChartView.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/5/7.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "MarketChartView.h"

#if DEVELOPMENT
#import "NFMerchant_iOSDev-Swift.h"
#else
#import "NFMerchant_iOS-Swift.h"
#endif
#import <Charts/Charts-Swift.h>
#import "Colours.h"
@interface MarketChartView()<ChartViewDelegate>
//@property (nonatomic, strong) XLineChart  *lineChart;
@property (nonatomic, strong) LineChartView  *lineChartView;
@end



@implementation MarketChartView

-(instancetype)init{
    if (self = [super init]) {
        [self setUpLineChartView];
    }
    return self;
}
-(void)setBackgroundColor:(UIColor *)backgroundColor{
    [super setBackgroundColor:backgroundColor];
    _lineChartView.backgroundColor =  backgroundColor;
}

-(void)setUpLineChartView{
    LineChartView *lineChartView = [[LineChartView alloc] init];
    
    [self addSubview:lineChartView];
    self.lineChartView = lineChartView;
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self configLineChartStyle];//配置
    });
    
}

-(void)setFrame:(CGRect)frame {
    [super setFrame:frame];
    
    if (self.lineChartView) {
        self.lineChartView.frame = self.bounds;
    }

    
}


-(void) configLineChartStyle {
//    _lineChartView.backgroundColor =  [UIColor orangeColor];
    _lineChartView.frame = self.bounds;
    _lineChartView.layer.cornerRadius = 8;
    _lineChartView.layer.masksToBounds = YES;
    
    
    _lineChartView.delegate = self;//代理
    _lineChartView.dragEnabled = YES;
    _lineChartView.chartDescription.enabled = NO;
    [_lineChartView setScaleXEnabled:YES];
    [_lineChartView setScaleYEnabled:NO];
    _lineChartView.pinchZoomEnabled = NO;
    _lineChartView.doubleTapToZoomEnabled = YES;
    _lineChartView.autoScaleMinMaxEnabled = YES;
    
    _lineChartView.drawGridBackgroundEnabled = NO;
    _lineChartView.drawBordersEnabled = NO;
    
    _lineChartView.legend.enabled = NO;//是否显示折线的名称以及对应颜色 多条折线时必须开启 否则无法分辨
    _lineChartView.legend.textColor = [UIColor whiteColor];//折线名称字体颜色
    _lineChartView.legend.form = ChartLegendFormLine;
    
    
    _lineChartView.extraRightOffset = 20;
    
    ChartViewPortHandler *chartViewHandle = _lineChartView.viewPortHandler;
    [chartViewHandle setMinMaxScaleXWithMinScaleX:1 maxScaleX:3];
    
    
    
    //设置动画时间
    [_lineChartView animateWithXAxisDuration:1];
    
    //设置纵轴坐标显示在左边而非右边
    ChartYAxis *rightAxis = _lineChartView.rightAxis;
    rightAxis.enabled = NO;
    
    ChartYAxis *leftAxis = _lineChartView.leftAxis;
    leftAxis.drawGridLinesEnabled = NO;
    leftAxis.axisMinimum = 0.0;
    NSString *axisColorHexLeft = self.chartOptions.xAxis.axisLabel.color;
    NSString *labelTextColorHexLeft = self.chartOptions.xAxis.nameTextStyle.color;
    leftAxis.axisLineColor = axisColorHexLeft? [UIColor colorFromHexString:axisColorHexLeft] : [UIColor whiteColor];
    leftAxis.labelTextColor = labelTextColorHexLeft? [UIColor colorFromHexString:labelTextColorHexLeft] : [UIColor whiteColor];
    leftAxis.enabled = self.chartOptions.yAxis.axisLabel.show.boolValue;
    __weak MarketChartView *weakSelf = self;
    //y轴信息
    leftAxis.valueFormatter = [[ChartDefaultAxisValueFormatter alloc] initWithBlock:^NSString * _Nonnull(double value, ChartAxisBase * _Nullable axis) {
        
        if (!weakSelf.chartOptions.xAxis.axisLabel.show.boolValue) {
            return @"";
        } else {
            NSString *yValueTemp = weakSelf.chartOptions.yAxis.axisLabel.formatter;
            if (yValueTemp) {
                return [yValueTemp stringByReplacingOccurrencesOfString:@"{value}" withString: [NSString stringWithFormat:@"%.2f",value]];
            }
            return [NSString stringWithFormat:@"%.2f",value];
        }
        
    }];
    
    
    
    //设置横轴坐标显示在下方 默认显示是在顶部
    ChartXAxis *xAxis = _lineChartView.xAxis;
    xAxis.drawGridLinesEnabled = NO;
    
    xAxis.labelPosition = XAxisLabelPositionBottom;
    NSString *axisColorHex = self.chartOptions.xAxis.axisLabel.color;
    NSString *labelTextColorHex = self.chartOptions.xAxis.nameTextStyle.color;
    xAxis.axisLineColor = axisColorHex? [UIColor colorFromHexString:axisColorHex] : [UIColor whiteColor];
    xAxis.labelTextColor = labelTextColorHex? [UIColor colorFromHexString:labelTextColorHex] : [UIColor whiteColor];
    xAxis.labelCount = 6;
    xAxis.granularityEnabled = YES;  
    xAxis.enabled = self.chartOptions.xAxis.axisLabel.show.boolValue;
    
    
    //设置x轴的值
    NSArray *xLabelValue = self.chartOptions.xAxis.data;
    NSMutableArray *xLabelValueArray = [NSMutableArray array];
    if ( xLabelValue && xLabelValue.count > 0) {//有X轴数据
        
        NSString *xValueTemp = self.chartOptions.xAxis.axisLabel.formatter;
        
        if (xValueTemp) {//有x轴的formatter
            [xLabelValue enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                NSString *value = [xValueTemp stringByReplacingOccurrencesOfString:@"{value}" withString: [(NSNumber *)obj stringValue]];
                [xLabelValueArray addObject:value];
            }];
        } else {
            [xLabelValue enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                NSString *value = [(NSNumber *)obj stringValue];
                [xLabelValueArray addObject:value];
            }];
        }
        
        if (!self.chartOptions.xAxis.axisLabel.show.boolValue) {//不显示X轴值
            [xLabelValueArray removeAllObjects];
            [xLabelValue enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                NSString *value = [(NSNumber *)obj stringValue];
                [xLabelValueArray addObject:value];
            }];
        }
        xAxis.valueFormatter = [[ChartIndexAxisValueFormatter alloc] initWithValues:xLabelValueArray];
        
        
//        [[ChartIndexAxisValueFormatter alloc] initWithValues:xLabelValueArray];
        
    }
    
    
    
    if (self.chartOptions.tooltip.show.boolValue) {
        BalloonMarker *marker = [[BalloonMarker alloc]
                                 initWithColor: [UIColor colorWithWhite:180/255. alpha:1.0]
                                 font: [UIFont systemFontOfSize:12.0]
                                 textColor: UIColor.whiteColor
                                 insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0)];
        marker.chartView = _lineChartView;
        marker.minimumSize = CGSizeMake(80.f, 40.f);
        marker.markerXValue = xLabelValueArray;
        marker.markerYFormatter = _chartOptions.yAxis.axisLabel.formatter;
        _lineChartView.marker = marker;
    }
    
    
    
    
    _lineChartView.noDataText = @"暂无数据";
    _lineChartView.noDataTextColor = [UIColor whiteColor];
    
    
}
-(void)setChartOptions:(ChartOptions *)chartOptions{
    if (chartOptions != _chartOptions) {
        _chartOptions = chartOptions;
        dispatch_async(dispatch_get_main_queue(), ^{
            [self configLineChartStyle];//配置
             [self updateChartWithData];
        });
       
    }
}
- (void)updateChartWithData {
    
    NSArray *lines = self.chartOptions.series;
    
    NSMutableArray *dataSets = [[NSMutableArray alloc] init];
    [lines enumerateObjectsUsingBlock:^(Serie *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        
        NSArray *data = obj.data;
        if (!data) {
            return ;
        }
        
        NSMutableArray *yValues = [NSMutableArray array];
        [data enumerateObjectsUsingBlock:^(NSNumber *  _Nonnull obj, NSUInteger dataIdx, BOOL * _Nonnull stop) {
            [yValues addObject:[[ChartDataEntry alloc] initWithX:dataIdx y:obj.doubleValue icon: nil]];
        }];
        
        NSString *lineName = [(Serie *)(self.chartOptions.series[idx]) name];
        LineChartDataSet *set = [[LineChartDataSet alloc] initWithValues:yValues label: lineName ? lineName : [NSString stringWithFormat:@"DataSet %ld", idx]];
        
        set.highlightLineDashLengths = @[@5.f, @2.5f];
        NSString *colorHex = [[(Serie *)(self.chartOptions.series[idx]) lineStyle] color];
        [set setColor:  (colorHex ? [UIColor colorFromHexString:colorHex] : UIColor.whiteColor)];
        [set setCircleColor: (colorHex ? [UIColor colorFromHexString:colorHex] : UIColor.whiteColor)];
        set.lineWidth = 1.0;
        set.circleRadius = 3.0;
        set.drawCircleHoleEnabled = NO;
        if ([(Serie *)(self.chartOptions.series[idx]) smooth]) {
            set.mode = LineChartModeCubicBezier;
        } else {
            set.mode = LineChartModeLinear;
        }
        
        
        set.valueFont = [UIFont systemFontOfSize:9.f];
//        set1.formLineDashLengths = @[@5.f, @2.5f]; 虚线样式
        BOOL showLabel = [[[(Serie *)(self.chartOptions.series[idx]) lable] show] boolValue];
        set.drawValuesEnabled = showLabel;//在点上方显示数据
        
        set.formLineWidth = 1.0;
        set.formSize = 15.0; //设置legend的大小
        
        
        set.drawFilledEnabled = YES;
        if ([[(Serie *)(self.chartOptions.series[idx]) areaStyle] color].count > 1) {
            
            NSArray *colorHex = [[(Serie *)(self.chartOptions.series[idx]) areaStyle] color];
            NSMutableArray *gradientColors = [NSMutableArray array];
            [colorHex enumerateObjectsUsingBlock:^(NSString *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                [gradientColors addObject:(id)[ChartColorTemplates colorFromString: obj].CGColor];
            }];
            CGGradientRef gradient = CGGradientCreateWithColors(nil, (CFArrayRef)gradientColors, nil);
            set.fillAlpha = 1.f;
            set.fill = [ChartFill fillWithLinearGradient:gradient angle:90.f];
            CGGradientRelease(gradient);
            
        } else if ([[(Serie *)(self.chartOptions.series[idx]) areaStyle] color].count == 1) {
            NSArray *colorHex = [[(Serie *)(self.chartOptions.series[idx]) areaStyle] color];
            set.fillAlpha = 1.f;
            set.fill = [ChartFill fillWithColor:[UIColor colorFromHexString:colorHex.firstObject]];
        } else {
            set.drawFilledEnabled = NO;
        }
        
        [dataSets addObject:set];
    }];
    
    
    if (dataSets.count > 0) {
        LineChartData *data = [[LineChartData alloc] initWithDataSets:dataSets];
        _lineChartView.data = data;
    }
    
//    [_lineChartView setVisibleXRangeWithMinXRange:1 maxXRange:6];
//    [_lineChartView.data notifyDataChanged];
    [_lineChartView notifyDataSetChanged];
  
}
    



-(void)chartValueSelected:(ChartViewBase *)chartView entry:(ChartDataEntry *)entry highlight:(ChartHighlight *)highlight{
    NSLog(@"%@---%@", entry, highlight);
    if(self.chartValueSelected) {
        self.chartValueSelected(entry.x, entry.y);
    }
    
}
    
    








/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end

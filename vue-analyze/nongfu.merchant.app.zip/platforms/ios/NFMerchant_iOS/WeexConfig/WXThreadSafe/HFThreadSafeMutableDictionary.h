//
//  HFThreadSafeMutableDictionary.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2017/8/16.
//  Copyright © 2017年 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HFThreadSafeMutableDictionary<KeyType, ObjectType> : NSMutableDictionary

@end

/**
 * \mainpage SNBC SDK for Barcode Printers
 * \if English
 * SNBC SDK for Barcode Printer support BPLZ/BPLE/BPLT/BPLC/BPLA, this document introduces the using method of SNBC SDK for Barcode Printer in details. Please read carefully before use.
 * \par I want to... \n
 * -# \ref ADD_SDK_TO_PROJECT \n
 * -# \ref DISCOVER_DEVICE \n
 * -# \ref CONNECT_DEVICE \n
 * -# \ref QUERY_STATUS \n
 * -# \ref PRINT_TEXT_USE_BUILTIN_FONT_BPLZ \n
 * -# \ref PRINT_TEXT_USE_BUILTIN_FONT_BPLE \n
 * -# \ref PRINT_TEXT_USE_BUILTIN_FONT_BPLT \n
 * -# \ref PRINT_TEXT_USE_BUILTIN_FONT_BPLC \n
 * -# \ref PRINT_TEXT_USE_BUILTIN_FONT_BPLA \n
 * -# \ref PRINT_TEXT_USE_DOWNLOADED_FONT_BPLZ \n
 * -# \ref PRINT_TEXT_USE_DOWNLOADED_FONT_BPLT \n
 * -# \ref PRINT_TEXT_USE_DOWNLOADED_FONT_BPLC \n
 * -# \ref PRINT_BARCODE_BPLZ \n
 * -# \ref PRINT_BARCODE_BPLE \n
 * -# \ref PRINT_BARCODE_BPLT \n
 * -# \ref PRINT_BARCODE_BPLC \n
 * -# \ref PRINT_BARCODE_BPLA \n
 * -# \ref PRINT_GRAPHICS_BPLZ \n
 * -# \ref PRINT_GRAPHICS_BPLE \n
 * -# \ref PRINT_GRAPHICS_BPLT \n
 * -# \ref PRINT_GRAPHICS_BPLC \n
 * -# \ref PRINT_GRAPHICS_BPLA \n
 * -# \ref PRINT_IMAGE \n
 * -# \ref PRINT_DOWNLOADED_IMAGE \n
 * -# \ref PRINT_LABEL_BPLZ_SAMPLE1 \n
 * -# \ref PRINT_LABEL_BPLZ_SAMPLE2 \n
 * -# \ref PRINT_LABEL_BPLE_SAMPLE1 \n
 * -# \ref PRINT_LABEL_BPLE_SAMPLE2 \n
 * -# \ref PRINT_LABEL_BPLT_SAMPLE1 \n
 * -# \ref PRINT_LABEL_BPLT_SAMPLE2 \n
 * -# \ref PRINT_LABEL_BPLC_SAMPLE1 \n
 * -# \ref PRINT_LABEL_BPLC_SAMPLE2 \n
 * -# \ref PRINT_LABEL_BPLA_SAMPLE1 \n
 * -# \ref PRINT_LABEL_BPLA_SAMPLE2 \n
 * -# \ref DOWNLOAD_IMAGE_TO_PRINTER \n
 * -# \ref DOWNLOAD_FONT_TO_PRINTER \n
 * -# \ref QUERY_FONT_FROM_PRINTER \n
 * -# \ref QUERY_IMAGE_FROM_PRINTER \n
 * -# \ref DOWNLOAD_FORMAT_TO_PRINTER \n
 * -# \ref PRINT_LABEL_WITH_FORMAT \n
 * -# \ref QUERY_FORMAT_FROM_PRINTER \n
 * -# \ref SEND_DATA_TO_DEVICE \n
 * -# \ref READ_PRINTER_CONFIGURATION \n
 * -# \ref UPDATE_PRINTER_CONFIGURATION \n
 * -# \ref DELETE_FILE \n
 * -# \ref FORMAT_FLASH \n
 *
 * \par Cautions while using SDK
 * -# Each Connection and Printer can only be used in single thread\n
 * -# Some functions only apply to particular command set. When the method that you call cannot be supported by your selected command set, SDK will cause ExceptionSDK type exception.
 * 
 * \par Development environment information
 * -# Establish SDK using Xcode6 \n
 * -# In SDK, use “Manual Reference Counting” to manage the internal memory \n
 * -# Use LLVM6.1 to compile \n
 * -# Support V7 and arm64 
 *
 * \par Applicable product
 * -# BPLZ printer: Firmware version V2.100 and above \n
 * -# BPLE printer: Firmware version V2.100 and above \n
 * -# BPLT printer: Firmware version V3.100 and above \n
 * -# BPLC printer: Firmware version V1.000.40 and above \n
 *
 * \elseif Chinese
 * SNBC SDK for Barcode Printer support支持的指令集包括BPLZ/BPLE/BPLT/BPLC/BPLA，本文档版详细介绍了SNBC SDK for Barcode Printer软件的使用方法，在使用SDK软件前，请仔细阅读
 * \par 我想...\n
 * -# \ref ADD_SDK_TO_PROJECT \n
 * -# \ref DISCOVER_DEVICE \n
 * -# \ref CONNECT_DEVICE \n
 * -# \ref QUERY_STATUS \n
 * -# \ref PRINT_TEXT_USE_BUILTIN_FONT_BPLZ \n
 * -# \ref PRINT_TEXT_USE_BUILTIN_FONT_BPLE \n
 * -# \ref PRINT_TEXT_USE_BUILTIN_FONT_BPLT \n
 * -# \ref PRINT_TEXT_USE_BUILTIN_FONT_BPLC \n
 * -# \ref PRINT_TEXT_USE_BUILTIN_FONT_BPLA \n
 * -# \ref PRINT_TEXT_USE_DOWNLOADED_FONT_BPLZ \n
 * -# \ref PRINT_TEXT_USE_DOWNLOADED_FONT_BPLT \n
 * -# \ref PRINT_TEXT_USE_DOWNLOADED_FONT_BPLC \n
 * -# \ref PRINT_BARCODE_BPLZ \n
 * -# \ref PRINT_BARCODE_BPLE \n
 * -# \ref PRINT_BARCODE_BPLT \n
 * -# \ref PRINT_BARCODE_BPLC \n
 * -# \ref PRINT_BARCODE_BPLA \n
 * -# \ref PRINT_GRAPHICS_BPLZ \n
 * -# \ref PRINT_GRAPHICS_BPLE \n
 * -# \ref PRINT_GRAPHICS_BPLT \n
 * -# \ref PRINT_GRAPHICS_BPLC \n
 * -# \ref PRINT_GRAPHICS_BPLA \n
 * -# \ref PRINT_IMAGE \n
 * -# \ref PRINT_DOWNLOADED_IMAGE \n
 * -# \ref PRINT_LABEL_BPLZ_SAMPLE1 \n
 * -# \ref PRINT_LABEL_BPLZ_SAMPLE2 \n
 * -# \ref PRINT_LABEL_BPLE_SAMPLE1 \n
 * -# \ref PRINT_LABEL_BPLE_SAMPLE2 \n
 * -# \ref PRINT_LABEL_BPLT_SAMPLE1 \n
 * -# \ref PRINT_LABEL_BPLT_SAMPLE2 \n
 * -# \ref PRINT_LABEL_BPLC_SAMPLE1 \n
 * -# \ref PRINT_LABEL_BPLC_SAMPLE2 \n
 * -# \ref PRINT_LABEL_BPLA_SAMPLE1 \n
 * -# \ref PRINT_LABEL_BPLA_SAMPLE2 \n
 * -# \ref DOWNLOAD_IMAGE_TO_PRINTER \n
 * -# \ref DOWNLOAD_FONT_TO_PRINTER \n
 * -# \ref QUERY_FONT_FROM_PRINTER \n
 * -# \ref QUERY_IMAGE_FROM_PRINTER \n
 * -# \ref DOWNLOAD_FORMAT_TO_PRINTER \n
 * -# \ref PRINT_LABEL_WITH_FORMAT \n
 * -# \ref QUERY_FORMAT_FROM_PRINTER \n
 * -# \ref SEND_DATA_TO_DEVICE \n
 * -# \ref READ_PRINTER_CONFIGURATION \n
 * -# \ref UPDATE_PRINTER_CONFIGURATION \n
 * -# \ref DELETE_FILE \n
 * -# \ref FORMAT_FLASH \n
 *
 * \par 使用SDK的注意事项
 * -# 每个 Connection 对象及 Printer 对象只能在单个线程中使用\n
 * -# 一些功能只适用于特定的指令集，当您调用的方法不被您选择的指令集支持时，SDK将会抛出 ExceptionSDK 类型的异常
 * 
 * \par 开发环境信息
 * -# SDK库使用Xcode6构建 \n
 * -# SDK库中使用“Manual Reference Counting”方式管理内存 \n
 * -# 使用LLVM6.1编译 \n
 * -# 支持V7及arm64平台
 *
 * \par 适用的产品
 * -# BPLZ语言打印机:固件版本V2.100及以上 \n
 * -# BPLE语言打印机:固件版本V2.100及以上 \n
 * -# BPLT语言打印机:固件版本V3.100及以上 \n
 * -# BPLC语言打印机:固件版本V1.000.40及以上
 * \endif
 */
 
 /**
 * \if English
 * \defgroup ADD_SDK_TO_PROJECT Add SDK to my project
 * \par Add SNBCSDKforBarcodePrinter.a
 * -# Open Xcode project and switch to “Project Navigator”\n
 * -# Switch to “Link Binary With Libraries” of “Build Phases” page\n
 * -# Click “＋” button and then click “Add Others...” button, select file SNBCSDKforBarcodePrinter.a.
 *
 * \par Add interface declaration
 * -# Open Xcode project and switch to “Project Navigator”\n
 * -# Switch to “Build Setting” page \n
 * -# Add the catalogue of SDK software interface declaration“lib/include” in the “Head Search Path” item.
 *
 * \elseif Chinese
 * \defgroup ADD_SDK_TO_PROJECT 添加SDK库到我的工程
 * \par 添加SNBCSDKforBarcodePrinter.a
 * -# 打开Xcode工程并切换到“Project Navigator”\n
 * -# 切换到“Build Phases”页面中的“Link Binary With Libraries”\n
 * -# 点击名为“＋”的button，然后点击名为“Add Others...”的按钮，选择文件SNBCSDKforBarcodePrinter.a
 *
 * \par 添加接口声明文件
 * -# 打开Xcode工程并切换到“Project Navigator”\n
 * -# 切换到“Build Setting”页面 \n
 * -# 在“Head Search Path”项中添加SDK软件接口声明文件所在目录“lib/include”
 * \endif
 */
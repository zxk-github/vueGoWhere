/**
 * \file Connection.h
 * \copyright
 *
 * \if English
 * This document is owned by Shandong New Beiyang Information Technology Co., Ltd. Without the express written permission of SNBC,
 * no part of this document may be reproduced or transmitted in any form or by any means.\n
 * Shandong New Beiyang Information Technology Co., Ltd. 2015
 * \elseif Chinese
 * 本文档为山东新北洋信息技术股份有限公司所有。未经山东新北洋信息技术股份有效公司书面授权，
 * 任何人不得以任何形式进行再次分发或复制。\n
 * 山东新北洋信息技术股份有限公司。2015
 * \endif
 */

#import <Foundation/Foundation.h>
#import <ExternalAccessory/ExternalAccessory.h>

#pragma mark -
#pragma mark default timeout

/**
 * \if English
 * \brief Default timeout of searching device, unit: ms
 * \elseif Chinese
 * \brief 设备搜索默认超时时间，单位毫秒
 * \endif
 */
#define DEFAULT_TIMEOUT_DISCOVER_DEVICE 10000

/**
 * \if English
 * \brief Default timeout of connecting device, unit: ms
 * \elseif Chinese
 * \brief 连接设备默认超时时间，单位毫秒
 * \endif
 */
#define DEFAULT_TIMEOUT_CREATE_CONNECT  (10 * 1000)

/**
 * \if English
 * \brief Default timeout of reading data, unit: ms
 * \elseif Chinese
 * \brief 读数据默认超时时间，单位毫秒
 * \endif
 */
#define DEFAULT_TIMEOUT_READ            (90 * 1000)

/**
 * \if English
 * \brief Default timeout of writing data, unit: ms
 * \elseif Chinese
 * \brief 写数据默认超时时间，单位毫秒
 * \endif
 */
#define DEFAULT_TIMEOUT_WRITE           (90 * 1000)

/**
 * \if English
 * \brief Default waiting time after finishing reading the data, unit: ms
 * \elseif Chinese
 * \brief 读数据完成后的默认等待时间，单位毫秒
 * \endif
 */
#define DEFAULT_WAIT_TIME_AFTER_WRITE   0

/**
 * \if English
 * \brief Default waiting time after finishing writing the data, unit: ms
 * \elseif Chinese
 * \brief 写数据完成后的默认等待时间，单位毫秒
 * \endif
 */
#define DEFAULT_WAIT_TIME_AFTER_READ    0

/**
 * \if English
 * \brief Default waiting time of resetting device, unit: ms
 * \elseif Chinese
 * \brief 设备复位需要等待的默认时间，单位毫秒
 * \endif
 */
#define DEFAULT_TIME_REBOOT             16000

/**
 * \if English
 * \brief Default waiting time of restoring factory settings, unit: ms
 * \elseif Chinese
 * \brief 设备恢复出厂设置需要等待的默认时间，单位毫秒
 * \endif
 */
#define DEFAULT_TIME_RESTORE_DEFAULT    10000

/**
 * \if English
 * \brief Default waiting time of formatting flash, unit: ms
 * \elseif Chinese
 * \brief 格式化flash需要等待的默认时间，单位毫秒
 * \endif
 */
#define DEFAULT_TIME_FORMAT_FLASH       10000

/**
 * \if English
 * \brief Default waiting time of deleting file, unit: ms
 * \elseif Chinese
 * \brief 删除文件需要的默认等待时间，单位毫秒
 * \endif
 */
#define DEFAULT_TIME_DELETE_FILE        2000

/**
 * \if English
 * \brief Definition of port type
 * \elseif Chinese
 * \brief 端口类型定义
 * \endif
 */
typedef enum
{
    /**
     * \if English
     * \brief WIFI port
     * \elseif Chinese
     * \brief WIFI接口
     * \endif
     */
    PORT_TYPE_WIFI = 1,
    
    /**
     * \if English
     * \brief BlueTooth port (BLE) mode
     * \elseif Chinese
     * \brief 蓝牙接口(BLE)模式
     * \endif
     */
    PORT_TYPE_BLUETOOTH_BLE,
    
    /**
     * \if English
     * \brief BlueTooth port (MFI) mode
     * \note Reserved type, unrealized function
     * \elseif Chinese
     * \brief 蓝牙接口(MFI)模式
     * \note 预留类型，功能暂未实现
     * \endif
     */
    PORT_TYPE_BLUETOOTH,
    
    /**
     * \if English
     * \brief File port
     * \note Reserved type, unrealized function
     * \elseif Chinese
     * \brief 文件接口
     * \note 预留类型，功能暂未实现
     * \endif
     */
    PORT_TYPE_FILE
}PortType;

/**
 * \if English
 * \brief WIFI port information
 * \elseif Chinese
 * \brief WIFI接口信息
 * \endif
 */
typedef struct
{
    /**
     * \if English
     * \brief Set as sizeof(PortInfoWIFI)
     * \elseif Chinese
     * \brief 设置为sizeof(PortInfoWIFI)
     * \endif
     */
    UInt32  selfSize;
    
    /**
     * \if English
     * \brief IP address, such as “192.168.1.2”
     * \elseif Chinese
     * \brief IP地址，如“192.168.1.2”
     * \endif
     */
    char    IP[256];
    
    /**
     * \if English
     * \brief Port number, like 9100
     * \elseif Chinese
     * \brief 端口号，如9100
     * \endif
     */
    UInt32  port;
}PortInfoWIFI;

/**
 * \if English
 * \brief BlueTooth (MFI) port information
 * \note Reserved structure, unrealized function
 * \elseif Chinese
 * \brief 蓝牙(MFI)接口信息
 * \note 预留结构，功能暂未实现
 * \endif
 */
typedef struct
{
    /**
     * \if English
     * \brief Set as sizeof(PortInfoBluetooth)
     * \elseif Chinese
     * \brief 设置为sizeof(PortInfoBluetooth)
     * \endif
     */
    UInt32  selfSize;
    
    /**
     * \if English
     * \brief MAC address of BlueTooth device
     * \elseif Chinese
     * \brief 蓝牙设备MAC地址
     * \endif
     */
    __unsafe_unretained EAAccessory *accessory;
    
    __unsafe_unretained NSString    *protocolString;
}PortInfoBluetooth;

/**
 * \if English
 * \brief BlueTooth port (BLE) information
 * \elseif Chinese
 * \brief 蓝牙接口(BLE)信息
 * \endif
 */
typedef struct
{
    /**
     * \if English
     * \brief Set as sizeo(PortInfoBluetoothBLE)
     * \elseif Chinese
     * \brief 设置为sizeo(PortInfoBluetoothBLE)
     * \endif
     */
    UInt32  selfSize;
    
    /**
     * \if English
     * \brief Name of BlueTooth device
     * \elseif Chinese
     * \brief 蓝牙设备名称
     * \endif
     */
    char    deviceName[256];
}PortInfoBluetoothBLE;


/**
 * \if English
 * \brief File port information
 * \elseif Chinese
 * \brief 文件接口信息
 * \endif
 */
typedef struct
{
    /**
     * \if English
     * \brief Set as sizeof(PortInfoFile)
     * \elseif Chinese
     * \brief 设置为sizeof(PortInfoFile)
     * \endif
     */
    UInt32  selfSize;
    
    /**
     * \if English
     * \brief File name that includes path
     * \elseif Chinese
     * \brief 包含路径的文件名称
     * \endif
     */
    char    fileName[256];
}PortInfoFile;


/**
 * \if English
 * \brief Port public body
 * \elseif Chinese
 * \brief 端口公用体
 * \endif
 */
typedef struct
{
    /**
     * \if English
     * \brief Port type
     * \elseif Chinese
     * \brief 端口类型
     * \endif
     */
    PortType portType;
    
    /**
     * \if English
     * \brief Member of various types of port
     * \elseif Chinese
     * \brief 各类型端口成员
     * \endif
     */
    union
    {
        PortInfoWIFI            wifi;
        PortInfoBluetooth       bluetooth;
        PortInfoBluetoothBLE    bluetoothBLE;
        PortInfoFile            file;
    };
}PortInfo;

/**
 * \if English
 *  \brief Device search and communication
 *
 * Realize the function of device search and communication
 * \elseif Chinese
 *  \brief 设备搜索及通讯
 *
 * 实现设备搜索、设备通讯等功能
 * \endif
 */

@interface Connection : NSObject

#pragma mark -
#pragma mark class property

/// \if English
/// \brief TRUE indicates that the connection is valid and can communicate through this connection; FALSE indicates that the connection is invalid
/// \elseif Chinese
/// \brief TRUE表示连接有效，可以使用该连接进行通讯；FALSE表示连接无效
/// \endif

@property (nonatomic, assign, readonly, getter=isConnected) BOOL connectedFlag;

/// \if English
/// \brief timeout of searching device, unit: ms
/// \elseif Chinese
/// \brief 设备搜索超时时间，单位毫秒
/// \endif
@property (nonatomic, assign, readwrite) UInt32 discoverDeviceTimeout;

/// \if English
/// \brief Timeout of establishing connection, unit: ms
/// \elseif Chinese
/// \brief 创建连接超时时间，单位毫秒
/// \endif
@property (nonatomic, assign, readwrite) UInt32 createConectTimeout;

/// \if English
/// \brief Timeout of reading data, unit: ms
/// \elseif Chinese
/// \brief 读数据超时时间，单位毫秒
/// \endif
@property (nonatomic, assign, readwrite) UInt32 readTimeout;

/// \if English
/// \brief Timeout of sending data, unit: ms
/// \elseif Chinese
/// \brief 下发数据超时时间，单位毫秒
/// \endif
@property (nonatomic, assign, readwrite) UInt32 writeTimeout;

/// \if English
/// \brief Waiting time after finishing reading data, unit: ms
/// \elseif Chinese
/// \brief 读数据完成后的等待时间，单位毫秒
/// \endif
@property (nonatomic, assign, readwrite) UInt32 waitTimeAfterRead;

/// \if English
/// \brief Waiting time after finishing sending data, unit: ms
/// \elseif Chinese
/// \brief 下发数据完成后的等待时间，单位毫秒
/// \endif
@property (nonatomic, assign, readwrite) UInt32 waitTimeAfterWrite;

#pragma mark -
#pragma mark class method

/**
 * \if English
 * \brief Search WIFI or BlueTooth device
 *
 * \return Searched WIFI or BlueTooth device
 * \exception When no device has been searched, cause ExceptionSDK type exception.
 * \note For WIFI device, return the IP address and name of each device, among which the key words of IP address is \n
 * For BlueTooth device, return the serial number and name of each device, among which the key words of serial number is \n
 * There is no need to release for the data that the function returns
 * \elseif Chinese
 * \brief 搜索WIFI或蓝牙设备
 *
 * \return 搜索到的WIFI或蓝牙设备
 * \exception 未搜索到任何设备时会抛出 ExceptionSDK 类型异常
 * \note 对于WIFI设备，返回每个设备的IP地址及设备名称，其中IP地址为关键字；\n
 * 对于蓝牙设备，返回每个设备的序号及名称，其中序号为关键字\n
 * 函数返回的对象无需release
 * \endif
 */
- (NSDictionary*)discoverDevice;

/**
 * \if English
 * \brief Establish the connection with device
 *
 * According to the port information specified in portInfo, establish the connection with device
 * \param [in]  portInfo    Port type and port information
 * \return void
 * \exception When the establishing of connection fails, cause ExceptionSDK type exception.
 * \note After successfully executing the function, the property connectedFlag will be set to TRUE
 * \elseif Chinese
 * \brief 创建与设备的连接
 *
 * 根据portInfo中指定的端口信息，创建与设备连接
 * \param [in]  portInfo    端口类型及端口信息
 * \return void
 * \exception 连接创建失败时会抛出 ExceptionSDK 类型异常
 * \note 函数执行成功后，属性 connectedFlag 会被置为TRUE
 * \endif
 */
- (void)connect:(PortInfo*)portInfo;

/**
 * \if English
 * \brief Send data to device
 *
 * Send the data in the dataBuffer whose length is dataSize to the device. The successfully sent data will be saved in hasWritedBytes.
 * \param [in]  dataBuffer      The internal memory address of the data to be sent
 * \param [in]  dataSize        Number of data bytes specified to be sent
 * \param [out] hasWritedBytes  After successfully executing the function, save the successfully sent bytes
 * \return void
 * \exception When the parameter is invalid, cause ExceptionSDK type exception.
 * \elseif Chinese
 * \brief 下发数据到设备
 *
 * 将dataBuffer中长度为dataSize的数据下发到设备，成功下发的字节数保存到hasWritedBytes中
 * \param [in]  dataBuffer      待下发数据的内存地址
 * \param [in]  dataSize        指定下发的数据字节数
 * \param [out] hasWritedBytes  函数执行完成后，保存成功下发的字节数
 * \return void
 * \exception 参数无效时会抛出 ExceptionSDK 类型异常
 * \endif
 */
- (void)write:(UInt8*)dataBuffer
     dataSize:(UInt32)dataSize
hasWritedBytes:(UInt32*)hasWritedBytes;

/**
 * \if English
 * \brief Read data from device
 *
 * Read the data whose length is dataSize from the device, and the read data will be stored in dataBuffer.The actually read data length will be stored in hasWritedBytes.
 * \param [out] receiveBuffer   Internal memory address of receiving data
 * \param [in]  readBytes       Specify the number of bytes of read data
 * \param [out] hasReadBytes    After successfully executing the function, save the successfully read bytes
 * \return void
 * \exception When the parameter is invalid, cause ExceptionSDK type exception.
 * \note
 * \elseif Chinese
 * \brief 从设备中读取数据
 *
 * 从设备中读取指定长度dataSize的数据，读取到的数据存储在dataBuffer，实际读取到的数据长度会被存储到hasWritedBytes中
 * \param [out] receiveBuffer   接收数据内存地址
 * \param [in]  readBytes       指定读取的数据字节数
 * \param [out] hasReadBytes    函数执行完成后，该参数中保存成功读取的字节数
 * \return void
 * \exception 参数无效时会抛出 ExceptionSDK 类型异常
 * \note
 * \endif
 */
- (void)read:(UInt8*)receiveBuffer
   readBytes:(UInt32)readBytes
hasReadBytes:(UInt32*)hasReadBytes;

- (NSData*)readDataToString:(NSString*)stopString;
- (NSData*)readDataToData:(NSData*)stopData;

/**
 * \if English
 * \brief Close the connection with device
 *
 * If the connection is valid, then close the connection with device.
 * \note After finishing executing the function, the property connectedFlag will be set to FALSE.
 * \elseif Chinese
 * \brief 关闭与设备的连接
 *
 * 若连接有效则关闭与设备的连接
 * \note 函数执完成后，属性 connectedFlag 会被置为FALSE
 * \endif
 */
- (void)disconnect;

/**
 * \if English
 * \brief Get connecting information
 *
 * \return Return connecting information
 * \note There is no need to release for the returned instance.
 * \elseif Chinese
 * \brief 获取连接信息
 *
 * \return 返回连接信息
 * \note 返回对象无需release
 * \endif
 */
- (NSString*)getConnectionInfo;

/**
 * \if English
 * \brief Send data to device
 *
 * Send the data to device, and the successfully sent bytes will be saved to hasWritedBytes after finishing executing the function.
 * \param [in]  data            Data to be sent
 * \param [out] hasWritedBytes  After finishing executing the function, save the successfully sent bytes in this parameter.
 * \return
 * \exception When the data is nil or the length of data is 0, cause ExceptionSDK type exception.
 * \note
 * \elseif Chinese
 * \brief 下发数据到设备
 *
 * 将数据data下发到设备，函数执行完成后成功下发的字节数将会被保存到hasWritedBytes中
 * \param [in]  data            待下发的数据
 * \param [out] hasWritedBytes  函数执行完成后，该参数中保存成功下发的字节数
 * \return
 * \exception data为nil或长度为0时会抛出 ExceptionSDK 类型异常
 * \note
 * \endif
 */
- (void)write:(NSData*)data
hasWritedBytes:(UInt32*)hasWritedBytes;

/**
 * \if English
 * \brief Send the data in the file to the device
 *
 * Send the data in the fileName to device
 * \param [in]  fileName      Name of file that includes path
 * \return
 * \exception When the parameter is invalid, cause ExceptionSDK type exception.
 * \note
 * \elseif Chinese
 * \brief 将文件中的数据下发到设备
 *
 * 将文件fileName中数据下发到设备
 * \param [in]  fileName      包含路径的文件名称
 * \return
 * \exception 参数无效时会抛出 ExceptionSDK 类型异常
 * \note
 * \endif
 */
- (void)writeFile:(NSString*)fileName;

/**
 * \if English
 * \brief Read data from the device
 *
 * Read the data, whose length is readBytes, from the device
 * \param [in]  readBytes      Length of data to be read
 * \return Return nil when no data is read; otherwise return the read data.
 * \exception When the parameter is invalid, cause ExceptionSDK type exception.
 * \note There is no need to release for the read data.
 * \elseif Chinese
 * \brief 从设备中读取数据
 *
 * 从设备中读取长度为readBytes的数据
 * \param [in]  readBytes      需要读取的数据长度
 * \return 未读取到数据时返回nil；否则返回读取到的数据
 * \exception 参数无效失败时会抛出 ExceptionSDK 类型异常
 * \note 返回对象无需release
 * \endif
 */
- (NSData*)read:(UInt32)readBytes;
@end

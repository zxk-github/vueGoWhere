/**
 * \file ExceptionSDK.h
 * \copyright
 * \if English
 * This document is owned by Shandong New Beiyang Information Technology Co., Ltd. Without the express written permission of SNBC,
 * no part of this document may be reproduced or transmitted in any form or by any means.\n
 * Shandong New Beiyang Information Technology Co., Ltd. 2015
 * \elseif Chinese
 * 本文档为山东新北洋信息技术股份有限公司所有。未经山东新北洋信息技术股份有效公司书面授权，
 * 任何人不得以任何形式进行再次分发或复制。\n
 * 山东新北洋信息技术股份有限公司。2015
 * \endif
 */

#import <Foundation/Foundation.h>
#import "SDKBase.h"

/**
 * \if English
 * \brief Format the function name and row number to character string.
 * \elseif Chinese
 * \brief 将函数名及行号格式化为字符串
 * \endif
 */
#define EXCEPTION_REASON [NSString stringWithFormat:@"%s(%d)", __FUNCTION__, __LINE__]

/**
 * \if English
 * \brief Build exception instance and throw
 * \note The instance will destroy automatically without releasing.
 * \elseif Chinese
 * \brief 构建异常对象并抛出
 * \note 对象自动销毁，无需release
 * \endif
 */
#define exceptionWithCode(code) @throw [[[ExceptionSDK alloc] initWithReason:EXCEPTION_REASON errorCode:code] autorelease];

/**
 * \if English
 *  \brief
 * \brief SDK exception type
 *
 * Get exceptional code and description through the exception type
 * \elseif Chinese
 *  \brief SDK异常类
 *
 * 通过该异常类可捕获异常代码及异常描述
 * \endif
 */
@interface ExceptionSDK : NSException

#pragma mark -
#pragma mark class property

/**
 * \if English
 * \brief Exceptional code
 * \elseif Chinese
 * \brief 异常代码
 * \endif
 */
@property (nonatomic, readonly) CommandErrorCode errorCode;

/**
 * \if English
 * \brief Exceptional description
 * \note There is no need to release for returned instance
 * \elseif Chinese
 * \brief 异常描述
 * \note 返回对象无需release
 * \endif
 */
@property (nonatomic, retain)   NSString  *errorDecsription;

#pragma mark -
#pragma mark class init

/**
 * \if English
 * \brief Build exceptional instance
 *
 * Build exceptional instance according to reason and newErrorCode.
 * \param [in]  reason          Exceptional description
 * \param [in]  newErrorCode    Exceptional code
 * \elseif Chinese
 * \brief 构建异常对象
 *
 * 根据reason及newErrorCode构建异常对象
 * \param [in]  reason          异常描述
 * \param [in]  newErrorCode    异常代码
 * \endif
 */
- (instancetype)initWithReason:(NSString *)reason
                     errorCode:(CommandErrorCode)newErrorCode;

@end
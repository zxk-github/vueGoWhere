/**
 * \file SDKBase.h
 * \copyright
 * \if English
 * This document is owned by Shandong New Beiyang Information Technology Co., Ltd. Without the express written permission of SNBC,
 * no part of this document may be reproduced or transmitted in any form or by any means.\n
 * Shandong New Beiyang Information Technology Co., Ltd. 2015
 * \elseif Chinese
 * 本文档为山东新北洋信息技术股份有限公司所有。未经山东新北洋信息技术股份有效公司书面授权，
 * 任何人不得以任何形式进行再次分发或复制。\n
 * 山东新北洋信息技术股份有限公司。2015
 * \endif
 */
/**
 * \if English
 * \brief Printer language
 * \elseif Chinese
 * \brief 打印机语言
 * \endif
 */
typedef enum
{
    /**
     * \if English
     * \brief BPLZ language
     * \elseif Chinese
     * \brief BPLZ语言
     * \endif
     */
    PRINTER_LANGUAGE_BPLZ = 1,
    
    /**
     * \if English
     * \brief BPLE language
     * \elseif Chinese
     * \brief BPLE语言
     * \endif
     */
    PRINTER_LANGUAGE_BPLE,
    
    /**
     * \if English
     * \brief BPLC language
     * \elseif Chinese
     * \brief BPLC语言
     * \endif
     */
    PRINTER_LANGUAGE_BPLC,
    
    /**
     * \if English
     * \brief BPLT language
     * \elseif Chinese
     * \brief BPLT语言
     * \endif
     */
    PRINTER_LANGUAGE_BPLT,
    
    /**
     * \if English
     * \brief BPLA language
     * \elseif Chinese
     * \brief BPLA语言
     * \endif
     */
    PRINTER_LANGUAGE_BPLA,
    
    /**
     * \if English
     * \brief Reserve
     * \elseif Chinese
     * \brief 预留
     * \endif
     */
    PRINTER_LANGUAGE_MAX_NUM
}PrinterLanguage;

/**
 * \if English
 * \brief Paper type
 * \elseif Chinese
 * \brief 纸张类型
 * \endif
 */
typedef enum
{
    /**
     * \if English
     * \brief Label paper with gap
     * \elseif Chinese
     * \brief 有间隙的标签纸
     * \endif
     */
    PAPER_MODE_LABEL_WITH_GAPS = 1,
    
    /**
     * \if English
     * \brief Continuous paper
     * \elseif Chinese
     * \brief 连续纸
     * \endif
     */
    PAPER_MODE_CONTINUOUS,
    
    /**
     * \if English
     * \brief Label paper with marks
     * \elseif Chinese
     * \brief 有标记的标签纸
     * \endif
     */
    PAPER_MODE_LABEL_WITH_MARK,
    
    /**
     * \if English
     * \brief Reserve, not use
     * \elseif Chinese
     * \brief 预留，不使用
     * \endif
     */
    PAPER_MODE_LABEL_WITH_NOTCHES,
    
    /**
     * \if English
     * \brief It it sutiable for BPLA, and means non-continuous paper
     * \elseif Chinese
     * \brief 适用于BPLA指令集，表示非连续纸
     * \endif
     */
    PAPER_MODE_NONCONTINUOUS
    
}PaperMode;

/**
 * \if English
 * \brief Sensor mode
 * \elseif Chinese
 * \brief 传感器模式
 * \endif
 */
typedef enum
{
    /**
     * \if English
     * \brief Auto mode
     * \elseif Chinese
     * \brief 自动模式
     * \endif
     */
    SENSOR_MODE_AUTO = 1,
    
    /**
     * \if English
     * \brief Reflective sensor
     * \elseif Chinese
     * \brief 反射传感器
     * \endif
     */
    SENSOR_MODE_REFLECTIVE,
    
    /**
     * \if English
     * \brief Transmissive sensor
     * \elseif Chinese
     * \brief 透射传感器
     * \endif
     */
    SENSOR_MODE_TRANSMISSIVE
}SensorMode;


/**
 * \if English
 * \brief Print method
 * \elseif Chinese
 * \brief 打印方法
 * \endif
 */
typedef enum
{
    /**
     * \if English
     * \brief Thermal printing
     * \elseif Chinese
     * \brief 热敏打印
     * \endif
     */
    PRINT_METHOD_DIRECT = 1,
    
    /**
     * \if English
     * \brief Thermal transfer printing
     * \elseif Chinese
     * \brief 热转印打印
     * \endif
     */
    PRINT_METHOD_TRANSFER
}PrintMethod;

/**
 * \if English
 * \brief Print mode
 * \elseif Chinese
 * \brief 打印模式
 * \endif
 */
typedef enum
{
    /**
     * \if English
     * \brief Tear-off mode
     * \elseif Chinese
     * \brief 撕离模式
     * \endif
     */
    PRINT_MODE_TEAROFF = 1,
    
    /**
     * \if English
     * \brief Peal-off mode
     * \elseif Chinese
     * \brief 剥离模式
     * \endif
     */
    PRINT_MODE_PEELOFF,
    
    /**
     * \if English
     * \brief Rewind mode
     * \elseif Chinese
     * \brief 回卷模式
     * \endif
     */
    PRINT_MODE_REWIND,
    
    /**
     * \if English
     * \brief Cut mode
     * \elseif Chinese
     * \brief 切纸模式
     * \endif
     */
    PRINT_MODE_CUTTER
}PrintMode;


/**
 * \if English
 * \brief Print direction
 * \elseif Chinese
 * \brief 打印方向
 * \endif
 */
typedef enum
{
    /**
     * \if English
     * \brief Normal direction printing
     * \elseif Chinese
     * \brief 正常方向打印
     * \endif
     */
    PRINT_DIRECTION_NORAML = 1,
    
    /**
     * \if English
     * \brief Rotation 180° printing
     * \elseif Chinese
     * \brief 旋转180度打印
     * \endif
     */
    PRINT_DIRECTION_180
}PrintDirection;

/**
 * \if English
 * \brief Measuring unit
 * \note This type is reserved, and SDK does not support.
 * \elseif Chinese
 * \brief 计量单位
 * \note 该类型预留，SDK暂不支持
 * \endif
 */
typedef enum
{
    /**
     * \if English
     * \brief Dot system, unit: dot
     * \elseif Chinese
     * \brief 点制，单位点
     * \endif
     */
    MEASURING_UNIT_DOTS = 1,
    
    /**
     * \if English
     * \brief Inch system, unit: 0.01 inch
     * \elseif Chinese
     * \brief 英制，单位0.01英寸
     * \endif
     */
    MEASURING_UNIT_INCHES,
    
    /**
     * \if English
     * \brief Meter system, unit: 0.1mm
     * \elseif Chinese
     * \brief 米制，单位0.1mm
     * \endif
     */
    MEASURING_UNIT_MILLIMETERS
}MeasuringUnit;

/**
 * \if English
 * \brief Rotation angle of printing
 * \elseif Chinese
 * \brief 打印旋转角度
 * \endif
 */
typedef enum
{
    /**
     * \if English
     * \brief Rotate 0°
     * \elseif Chinese
     * \brief 旋转0度
     * \endif
     */
    ROTATED_0 = 0,
    
    /**
     * \if English
     * \brief Rotate 90° clockwise
     * \elseif Chinese
     * \brief 顺时针旋转90度
     * \endif
     */
    ROTATED_90 = 90,
    
    /**
     * \if English
     * \brief Rotate 180°
     * \elseif Chinese
     * \brief 旋转180度
     * \endif
     */
    ROTATED_180 = 180,
    
    /**
     * \if English
     * \brief Rotate 270° clockwise
     * \elseif Chinese
     * \brief 顺时针旋转270度
     * \endif
     */
    ROTATED_270 = 270
}Rotation;

/**
 * \if English
 * \brief Barcode type
 * \elseif Chinese
 * \brief 条码类型
 * \endif
 */
typedef enum
{
    /**
     * \if English
     * \brief Code 128
     * \elseif Chinese
     * \brief code 128码
     * \endif
     */
    BARCODE_CODE128 = 1,
    
    /**
     * \if English
     * \brief Code 39
     * \elseif Chinese
     * \brief code 39码
     * \endif
     */
    BARCODE_CODE39,
    
    /**
     * \if English
     * \brief Code 93
     * \elseif Chinese
     * \brief code 93码
     * \endif
     */
    BARCODE_CODE93,
    
    /**
     * \if English
     * \brief EAN-8 code
     * \elseif Chinese
     * \brief EAN-8码
     * \endif
     */
    BARCODE_CODEEAN8,
    
    /**
     * \if English
     * \brief EAN-13 code
     * \elseif Chinese
     * \brief EAN-13码
     * \endif
     */
    BARCODE_CODEEAN13,
    
    /**
     * \if English
     * \brief codebar code
     * \elseif Chinese
     * \brief codebar码
     * \endif
     */
    BARCODE_CODABAR,
    
    /**
     * \if English
     * \brief ITF25 code
     * \elseif Chinese
     * \brief ITF25码
     * \endif
     */
    BARCODE_ITF25,
    
    /**
     * \if English
     * \brief UPC-A code
     * \elseif Chinese
     * \brief UPC-A码
     * \endif
     */
    BARCODE_UPCA,
    
    /**
     * \if English
     * \brief UPC-E code
     * \elseif Chinese
     * \brief UPC-E码
     * \endif
     */
    BARCODE_UPCE
}BarcodeType;

/**
 * \if English
 * \brief Time structure
 * \elseif Chinese
 * \brief 时间结构
 * \endif
 */
typedef struct
{
    /**
     * \if English
     * \brief Month
     * \elseif Chinese
     * \brief 月
     * \endif
     */
    UInt32 month;
    
    /**
     * \if English
     * \brief Day
     * \elseif Chinese
     * \brief 日
     * \endif
     */
    UInt32 day;
    
    /**
     * \if English
     * \brief Year
     * \elseif Chinese
     * \brief 年
     * \endif
     */
    UInt32 year;
    
    /**
     * \if English
     * \brief Hour
     * \elseif Chinese
     * \brief 时
     * \endif
     */
    UInt32 hour;
    
    /**
     * \if English
     * \brief Minute
     * \elseif Chinese
     * \brief 分
     * \endif
     */
    UInt32 minute;
    
    /**
     * \if English
     * \brief Second
     * \elseif Chinese
     * \brief 秒
     * \endif
     */
    UInt32 second;
}ClockPara;

/**
 * \if English
 * \brief HRI character printing mode
 * \elseif Chinese
 * \brief HRI字符打印模式
 * \endif
 */
typedef enum
{
    /**
     * \if English
     * \brief Not print
     * \elseif Chinese
     * \brief 不打印
     * \endif
     */
    HRI_NONE = 0,
    
    /**
     * \if English
     * \brief Left alignment printing
     * \elseif Chinese
     * \brief 左对齐打印
     * \endif
     */
    HRI_ALIGN_LEFT,
    
    /**
     * \if English
     * \brief Central alignment printing
     * \elseif Chinese
     * \brief 居中对齐打印
     * \endif
     */
    HRI_ALIGN_CENTER,
    
    /**
     * \if English
     * \brief Right alignment printing
     * \elseif Chinese
     * \brief 右对齐打印
     * \endif
     */
    HRI_ALIGN_RIGHT
}HRIAlign;


/**
 * \if English
 * \brief Image binary method
 * \elseif Chinese
 * \brief 图像二值化方法
 * \endif
 */
typedef enum
{
    /**
     * \if English
     * \brief Shaking mode
     * \elseif Chinese
     * \brief 抖动模式
     * \endif
     */
    IMAGE_BINARIZE_DITHERING=1,
    
    /**
     * \if English
     * \brief Auto mode
     * \elseif Chinese
     * \brief 自动模式
     * \endif
     */
    IMAGE_BINARIZE_AUTO_THRESHOLD,
    
    /**
     * \if English
     * \brief Self-defined mode
     * \elseif Chinese
     * \brief 自定义模式
     * \endif
     */
    IMAGE_BINARIZE_CUSTOM_THRESHOLD,
}ImageBinarizeMethord;

/**
 * \if English
 * \brief QR code security level
 * \elseif Chinese
 * \brief QR码安全级别
 * \endif
 */
typedef enum
{
    /**
     * \if English
     * \brief Higher reliability level
     * \elseif Chinese
     * \brief 极高可靠性级别
     * \endif
     */
    QR_LEVEL_H = 'H',
    
    /**
     * \if English
     * \brief High reliability level
     * \elseif Chinese
     * \brief 高可靠性级别
     * \endif
     */
    QR_LEVEL_Q = 'Q',
    
    /**
     * \if English
     * \brief Standard level
     * \elseif Chinese
     * \brief 标准级别
     * \endif
     */
    QR_LEVEL_M = 'M',
    
    /**
     * \if English
     * \brief High density level
     * \elseif Chinese
     * \brief 高密度级别
     * \endif
     */
    QR_LEVEL_L = 'L'
}QRLevel;


/**
 * \if English
 * \brief QR mode
 * \elseif Chinese
 * \brief QR模式
 * \endif
 */
typedef enum
{
    /**
     * \if English
     * \brief Initial mode
     * \elseif Chinese
     * \brief 原始模式
     * \endif
     */
    QR_MODE_ORIGINAL = 1,
    
    /**
     * \if English
     * \brief Strengthen mode
     * \elseif Chinese
     * \brief 增强模式
     * \endif
     */
    QR_MODE_ENHANCED = 2
}QRMode;


/**
 * \if English
 * \brief Error code definition
 * \elseif Chinese
 * \brief 错误代码定义
 * \endif
 */
typedef enum
{
    CEC_SUCCESS = 0,
    CEC_FAILED = 1,
    CEC_UNSUPPORT,
    CEC_DISCOVER_DEVICE_FAILED,
    CEC_CREATE_CONNECT_FAILED,
    CEC_TIMEOUT,
    CEC_INVALID_CONNECTION,
    CEC_READ_FAILED,
    CEC_WRITE_FAILED,
    CEC_INVALID_PARAMETER,
    CEC_INVALID_DATA,
    CEC_ALLOC_MEMORY_FAIELD,
    CEC_MEM_INSUFFIENT,
    CEC_BWOTSU_Error,
}CommandErrorCode;

/**
 * \if English
 * \brief Codepage definition
 * \elseif Chinese
 * \brief 代码页定义
 * \endif
 */
typedef enum
{
    CODEPAGE_DEFAULT= -(0xFF01),    //Defaule codepage
    CODEPAGE_UTF8   = -(0xFF02),
    CODEPAGE_850    = -(0xFF03),
    CODEPAGE_1250   = -(0xFF04),
    CODEPAGE_1251   = -(0xFF05),
    CODEPAGE_1252   = -(0xFF06),
    CODEPAGE_1253   = -(0xFF07),
    CODEPAGE_1254   = -(0xFF08),
    CODEPAGE_1255   = -(0xFF09),
    CODEPAGE_936    = -(0xFF0A)
    
}Codepage;

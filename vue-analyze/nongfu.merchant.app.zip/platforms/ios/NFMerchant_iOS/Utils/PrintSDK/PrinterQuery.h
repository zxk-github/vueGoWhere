/**
 * \file PrinterQuery.h
 * \copyright
 * \if English
 * This document is owned by Shandong New Beiyang Information Technology Co., Ltd. Without the express written permission of SNBC,
 * no part of this document may be reproduced or transmitted in any form or by any means.\n
 * Shandong New Beiyang Information Technology Co., Ltd. 2015
 * \elseif Chinese
 * 本文档为山东新北洋信息技术股份有限公司所有。未经山东新北洋信息技术股份有效公司书面授权，
 * 任何人不得以任何形式进行再次分发或复制。\n
 * 山东新北洋信息技术股份有限公司。2015
 * \endif
 */

#import <Foundation/Foundation.h>
#import "Connection.h"
#import "SDKBase.h"
#import "Printer.h"

/**
 * \if English
 * \brief Length of printer name
 * \elseif Chinese
 * \brief 打印机名称长度
 * \endif
 */
#define PRINTER_NAME_LEN    (260)

/**
 * \if English
 * \brief Length of printer version
 * \elseif Chinese
 * \brief 打印机版本号长度
 * \endif
 */
#define VERSION_LEN			(128)

/**
 * \if English
 * \brief Length of printer SN
 * \elseif Chinese
 * \brief 打印机序列号长度
 * \endif
 */
#define SERIAL_NUMBER_LEN	(128)

/**
 * \if English
 * \brief Printer status structure
 * \elseif Chinese
 * \brief 打印机状态结构
 * \endif
 */
typedef struct
{
    /**
     * \if English
     * \brief Set as sizeof(PrinterStatus)
     * \elseif Chinese
     * \brief 设置为sizeof(PrinterStatus)
     * \endif
     */
    UInt32 selfSize;
    
    /**
     * \if English
     * \brief Printer language
     * \elseif Chinese
     * \brief 打印机语言
     * \endif
     */
    PrinterLanguage printerLanguage;
    
    /**
     * \if English
     * \brief TRUE indicates that the printer is in ready status and can receive print job and print;FALSE indicates that the printer is not ready and cannot print.
     * \elseif Chinese
     * \brief TRUE表示打印机为就绪状态，可以接收打印任务并打印；FALSE表示为未就绪状态，不可进行打印
     * \endif
     */
    BOOL isReadyToPrint;
    
    /**
     * \if English
     * \brief TRUE indicates that the printer is in pause status, under which status the printer cannot print.
     * \elseif Chinese
     * \brief TRUE表示打印机处于暂停状态，此状态下打印机不能打印
     * \endif
     */
    BOOL isPaused;
    
    /**
     * \if English
     * \brief TRUE indicates paper end of printer, and the printer cannot print under this status.
     * \elseif Chinese
     * \brief TRUE表示打印机缺纸，此状态下打印机不能打印
     * \endif
     */
    BOOL isPaperOut;
    
    /**
     * \if English
     * \brief Reserve, fixed to FALSE.
     * \elseif Chinese
     * \brief 预留，固定为FALSE
     * \endif
     */
    BOOL isPaperNearOut;
    
    /**
     * \if English
     * \brief TRUE indicates that the print head is too hot, and the printer cannot print under this status.
     * \note BPLZ/BPLT/BPLC support the function.
     * \elseif Chinese
     * \brief TRUE表示打印头过热，此状态下打印机不能打印
     * \note BPLZ/BPLT/BPLC支持此功能
     * \endif
     */
    BOOL isHeadTooHot;
    
    /**
     * \if English
     * \brief TRUE indicates that the cover of printer is open, and the printer cannot print under this status.
     * \elseif Chinese
     * \brief TRUE表示打印机处于开盖状态，此状态下打印机不能打印
     * \endif
     */
    BOOL isHeadOpened;
    
    /**
     * \if English
     * \brief TRUE indicates that the receive buffer of printer is full and the printer cannot receive data under this status.
     * \note BPLZ/BPLT/BPLC support the function.
     * \elseif Chinese
     * \brief TRUE表示打印机接收缓冲区满，此状态下打印机将不再接收数据
     * \note BPLZ/BPLT/BPLC支持此功能
     * \endif
     */
    BOOL isReceiveBufferFull;
    
    /**
     * \if English
     * \brief TRUE indicates that the ribbon has been used up and the printer cannot print under this status.
     * \elseif Chinese
     * \brief TRUE表示碳带用尽，此状态下打印机不能打印
     * \endif
     */
    BOOL isRibbonOut;
    
    /**
     * \if English
     * \brief Reserve, fix to FALSE.
     * \elseif Chinese
     * \brief 预留，固定为FALSE
     * \endif
     */
    BOOL isRibbonNearOut;
    
    /**
     * \if English
     * \brief TRUE indicates that the cutter is in error status and printer cannot print under this status.
     * \note BPLE/BPLT support the function
     * \elseif Chinese
     * \brief TRUE表示切刀处于错误状态，此状态下打印机不能打印
     * \note BPLZE/BPLT支持此功能
     * \endif
     */
    BOOL isCutterError;
    
    /**
     * \if English
     * \brief TRUE indicates that the printer is printing
     * \elseif Chinese
     * \brief TRUE表示打印机的正在进行打印
     * \endif
     */
    BOOL isPrinterBusy;
    
    /**
     * \if English
     * \brief Reserve, fixed to 0.
     * \elseif Chinese
     * \brief 预留，固定为0
     * \endif
     */
    UInt32 hasOtherError;
}PrinterStatus;


/**
 * \if English
 * \brief Configuration structure of printer
 * \elseif Chinese
 * \brief 打印机配置结构
 * \endif
 */
typedef struct
{
    /**
     * \if English
     * \brief Set as sizeof(PrinterSetting)
     * \elseif Chinese
     * \brief 设置为sizeof(PrinterSetting)
     * \endif
     */
    UInt32          selfSize;
    
    /**
     * \if English
     * \brief Printer name
     * \elseif Chinese
     * \brief 打印机名称
     * \endif
     */
    SInt8           printerName[PRINTER_NAME_LEN];
    
    /**
     * \if English
     * \brief Print speed, unit: inch/s
     * \elseif Chinese
     * \brief 打印速度，单位inch/s
     * \endif
     */
    UInt32          printSpeed;
    
    /**
     * \if English
     * \brief Print darkness, range: 0-30
     * \elseif Chinese
     * \brief 打印浓度，范围0-30
     * \endif
     */
    UInt32          printDensity;
    
    /**
     * \if English
     * \brief Paper mode
     * \elseif Chinese
     * \brief 纸张模式
     * \endif
     */
    PaperMode       paperMode;
    
    /**
     * \if English
     * \brief Print resolution, unit: DPI
     * \elseif Chinese
     * \brief 打印分辨率，单位DPI
     * \endif
     */
    UInt32          resolution;
    
    /**
     * \if English
     * \brief Sensor mode
     * \elseif Chinese
     * \brief 传感器模式
     * \endif
     */
    SensorMode      sensorMode;
    
    /**
     * \if English
     * \brief Label length, unit: dot
     * \elseif Chinese
     * \brief 标签长度，单位点
     * \endif
     */
    UInt32          labelLength;
    
    /**
     * \if English
     * \brief Printer version
     * \elseif Chinese
     * \brief 打印机版本号
     * \endif
     */
    SInt8           firmwareVersion[VERSION_LEN];
    
    /**
     * \if English
     * \brief Printer serial number
     * \elseif Chinese
     * \brief 打印机序列号
     * \endif
     */
    SInt8           serialNumber[SERIAL_NUMBER_LEN];
    
    /**
     * \if English
     * \brief Tear-off offset, unit: dot
     * \elseif Chinese
     * \brief 撕离偏移量，单位点
     * \endif
     */
    UInt32          tearOffset;
    
    /**
     * \if English
     * \brief Print mode
     * \elseif Chinese
     * \brief 打印模式
     * \endif
     */
    PrintMode       printMode;
    
    /**
     * \if English
     * \brief Print method
     * \elseif Chinese
     * \brief 打印方法
     * \endif
     */
    PrintMethod     printMethod;
    
    /**
     * \if English
     * \brief Vertical offset of print position, unit: dot
     * \elseif Chinese
     * \brief 打印位置纵向偏移量，单位点
     * \endif
     */
    UInt32          printVerticalOffset;
    
    /**
     * \if English
     * \brief Horizontal offset of print position, unit: dot
     * \elseif Chinese
     * \brief 打印位置横向偏移量，单位点
     * \endif
     */
    UInt32          printHorizontalOffset;
    
    /**
     * \if English
     * \brief Print direction
     * \elseif Chinese
     * \brief 打印方向
     * \endif
     */
    PrintDirection  printDirection;
}PrinterSetting;

@class Printer;

/**
 * \if English
 * \brief Printer inquiry
 *
 *Printer status and configuration inquiry
 * \elseif Chinese
 * \brief 打印机查询
 *
 * 打印机状态及配置查询
 * \endif
 */
@interface PrinterQuery : NSObject

#pragma mark -
#pragma mark class property

#pragma mark -
#pragma mark class init
/**
 * \if English
 * \brief Establish printer inquiring part
 *
 * Establish printer inquiring part
 * \param [in]  delegate        Printer instance
 * \param [in]  printerLanguage Printer language
 * \return
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \elseif Chinese
 * \brief 构建打印机查询部件
 *
 * 构建打印机查询部件
 * \param [in]  delegate        打印机对象
 * \param [in]  printerLanguage 打印机语言
 * \return
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \endif
 */
- (instancetype)initWithDelegate:(id)delegate
                 printerLanguage:(PrinterLanguage)printerLanguage;

#pragma mark -
#pragma mark class method - printer status

/**
 * \if English
 * \brief Inquire printer status
 *
 * Inquire printer status
 * \return Printer status
 * \exception ExceptionSDK
 * \elseif Chinese
 * \brief 查询打印机状态
 *
 * 查询打印机状态
 * \return 打印机状态
 * \exception ExceptionSDK
 * \endif
 */
- (PrinterStatus)getPrinterStatus;

/**
 * \if English
 * \brief Inquire printer language
 *
 * Inquire printer language
 * \return Printer language
 * \exception ExceptionSDK
 * \elseif Chinese
 * \brief 查询打印机语言
 *
 * 查询打印机语言
 * \return 打印机语言
 * \exception ExceptionSDK
 * \endif
 */
- (PrinterLanguage)getPrinterLanguage;

/**
 * \if English
 * \brief Inquire whether the printer is ready or not
 *
 * \return  When the printer is ready, return TRUE and the printer can receive print job under this status; Otherwise return FALSE.
 * \elseif Chinese
 * \brief 查询打印是否就绪
 *
 * \return  打印机处于就绪状态时返回TRUE，该状态下打印机可接收打印任务；否则返回FALSE
 * \endif
 */
- (BOOL)isReadyToPrint;

/**
 * \if English
 * \brief Inquire whether the printer pauses or not
 *
 * \return When the printer pauses, return TRUE; Otherwise return FALSE.
 * \elseif Chinese
 * \brief 查询打印是否暂停
 *
 * \return 打印机处于暂停状态时返回TRUE；否则返回FALSE
 * \endif
 */
- (BOOL)isPaused;

/**
 * \if English
 * \brief Inquire whether the paper has been used up or not
 *
 * \return When the paper is used up, return TRUE; Otherwise return FALSE.
 * \elseif Chinese
 * \brief 查询纸张是否用尽
 *
 * \return 纸用尽时返回TRUE；否则返回FALSE
 * \endif
 */
- (BOOL)isPaperOut;

/**
 * \if English
 * \brief Reserve, fixed to return FALSE.
 * \elseif Chinese
 * \brief 预留，固定返回FALSE
 * \endif
 */
- (BOOL)isPaperNearOut;

/**
 * \if English
 * \brief Inquire whether the print head is too hot or not
 *
 * \return When the print head is too hot, return TRUE and the printer stops printing under this status; Otherwise return FALSE.
 * \elseif Chinese
 * \brief 查询打印头是否过热
 *
 * \return 打印头过热时返回TRUE，此状态下需停止打印；否则返回FALSE
 * \endif
 */
- (BOOL)isHeadTooHot;

/**
 * \if English
 * \brief Inquire whether the top cover of printer is open or not
 *
 * \return When the top cover of printer is open, return TRUE; Otherwise return FALSE.
 * \elseif Chinese
 * \brief 查询打印机上盖是否开启
 *
 * \return 打印机上盖打开时返回TRUE；否则返回FALSE
 * \endif
 */
- (BOOL)isHeadOpened;

/**
 * \if English
 * \brief Inquire whether the receive buffer of printer has been full or not
 *
 * \return When the receive buffer of printer is full, return TRUE and APP should stop sending data; Otherwise return FALSE.
 * \elseif Chinese
 * \brief 查询打印机接收缓冲区是否已满
 *
 * \return 打印机接收缓冲区满时返回TRUE，此时APP应停止下发数据；否则返回FALSE
 * \endif
 */
- (BOOL)isReceiveBufferFull;

/**
 * \if English
 * \brief Inquire whether the ribbon has been used up or not
 *
 * \return When the ribbon is used up, return TRUE; Otherwise return FALSE.
 * \elseif Chinese
 * \brief 查询碳带是否用尽
 *
 * \return 碳带用尽时返回TRUE；否则返回FALSE
 * \endif
 */
- (BOOL)isRibbonOut;

/**
 * \if English
 * \brief Reserve, fixed to return FALSE.
 * \elseif Chinese
 * \brief 预留，固定返回FALSE
 * \endif
 */
- (BOOL)isRibbonNearOut;

/**
 * \if English
 * \brief Inquire whether the cutter has error or not
 *
 * \return When the cutter has error, return TRUE; Otherwise return FALSE.
 * \elseif Chinese
 * \brief 查询切刀是否存在错误
 *
 * \return 切刀出错时返回TRUE；否则返回FALSE
 * \endif
 */
- (BOOL)isCutterError;

/**
 * \if English
 * \brief Inquire whether the printer is busy or not
 *
 * \return When the printer is busy, return TRUE; Otherwise return FALSE.
 * \elseif Chinese
 * \brief 查询打印机是否忙
 *
 * \return 打印机忙时返回TRUE；否则返回FALSE
 * \endif
 */
- (BOOL)isPrinterBusy;

/**
 * \if English
 * \brief Inquire the error code
 * \note Reserve, fixed to return 0
 * \elseif Chinese
 * \brief 查询错误代码
 * \note 预留，固定返回0
 * \endif
 */
- (UInt32)hasOtherError;

#pragma mark -
#pragma mark class method - font/image/format

/**
 * \if English
 * \brief Inquire the name of each format stored in printer
 *
 * Inquire the name of each format stored in printer
 * \return format name list
 * \exception ExceptionSDK
 * \note The returned NSArray does not need to release; BPLZ/BPLE/BPLC support the function.
 * \elseif Chinese
 * \brief 查询打印机中存储的各format名称
 *
 * 查询打印机中存储的各format名称
 * \return format名称列表
 * \exception ExceptionSDK
 * \note 返回对象NSArray无需release；BPLZ/BPLE/BPLC支持此功能
 * \endif
 */
- (NSArray*)getFormatFileName;

/**
 * \if English
 * \brief Inquire the contents of the format file stored in printer
 *
 * Inquire the contents of the format file stored in printer
 * \param [in]  fileName    format name
 * \return Contents of format file
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note The returned NSData does not need to release; The BPLZ language supports the function.
 * \elseif Chinese
 * \brief 查询打印机中存储的format文件内容
 *
 * 查询打印机中存储的名为fileName的format文件内容
 * \param [in]  fileName    format名称
 * \return format文件内容
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note 返回对象NSData无需release；BPLZ语言支持此功能
 * \endif
 */
- (NSData*)getFormatFileContent:(NSString*)fileName;

/**
 * \if English
 * \brief Inquire the name of image stored in printer
 *
 * Inquire the name of image stored in printer
 * \return Name of image file stored in printer
 * \exception ExceptionSDK
 * \note The returned NSArray does not need to release.
 * \elseif Chinese
 * \brief 查询打印机中存储的各图像名称
 *
 * 查询打印机中存储的各图像名称
 * \return 打印机中存储的图像文件名称
 * \exception ExceptionSDK
 * \note 返回对象NSArray无需release
 * \endif
 */
- (NSArray*)getImageFileName;

/**
 * \if English
 * \brief Inquire the font name stored in printer
 *
 * Inquire the font name stored in printer
 * \return Font name stored in printer
 * \exception ExceptionSDK
 * \note The returned NSArray does not need to release; BPLZ/BPLT/BPLC support the function.
 * \elseif Chinese
 * \brief 查询打印机中存储的字体名称
 *
 * 查询打印机中存储的字体名称
 * \return 打印机中存储的字体名称
 * \exception ExceptionSDK
 * \note 返回对象NSArray无需release；BPLZ/BPLT/BPLC支持此功能
 * \endif
 */
- (NSArray*)getFontFileName;

#pragma mark -
#pragma mark class method - printer setting

/**
 * \if English
 * \brief Inquire the size of Ram and Flash
 *
 * Inquire the size of Ram and Flash
 * \param [out]  flashBytes    Return number of flash bytes
 * \param [out]  ramBytes      Return the number of ram bytes
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note BPLE only returns the size of flash.
 * \elseif Chinese
 * \brief 查询Ram及Flash大小
 *
 * 查询Ram及Flash大小
 * \param [out]  flashBytes    返回flash字节数
 * \param [out]  ramBytes      返回ram字节数
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note BPLE只返回flash大小
 * \endif
 */
- (void)getRemainingMemory:(UInt32*)flashBytes
                  ramBytes:(UInt32*)ramBytes;


/**
 * \if English
 * \brief Inquire the printer configuration
 *
 * Inquire the printer configuration
 * \return Printer status
 * \exception ExceptionSDK
 * \elseif Chinese
 * \brief 查询打印机配置
 *
 * 查询打印机配置
 * \return 打印机状态
 * \exception ExceptionSDK
 * \endif
 */
- (PrinterSetting)getPrinterSetting;

/**
 * \if English
 * \brief Inquire the name of printer
 * \return Printer name
 * \note The returned NSString does not need to release.
 * \elseif Chinese
 * \brief 查询打印机名称
 * \return 打印机名称
 * \note 返回对象NSString无需release
 * \endif
 */
- (NSString*)getPrinterName;

/**
 * \if English
 * \brief Inquire the print speed
 * \return Print speed
 * \elseif Chinese
 * \brief 查询打印速度
 * \return 打印速度
 * \endif
 */
- (UInt32)getPrintSpeed;

/**
 * \if English
 * \brief Inquire the print darkness
 * \return Print darkness，range:0-30
 * \note BPLZ/BPLE/BPLT support the  function
 * \elseif Chinese
 * \brief 查询打印浓度
 * \return 打印浓度，范围0-30
 * \note BPLZ/BPLE/BPLT支持此功能
 * \endif
 */
- (UInt32)getPrintDensity;

/**
 * \if English
 * \brief Inquire the paper mode
 * \return Paper mode
 * \elseif Chinese
 * \brief 查询纸张模式
 * \return 纸张模式
 * \endif
 */
- (PaperMode)getPaperMode;

/**
 * \if English
 * \brief Inquire the print resolution
 * \return The returned print resolution, unit: DPI
 * \elseif Chinese
 * \brief 查询打印分辨率
 * \return 返回打印分辨率，单位为DPI
 * \endif
 */
- (UInt32)getResolution;

/**
 * \if English
 * \brief Inquire the sensor mode
 * \return Sensor mode
 * \elseif Chinese
 * \brief 查询传感器模式
 * \return 传感器模式
 * \endif
 */
- (SensorMode)getSensorMode;

/**
 * \if English
 * \brief Inquire the length of label
 * \return Label length, unit: dot
 * \elseif Chinese
 * \brief 查询标签长度
 * \return 标签长度，单位点
 * \endif
 */
- (UInt32)getLabelLength;

/**
 * \if English
 * \brief Inquire the printer version
 * \return Printer version
 * \note The returned NSString does not need to release.
 * \elseif Chinese
 * \brief 查询打印机版本号
 * \return 打印机版本号
 * \note 返回对象NSString无需release
 * \endif
 */
- (NSString*)getFirmwareVersion;

/**
 * \if English
 * \brief Inquire the printer serial number
 * \return Printer serial number
 * \note The returned NSString does not need to release.
 * \elseif Chinese
 * \brief 查询打印机序列号
 * \return 打印机序列号
 * \note 返回对象NSString无需release
 * \endif
 */
- (NSString*)getSerialNumber;

/**
 * \if English
 * \brief Inquire the SDK version
 * \return SDK version
 * \note The returned NSString does not need to release.
 * \elseif Chinese
 * \brief 查询SDK版本号
 * \return SDK版本号
 * \note 返回对象NSString无需release
 * \endif
 */
- (NSString*)getSDKVersion;

/**
 * \if English
 * \brief Inquire the tear-off distance
 * \return Tear-off distance, unit: dot
 * \elseif Chinese
 * \brief 查询撕离距离
 * \return 撕离距离，单位点
 * \endif
 */
- (SInt32)getTearOffset;

/**
 * \if English
 * \brief Inquire the print mode
 * \return Print mode
 * \elseif Chinese
 * \brief 查询打印模式
 * \return 打印模式
 * \endif
 */
- (PrintMode)getPrintMode;

/**
 * \if English
 * \brief Inquire the print method
 * \return Print method
 * \elseif Chinese
 * \brief 查询打印方法
 * \return 打印方法
 * \endif
 */
- (PrintMethod)getPrintMethod;

/**
 * \if English
 * \brief Inquire the vertical print offset
 * \return Vertical print offset, unit: dot
 * \elseif Chinese
 * \brief 查询纵向打印偏移量
 * \return纵向打印偏移量，单位点
 * \endif
 */
- (SInt32)getPrintVerticalOffset;

/**
 * \if English
 * \brief Inquire the horizontal print offset
 * \return Horizontal print offset, unit: dot
 * \elseif Chinese
 * \brief 查询横向打印偏移量
 * \return 横向打印偏移量，单位点
 * \endif
 */
- (SInt32)getprintHorizontalOffset;

/**
 * \if English
 * \brief Inquire the print direction
 * \return Print direction
 * \note BPLZ/BPLE/BPLT support the function
 * \elseif Chinese
 * \brief 查询打印方向
 * \return 打印方向
 * \note BPLZ/BPLE/BPLT支持此功能
 * \endif
 */
- (PrintDirection)getPrintDirection;
@end
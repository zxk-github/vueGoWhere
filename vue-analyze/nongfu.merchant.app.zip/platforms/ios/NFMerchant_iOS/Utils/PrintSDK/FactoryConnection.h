/**
 * \file FactoryConnection.h
 * \copyright
 * \if English
 * This document is owned by Shandong New Beiyang Information Technology Co., Ltd. Without the express written permission of SNBC,
 * no part of this document may be reproduced or transmitted in any form or by any means.\n
 * Shandong New Beiyang Information Technology Co., Ltd. 2015
 * \elseif Chinese
 * 本文档为山东新北洋信息技术股份有限公司所有。未经山东新北洋信息技术股份有效公司书面授权，
 * 任何人不得以任何形式进行再次分发或复制。\n
 * 山东新北洋信息技术股份有限公司。2015
 * \endif
 */

#import <Foundation/Foundation.h>
#import "Connection.h"

/**
 * \if English
 *  \brief Communication connection building factory
 *
 * Build and manage communication connection instance
 * \elseif Chinese
 *  \brief 通讯连接构建工厂
 *
 * 构建并管理通讯连接对象
 * \endif
 */
@interface FactoryConnection : NSObject

/**
 * \if English
 * \brief Build the communication connection instance
 *
 * Build the communication connection instance according to portInfo
 * \param [in]  portInfo    Port information
 * \return Connection type instance
 * \exception When the portInfo data is invalid, cause ExceptionSDK type abnormality.
 * \note The instance built through this method does not need to be destroyed, and FactoryConnection will destroy automatically.
 * \elseif Chinese
 * \brief 构建通讯连接对象
 *
 * 根据portInfo构建通讯连接对象
 * \param [in]  portInfo    端口信息
 * \return Connection 类型的对象
 * \exception portInfo数据无效时会抛出 ExceptionSDK 类型异常
 * \note 该方法创建的对象无需销毁， FactoryConnection 会进行自动销毁
 * \endif
 */
- (Connection*)createConnection:(PortInfo*)portInfo;

@end

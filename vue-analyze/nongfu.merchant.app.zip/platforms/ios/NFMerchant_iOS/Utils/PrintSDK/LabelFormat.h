/**
 * \file LabelFormat.h
 * \copyright
 * \if English
 * This document is owned by Shandong New Beiyang Information Technology Co., Ltd. Without the express written permission of SNBC,
 * no part of this document may be reproduced or transmitted in any form or by any means.\n
 * Shandong New Beiyang Information Technology Co., Ltd. 2015
 * \elseif Chinese
 * 本文档为山东新北洋信息技术股份有限公司所有。未经山东新北洋信息技术股份有效公司书面授权，
 * 任何人不得以任何形式进行再次分发或复制。\n
 * 山东新北洋信息技术股份有限公司。2015
 * \endif
 */

#import <Foundation/Foundation.h>
#import "Connection.h"
#import "SDKBase.h"
#import "Printer.h"

@class Printer;

/**
 * \if English
 *  \brief Format downloading and printing
 *
 * Realize the function of format downloading and printing
 * \elseif Chinese
 *  \brief format下载及打印
 *
 * 实现format下载及打印功能
 * \endif
 */
@interface LabelFormat : NSObject

#pragma mark -
#pragma mark class property


#pragma mark -
#pragma mark class init

/**
 * \if English
 * \brief Establish format downloading and printing part
 *
 * Establish format downloading and printing part
 * \param [in]  delegate        Printer instance
 * \param [in]  printerLanguage Printer language
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \elseif Chinese
 * \brief 构建format下载及打印部件
 *
 * 构建format下载机打印部件
 * \param [in]  delegate        打印机对象
 * \param [in]  printerLanguage 打印机语言
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \endif
 */
- (instancetype)initWithDelegate:(id)delegate
                 printerLanguage:(PrinterLanguage)printerLanguage;

#pragma mark -
#pragma mark class method

/**
 * \if English
 * \brief Download format to printer
 *
 * Download format to printer
 * \param [in]  filePath    Format file name that includes path
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note BPLZ/BPLE/BPLC support the function.
 * \elseif Chinese
 * \brief 下载format到打印机
 *
 * 下载format到打印机
 * \param [in]  filePath    包含路径的format文件名称
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note BPLZ/BPLE/BPLC支持此功能
 * \endif
 */
- (void)downloadFormat:(NSString*)filePath;

/**
 * \if English
 * \brief Format printing
 *
 * Format printing
 * \param [in]  formatName  Format name stored in printer, the name is queried by getFormatFileName
 * \param [in]  keyValue    Assembly of variable data corresponding with format
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note BPLZ/BPLE/BPLC support the function.
 * \elseif Chinese
 * \brief format打印
 *
 * format打印
 * \param [in]  formatName  打印机中存储的format名称；该名称可以通过getFormatFileName获取
 * \param [in]  keyValue    与format对应的变量数据集合
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note BPLZ/BPLE/BPLC支持此功能
 * \endif
 */
- (void)printStoredFormat:(NSString*)formatName
                 keyValue:(NSDictionary*)keyValue;
@end

/**
 * \file PrinterControl.h
 * \copyright
 * \if English
 * This document is owned by Shandong New Beiyang Information Technology Co., Ltd. Without the express written permission of SNBC,
 * no part of this document may be reproduced or transmitted in any form or by any means.\n
 * Shandong New Beiyang Information Technology Co., Ltd. 2015
 * \elseif Chinese
 * 本文档为山东新北洋信息技术股份有限公司所有。未经山东新北洋信息技术股份有效公司书面授权，
 * 任何人不得以任何形式进行再次分发或复制。\n
 * 山东新北洋信息技术股份有限公司。2015
 * \endif
 */

#import <Foundation/Foundation.h>
#import "Connection.h"
#import "SDKBase.h"
#import "Printer.h"

@class Printer;

/**
 * \if English
 * \brief Printer control
 *
 * Control the movement of printer
 * \elseif Chinese
 * \brief 打印机控制
 *
 * 控制打印机的运动
 * \endif
 */
@interface PrinterControl : NSObject

#pragma mark -
#pragma mark class property


#pragma mark -
#pragma mark class init
/**
 * \if English
 * \brief Build printer control part
 *
 * Build printer control part
 * \param [in]  delegate        Printer instance
 * \param [in]  printerLanguage Printer language
 * \return
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \elseif Chinese
 * \brief 构建打印机控制部件
 *
 * 构建打印机控制部件
 * \param [in]  delegate        打印机对象
 * \param [in]  printerLanguage 打印机语言
 * \return
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \endif
 */
- (instancetype)initWithDelegate:(id)delegate
                 printerLanguage:(PrinterLanguage)printerLanguage;

#pragma mark -
#pragma mark class method

/**
 * \if English
 * \brief Start printing
 *
 * Start printing
 * \param [in]  labelNum      Number of printout
 * \param [in]  copyNum       Copies of variable domain, the BPLT command set supports the function.
 * \return void
 * \exception ExceptionSDK
 * \note
 * \elseif Chinese
 * \brief 启动打印
 *
 * 启动打印
 * \param [in]  labelNum      打印份数
 * \param [in]  copyNum       变域份数,BPLT指令集支持此功能
 * \return void
 * \exception ExceptionSDK
 * \note
 * \endif
 */
- (void)print:(UInt32)labelNum
      copyNum:(UInt32)copyNum;

/**
 * \if English
 * \brief Feed one piece of label
 *
 * Feed one piece of label
 * \return void
 * \exception ExceptionSDK
 * \note
 * \elseif Chinese
 * \brief 进一张标签
 *
 * 进一张标签
 * \return void
 * \exception ExceptionSDK
 * \note
 * \endif
 */
- (void)feedLabel;

/**
 * \if English
 * \brief Cut paper
 *
 * Cut paper
 * \return void
 * \exception ExceptionSDK
 * \note BPLZ/BPLE/BPLT support the function
 * \elseif Chinese
 * \brief 切纸
 *
 * 切纸
 * \return void
 * \exception ExceptionSDK
 * \note BPLZ/BPLE/BPLT支持此功能
 * \endif
 */
- (void)cut;

/**
 * \if English
 * \brief Start calibration
 *
 * Start calibration
 * \return void
 * \exception ExceptionSDK
 * \note
 * \elseif Chinese
 * \brief 启动校验
 *
 * 启动校验
 * \return void
 * \exception ExceptionSDK
 * \note
 * \endif
 */
- (void)calibrate;

/**
 * \if English
 * \brief Restart device
 *
 * Restart device
 * \return void
 * \exception ExceptionSDK
 * \note
 * \elseif Chinese
 * \brief 重启设备
 *
 * 重启设备
 * \return void
 * \exception ExceptionSDK
 * \note
 * \endif
 */
- (void)reboot;

/**
 * \if English
 * \brief Print self-test page
 *
 * Print self-test page
 * \return void
 * \exception ExceptionSDK
 * \note
 * \elseif Chinese
 * \brief 打印自检页
 *
 * 打印自检页
 * \return void
 * \exception ExceptionSDK
 * \note
 * \endif
 */
- (void)printSelfCheckingPage;

/**
 * \if English
 * \brief Print the printer configuration
 *
 * Print the printer configuration
 * \return void
 * \exception ExceptionSDK
 * \note
 * \elseif Chinese
 * \brief 打印打印机配置
 *
 * 打印打印配置
 * \return void
 * \exception ExceptionSDK
 * \note
 * \endif
 */
- (void)printConfiguration;

/**
 * \if English
 * \brief Self-test of printer
 *
 * Self-test of printer
 * \return TRUE indicates that the self-test is successful and can work normally; FALSE indicates that the self-test fails and cannot work normally.
 * \exception ExceptionSDK
 * \note
 * \note Reserved method, unrealized function.
 * \elseif Chinese
 * \brief 打印机自检
 *
 * 打印机自检
 * \return TRUE表示自检成功，可正常工作；FALSE表示打印机自检失败，不能正常工作
 * \exception ExceptionSDK
 * \note
 * \note 预留方法，功能暂未实现
 * \endif
 */
- (BOOL)SelfCheck;
@end

/**
 * \file ImageAndFont.h
 * \copyright
 * \if English
 * This document is owned by Shandong New Beiyang Information Technology Co., Ltd. Without the express written permission of SNBC,
 * no part of this document may be reproduced or transmitted in any form or by any means.\n
 * Shandong New Beiyang Information Technology Co., Ltd. 2015
 * \elseif Chinese
 * 本文档为山东新北洋信息技术股份有限公司所有。未经山东新北洋信息技术股份有效公司书面授权，
 * 任何人不得以任何形式进行再次分发或复制。\n
 * 山东新北洋信息技术股份有限公司。2015
 * \endif
 */

#import <Foundation/Foundation.h>
#import "Connection.h"
#import "SDKBase.h"
#import "Printer.h"

@class Printer;

/**
 * \if English
 *  \brief Image and fonts downloading
 *
 * Realize the function of downloading image and fonts
 * \elseif Chinese
 *  \brief 图像及字库下载
 *
 * 实现图像及字库下载功能
 * \endif
 */
@interface ImageAndFont : NSObject

#pragma mark -
#pragma mark class property


#pragma mark -
#pragma mark class init

/**
 * \if English
 * \brief Establish image and fonts downloading part
 *
 * Establish image and fonts downloading part
 * \param [in]  delegate        Printer instance
 * \param [in]  printerLanguage Printer language
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \elseif Chinese
 * \brief 构建图像及字库下载部件
 *
 * 构建图像及字库下载部件
 * \param [in]  delegate        打印机对象
 * \param [in]  printerLanguage 打印机语言
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \endif
 */
- (instancetype)initWithDelegate:(id)delegate
                 printerLanguage:(PrinterLanguage)printerLanguage;

#pragma mark -
#pragma mark class method

/**
 * \if English
 * \brief Download TTF vector fonts to printer
 *
 * Download TTF vector fonts filePath to printer
 * \param [in]  filePath        Name of TTF fonts file that includes path
 * \param [in]  storedName      Name of fonts used while storing in printer;the length of storedName should less than 8; for BPLZ/BPLT, the format of file name like "R:\\a.ttf" and "E:\\b.ttf"; for BPLE/BPLC, the format of file name like "c.ttf"
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note BPLZ/BPLT/BPLC command sets support the function.
 * \elseif Chinese
 * \brief 将TTF格式矢量字库下载到打印机
 *
 * 将TTF矢量字库filePath下载到打印机
 * \param [in]  filePath        包含路径的TTF字库文件名称
 * \param [in]  storedName      在打印机中存储时使用的字库名称;长度不超过8字节;对于BPLZ和BPLT，文件名格式为“盘符:\\文件名.扩展名”，“R:\\a.ttf”表示存储在Ram中名为a.ttf的文件，“E:\\b.ttf”表示存储在Flash中名为b.ttf的文件; 对于BPLE和BPLC，文件名格式为“文件名.扩展名”，“c.ttf”表示存储在打印机中名为c.ttf的文件
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note BPLZ/BPLT/BPLC指令集支持此功能
 * \endif
 */
- (void)downloadTTF:(NSString*)filePath
         storedName:(NSString*)storedName;

/**
 * \if English
 * \brief Download image to printer
 *
 * Download image filePath to printer
 * \param [in]  filePath        File name that includes path
 * \param [in]  storedName      Image name used while storing in printer;the length of storedName should less than 8; for BPLZ/BPLT, the format of file name like "R:\\a.bmp" and "E:\\b.bmp"; for BPLE/BPLC, the format of file name like "c.bmp"
 * \param [in]  binarizeMethord Image managing mode
 * \param [in]  customThreshold Self-defined threshold, use when binarizeMethord is IMAGE_BINARIZE_CUSTOM_THRESHOLD.
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note BPLZ/BPLT command sets support the function.
 * \elseif Chinese
 * \brief 将图像下载到打印机
 *
 * 将图像filePath下载到打印机
 * \param [in]  filePath        包含路径的文件名称
 * \param [in]  storedName      在打印机中存储时使用的图像名称;长度不超过8字节;对于BPLZ和BPLT，文件名格式为“盘符:\\文件名.扩展名”，“R:\\a.bmp”表示存储在Ram中名为a.bmp的文件，“E:\\b.bmp”表示存储在Flash中名为b.bmp的文件; 对于BPLE和BPLC，文件名格式为“文件名.扩展名”，“c.bmp”表示存储在打印机中名为c.bmp的文件
 * \param [in]  binarizeMethord 图像处理模式
 * \param [in]  customThreshold 自定义阈值，当binarizeMethord为IMAGE_BINARIZE_CUSTOM_THRESHOLD时使用
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note BPLZ/BPLT指令集支持此功能
 * \endif
 */
- (void)downloadImage:(NSString*)filePath
           storedName:(NSString*)storedName
      binarizeMethord:(ImageBinarizeMethord) binarizeMethord
      customThreshold:(UInt32)customThreshold;

/**
 * \if English
 * \brief Download UIImage image to printer
 *
 * Download image to printer
 * \param [in]  image           UIImage instance
 * \param [in]  storedName      Image name used while storing in printer;the length of storedName should less than 8; for BPLZ/BPLT, the format of file name like "R:\\a.bmp" and "E:\\b.bmp"; for BPLE/BPLC, the format of file name like "c.bmp"
 * \param [in]  binarizeMethord Image managing mode
 * \param [in]  customThreshold Self-defined threshold, use when binarizeMethord is IMAGE_BINARIZE_CUSTOM_THRESHOLD.
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note This function adopts BMP format to download image; BPLZ/BPLT command sets support the function.
 * \elseif Chinese
 * \brief 将UIImage图像下载到打印机
 *
 * 将图像image下载到打印机
 * \param [in]  image           UIImage对象
 * \param [in]  storedName      在打印机中存储时使用的图像名称;长度不超过8字节;对于BPLZ和BPLT，文件名格式为“盘符:\\文件名.扩展名”，“R:\\a.bmp”表示存储在Ram中名为a.bmp的文件，“E:\\b.bmp”表示存储在Flash中名为b.bmp的文件; 对于BPLE和BPLC，文件名格式为“文件名.扩展名”，“c.bmp”表示存储在打印机中名为c.bmp的文件
 * \param [in]  binarizeMethord 图像处理模式
 * \param [in]  customThreshold 自定义阈值，当binarizeMethord为IMAGE_BINARIZE_CUSTOM_THRESHOLD时使用
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note 本函数采用BMP格式下载图像；BPLZ/BPLT指令集支持此功能
 * \endif
 */
- (void)downloadUIImage:(UIImage*)image
             storedName:(NSString*)storedName
        binarizeMethord:(ImageBinarizeMethord) binarizeMethord
        customThreshold:(UInt32)customThreshold;


/**
 * \if English
 * \brief Download bitmap image to printer
 *
 * Download bitmap image filePath to printer
 * \param [in]  filePath        File name that includes path
 * \param [in]  storedName      Image name used while storing in printer;the length of storedName should less than 8; for BPLZ/BPLT, the format of file name like "R:\\a.bmp" and "E:\\b.bmp"; for BPLE/BPLC, the format of file name like "c.bmp"
 * \param [in]  binarizeMethord Image managing mode
 * \param [in]  customThreshold Self-defined threshold, use when binarizeMethord is IMAGE_BINARIZE_CUSTOM_THRESHOLD.
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note BPLZ/BPLT command sets support the function.
 * \elseif Chinese
 * \brief 将bitmap图像下载到打印机
 *
 * 将bitmap格式的图像filePath下载到打印机
 * \param [in]  filePath        包含路径的文件名称
 * \param [in]  storedName      在打印机中存储时使用的图像名称;长度不超过8字节;对于BPLZ和BPLT，文件名格式为“盘符:\\文件名.扩展名”，“R:\\a.bmp”表示存储在Ram中名为a.bmp的文件，“E:\\b.bmp”表示存储在Flash中名为b.bmp的文件; 对于BPLE和BPLC，文件名格式为“文件名.扩展名”，“c.bmp”表示存储在打印机中名为c.bmp的文件
 * \param [in]  binarizeMethord 图像处理模式
 * \param [in]  customThreshold 自定义阈值，当binarizeMethord为IMAGE_BINARIZE_CUSTOM_THRESHOLD时使用
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note BPLZ/BPLT指令集支持此功能
 * \endif
 */
- (void)downloadBMP:(NSString*)filePath
         storedName:(NSString*)storedName
    binarizeMethord:(ImageBinarizeMethord) binarizeMethord
    customThreshold:(UInt32)customThreshold;

/**
 * \if English
 * \brief Download PCX image to printer
 *
 * Download PCX image filePath to printer
 * \param [in]  filePath        File name that includes path
 * \param [in]  storedName      Name used while storing in printer;the length of storedName should less than 8; for BPLZ/BPLT, the format of file name like "R:\\a.pcx" and "E:\\b.pcx"; for BPLE/BPLC, the format of file name like "c.pcx"
 * \param [in]  binarizeMethord Image managing mode
 * \param [in]  customThreshold Self-defined threshold, use when binarizeMethord is IMAGE_BINARIZE_CUSTOM_THRESHOLD.
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note This function supports single-color pcx image; BPLE/BPLT/BPLC command sets support the function.
 * \elseif Chinese
 * \brief 将PCX图像下载到打印机
 *
 * 将PCX格式的图像filePath下载到打印机
 * \param [in]  filePath        包含路径的文件名称
 * \param [in]  storedName      在打印机中存储时使用的名称;长度不超过8字节;对于BPLZ和BPLT，文件名格式为“盘符:\\文件名.扩展名”，“R:\\a.pcx”表示存储在Ram中名为a.pcx的文件，“E:\\b.pcx”表示存储在Flash中名为b.pcx的文件; 对于BPLE和BPLC，文件名格式为“文件名.扩展名”，“c.pcx”表示存储在打印机中名为c.pcx的文件
 * \param [in]  binarizeMethord 图像处理模式
 * \param [in]  customThreshold 自定义阈值，当binarizeMethord为IMAGE_BINARIZE_CUSTOM_THRESHOLD时使用
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note 本函数支持单色pcx图像；BPLE/BPLT/BPLC指令集支持此功能
 * \endif
 */
- (void)downloadPCX:(NSString*)filePath
         storedName:(NSString*)storedName
    binarizeMethord:(ImageBinarizeMethord) binarizeMethord
    customThreshold:(UInt32)customThreshold;
@end

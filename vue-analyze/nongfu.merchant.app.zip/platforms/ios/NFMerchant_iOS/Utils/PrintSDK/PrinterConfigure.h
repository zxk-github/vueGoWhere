/**
 * \file PrinterConfigure.h
 * \copyright
 * \if English
 * This document is owned by Shandong New Beiyang Information Technology Co., Ltd. Without the express written permission of SNBC,
 * no part of this document may be reproduced or transmitted in any form or by any means.\n
 * Shandong New Beiyang Information Technology Co., Ltd. 2015
 * \elseif Chinese
 * 本文档为山东新北洋信息技术股份有限公司所有。未经山东新北洋信息技术股份有效公司书面授权，
 * 任何人不得以任何形式进行再次分发或复制。\n
 * 山东新北洋信息技术股份有限公司。2015
 * \endif
 */

#import <Foundation/Foundation.h>
#import "SDKBase.h"
#import "Connection.h"
#import "Printer.h"

@class Printer;

/**
 * \if English
 *  \brief Printer configuration
 *
 * Realize the function of configuring each parameter of printer
 * \elseif Chinese
 *  \brief 打印机配置
 *
 * 实现打印机各项参数的配置功能
 * \endif
 */
@interface PrinterConfigure : NSObject

#pragma mark -
#pragma mark class property

#pragma mark -
#pragma mark class init
/**
 * \if English
 * \brief Build the printer configuring part
 *
 * Build the printer configuring part
 * \param [in]  delegate        Printer instance
 * \param [in]  printerLanguage Printer language
 * \return void
 * \exception When the parameter is illegal,cause ExceptionSDK type exception.
 * \elseif Chinese
 * \brief 构建打印机配置部件
 *
 * 构建打印机配置部件
 * \param [in]  delegate        打印机对象
 * \param [in]  printerLanguage 打印机语言
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \endif
 */
- (instancetype)initWithDelegate:(id)delegate
                 printerLanguage:(PrinterLanguage)printerLanguage;

#pragma mark -
#pragma mark class method

/**
 * \if English
 * \brief Restore the printer to factory settings
 * \elseif Chinese
 * \brief 将打印机恢复为出厂配置
 * \endif
 */
- (void)restoreDefaults;

/**
 * \if English
 * \brief Delete file
 *
 * Delete the file whose name is fileName in the printer
 * \param [in]  fileName      File name to be deleted; For BPLZ, take "A.FNT" file as example, format: R:A.FNT, among which R indicates RAM and E indicates FLASH; For BPLE, take "A.FNT" file as example, format: A; For BPLT, take "lion.pcx" file as example, format: If delete the file in RAM, the format is lion.pcx and if delete the file in FLASH, the format is F,"lion.pcx", among which disk F indicates FLASH and RAM ignores the disk; For BPLC, take "lion.pcx" file as example, format: lion.pcx.
 * \return void
 * \exception When the parameter is illegal,cause ExceptionSDK type exception.
 * \note
 * \elseif Chinese
 * \brief 删除文件
 *
 * 删除打印机中名称为fileName的文件
 * \param [in]  fileName      待删除的文件名称；BPLZ以“A.FNT”文件为例，格式如：R:A.FNT，其中R表示RAM，E表示FLASH；BPLE以“A.FNT”文件为例，格式如：A；BPLT以“lion.pcx”文件为例，格式如：删除RAM中的文件为lion.pcx，删除FLASH中的文件为F,"lion.pcx"，其中盘符F表示FLASH，RAM省略盘符；BPLC以“lion.pcx”文件为例，格式如：lion.pcx。
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note 删除文件
 * \endif
 */
- (void)deleteFile:(NSString*)fileName;

/**
 * \if English
 * \brief Format the printer flash
 *
 * Format the printer flash
 * \return void
 * \exception ExceptionSDK
 * \note
 * \elseif Chinese
 * \brief 格式化打印机flash
 *
 * 将打印机flash格式化
 * \return void
 * \exception ExceptionSDK
 * \note
 * \endif
 */
- (void)formatFlash;

/**
 * \if English
 * \brief Set the clock of printer
 *
 * Set the clock of printer
 * \param [in]  clockPara      Time
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note
 * \elseif Chinese
 * \brief 设置打印机时钟
 *
 * 设置打印机时钟
 * \param [in]  clockPara      时间
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note
 * \endif
 */
- (void)setClock:(ClockPara)clockPara;

/**
 * \if English
 * \brief Set the print speed
 *
 * Set the print speed
 * \param [in]  printSpeed      Print speed, unit: inch/s
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note In BPLA mode, it is valid to call this method after setLabelSize.
 * \elseif Chinese
 * \brief 设置打印速度
 *
 * 设置打印速度
 * \param [in]  printSpeed      打印速度，单位inch/s
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note 在BPLA指令集模式下，该函数在setLabelSize后执行有效
 * \endif
 */
- (void)setPrintSpeed:(UInt32)printSpeed;

/**
 * \if English
 * \brief Set the print darkness
 *
 * Set the print darkness
 * \param [in]  printDensity      Print darkness, range: 0-30, the larger number and the higher darkness.
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note In BPLA mode, it is valid to call this method after setLabelSize.
 * \elseif Chinese
 * \brief 设置打印浓度
 *
 * 设置打印浓度
 * \param [in]  printDensity      打印浓度，范围为0-30，数值越大浓度越高
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note 在BPLA指令集模式下，该函数在setLabelSize后执行有效
 * \endif
 */
- (void)setPrintDensity:(UInt32)printDensity;

/**
 * \if English
 * \brief Set paper type
 *
 * Set paper type
 * \param [in]  paperMode      Paper type
 * \return void
 * \exception ExceptionSDK
 * \note
 * \elseif Chinese
 * \brief 设置纸张类型
 *
 * 设置纸张类型
 * \param [in]  paperMode      纸张类型
 * \return void
 * \exception ExceptionSDK
 * \note
 * \endif
 */
- (void)setPaperMode:(PaperMode)paperMode;

/**
 * \if English
 * \brief Set the tear-off distance
 *
 * Set the tear-off distance
 * \param [in]  offset      Tear -off offset, unit: dot
 * \return void
 * \exception ExceptionSDK
 * \note BPLZ/BPLT/BPLC support the function
 * \elseif Chinese
 * \brief 设置撕离距离
 *
 * 设置撕离距离
 * \param [in]  offset      撕离偏移量，单位点
 * \return void
 * \exception ExceptionSDK
 * \note BPLZ/BPLT/BPLC支持此功能
 * \endif
 */
- (void)setTearOffset:(SInt32)offset;

/**
 * \if English
 * \brief Set the print mode and method
 *
 * Set the print mode and method
 * \param [in]  printMode      Print mode
 * \param [in]  printMethod    Print method
 * \return void
 * \exception ExceptionSDK
 * \note BPLZ/BPLE/BPLT/BPLC support the function
 * \elseif Chinese
 * \brief 设置打印模式及方法
 *
 * 设置打印模式及方法
 * \param [in]  printMode      打印模式
 * \param [in]  printMethod    打印方法
 * \return void
 * \exception ExceptionSDK
 * \note BPLZ/BPLE/BPLT/BPLC支持此功能
 * \endif
 */
- (void)setPrintMode:(PrintMode)printMode
         printMethod:(PrintMethod)printMethod;

/**
 * \if English
 * \brief Set the print mode and method
 *
 * Set the print mode and method
 * \param [in]  printMode      Print mode
 * \param [in]  printMethod    Print method
 * \param [in]  distance       distance between print head and paper out position
 * \return void
 * \exception ExceptionSDK
 * \note BPLA support the function
 * \elseif Chinese
 * \brief 设置打印模式及方法
 *
 * 设置打印模式及方法
 * \param [in]  printMode      打印模式
 * \param [in]  printMethod    打印方法
 * \param [in]  distance       出纸口与打印头间的距离
 * \return void
 * \exception ExceptionSDK
 * \note BPLA支持此接口
 * \endif
 */
- (void)setPrintMode:(PrintMode)printMode
         printMethod:(PrintMethod)printMethod
            distance:(SInt32)distance;

/**
 * \if English
 * \brief Set the offset of label
 *
 * Set the offset of label
 * \param [in]  offsetX         Horizontal offset, unit: dot
 * \param [in]  offsetY         Vertical offset, unit: dot
 * \return void
 * \exception ExceptionSDK
 * \note BPLZ support the function.
 * \elseif Chinese
 * \brief 设置标签偏移量
 *
 * 设置标签偏移量
 * \param [in]  offsetX         横向偏移量，单位点
 * \param [in]  offsetY         纵向偏移量，单位点
 * \return void
 * \exception ExceptionSDK
 * \note BPLZ支持此功能
 * \endif
 */
- (void)setLabelOffset:(SInt32)offsetX
               offsetY:(SInt32)offsetY;

/**
 * \if English
 * \brief Set the print direction
 *
 * Set the print direction
 * \param [in]  printDirection Print direction
 * \return void
 * \exception ExceptionSDK
 * \note
 * \elseif Chinese
 * \brief 设置打印方向
 *
 * 设置打印方向
 * \param [in]  printDirection 打印方向
 * \return void
 * \exception ExceptionSDK
 * \note
 * \endif
 */
- (void)setPrintDirection:(PrintDirection)printDirection;

/**
 * \if English
 * \brief Device binding
 *
 * Device binding
 * \param [in]  subContent      Contents to be verified
 * \return void
 * \exception ExceptionSDK
 * \note Reserved function, not support temporarily
 * \elseif Chinese
 * \brief 设备绑定
 *
 * 设备绑定
 * \param [in]  subContent      待验证内容
 * \return void
 * \exception ExceptionSDK
 * \note 预留功能，暂不支持
 * \endif
 */
- (BOOL)bindPrinter:(NSString*)subContent;

@end

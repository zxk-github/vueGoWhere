/**
 * \file Printer.h
 * \copyright
 * \if English
 * This document is owned by Shandong New Beiyang Information Technology Co., Ltd. Without the express written permission of SNBC,
 * no part of this document may be reproduced or transmitted in any form or by any means.\n
 * Shandong New Beiyang Information Technology Co., Ltd. 2015
 * \elseif Chinese
 * 本文档为山东新北洋信息技术股份有限公司所有。未经山东新北洋信息技术股份有效公司书面授权，
 * 任何人不得以任何形式进行再次分发或复制。\n
 * 山东新北洋信息技术股份有限公司。2015
 * \endif
 */

#import "Connection.h"
#import "PrinterConfigure.h"
#import "PrinterControl.h"
#import "PrinterQuery.h"
#import "LabelEdit.h"
#import "LabelFormat.h"
#import "ImageAndFont.h"

@class PrinterQuery;
@class PrinterControl;
@class PrinterConfigure;
@class LabelEdit;
@class LabelFormat;
@class ImageAndFont;

/**
 * \if English
 *  \brief Printer class
 *
 * The printer class includes seven properties, and APP can interact with printer through the seven properties.
 * \elseif Chinese
 *  \brief 打印机类
 *
 * 打印机类包含七个属性，APP可通过这七个属性与打印机进行交互
 * \endif
 */
@interface Printer : NSObject

/**
 * \if English
 * \brief Printer inquiry
 * \elseif Chinese
 * \brief 打印机查询
 * \endif
 */
@property (nonatomic, retain, readonly) PrinterQuery        *printerQuery;

/**
 * \if English
 * \brief Printer control
 * \elseif Chinese
 * \brief 打印机控制
 * \endif
 */
@property (nonatomic, retain, readonly) PrinterControl      *printerControl;

/**
 * \if English
 * \brief Printer configuration
 * \elseif Chinese
 * \brief 打印机配置
 * \endif
 */
@property (nonatomic, retain, readonly) PrinterConfigure    *printerConfigure;

/**
 * \if English
 * \brief Label editing
 * \elseif Chinese
 * \brief 标签编辑
 * \endif
 */
@property (nonatomic, retain, readonly) LabelEdit           *labelEdit;

/**
 * \if English
 * \brief Format downloading and label printing based on format
 * \elseif Chinese
 * \brief format下载及基于format的标签打印
 * \endif
 */
@property (nonatomic, retain, readonly) LabelFormat         *labelFormat;

/**
 * \if English
 * \brief Image and fonts downloading
 * \elseif Chinese
 * \brief 图像及字体下载
 * \endif
 */
@property (nonatomic, retain, readonly) ImageAndFont        *imageAndFont;

/**
 * \if English
 * \brief Device reading and writing
 * \elseif Chinese
 * \brief 设备读写
 * \endif
 */
@property (nonatomic, retain, readonly) Connection          *directIO;

/**
 * \if English
 * \brief Establish printer class according to communication connection.
 *
 * Establish printer class according to communication connection.
 * \param [in]  connection      Communication connection instance
 * \exception When the connection is invalid or the connectedFlag of connection is FALSE, cause ExceptionSDK type exception.
 * \note This method is only for internal use.
 * \elseif Chinese
 * \brief 根据通讯连接构建打印机类
 *
 * 根据通讯连接构建打印机类
 * \param [in]  connection      通讯连接对象
 * \exception connection无效或connection的connectedFlag为FALSE时会抛出ExceptionSDK类型异常
 * \note 该方法限内部使用
 * \endif
 */
- (instancetype)initWithConnection:(Connection*)connection;

/**
 * \if English
 * \brief Set each part of printer
 *
 * Set each part of printer
 * \param [in]  printerQuery    Printer querying part
 * \param [in]  printerControl  Printer control part
 * \param [in]  printerConfigure Printer configuring part
 * \param [in]  labelEdit   Label editing part
 * \param [in]  labelFormat format part
 * \param [in]  imageAndFont    Image and fonts part
 * \exception When the above parts are illegal, cause ExceptionSDK type exception.
 * \note This method is only for internal use.
 * \elseif Chinese
 * \brief 设置打印机各部件
 *
 * 设置打印机的各部件
 * \param [in]  printerQuery    打印机查询部件
 * \param [in]  printerControl  打印机控制部件
 * \param [in]  printerConfigure 打印机配置部件
 * \param [in]  labelEdit   标签编辑部件
 * \param [in]  labelFormat format部件
 * \param [in]  imageAndFont    图像及字库部件
 * \exception 上述部件非法时会抛出ExceptionSDK类型异常
 * \note 该方法限内部使用
 * \endif
 */
- (void)setPrinterParts:(PrinterQuery*)printerQuery
         printerControl:(PrinterControl*)printerControl
       printerConfigure:(PrinterConfigure*)printerConfigure
              labelEdit:(LabelEdit*)labelEdit
            labelFormat:(LabelFormat*)labelFormat
           imageAndFont:(ImageAndFont*)imageAndFont;
@end

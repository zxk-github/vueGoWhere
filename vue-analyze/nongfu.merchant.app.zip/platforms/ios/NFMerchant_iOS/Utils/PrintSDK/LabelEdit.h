/**
 * \file LabelEdit.h
 * \copyright
 * \if English
 * This document is owned by Shandong New Beiyang Information Technology Co., Ltd. Without the express written permission of SNBC,
 * no part of this document may be reproduced or transmitted in any form or by any means.\n
 * Shandong New Beiyang Information Technology Co., Ltd. 2015
 * \elseif Chinese
 * 本文档为山东新北洋信息技术股份有限公司所有。未经山东新北洋信息技术股份有效公司书面授权，
 * 任何人不得以任何形式进行再次分发或复制。\n
 * 山东新北洋信息技术股份有限公司。2015
 * \endif
 */

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Connection.h"
#import "SDKBase.h"
#import "Printer.h"

@class Printer;

/**
 * \if English
 *  \brief Label editing
 *
 *Realize the function of editing label
 * \elseif Chinese
 *  \brief 标签编辑
 *
 * 实现标签编辑功能
 * \endif
 */
@interface LabelEdit : NSObject
{
    UInt32          labelWidth;
    UInt32          LabelHeight;
    SInt32          labelSpaceHor;
    SInt32          labelSpaceVer;
    UInt32          labelColumns;
}
#pragma mark -
#pragma mark class property

/**
 * \if English
 * \brief Coding method, default: NSUTF8StringEncoding
 * \elseif Chinese
 * \brief 编码方式，默认为NSUTF8StringEncoding
 * \endif
 */
@property (nonatomic, assign, readwrite)NSStringEncoding    stringEncoding;

#pragma mark -
#pragma mark class init

/**
 * \if English
 * \brief Establish label editing part
 *
 * Establish label editing part
 * \param [in]  delegate        Printer instance
 * \param [in]  printerLanguage Printer language
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \elseif Chinese
 * \brief 构建标签编辑部件
 *
 * 构建标签编辑部件
 * \param [in]  delegate        打印机对象
 * \param [in]  printerLanguage 打印机语言
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \endif
 */
- (instancetype)initWithDelegate:(id)delegate
                 printerLanguage:(PrinterLanguage)printerLanguage;

#pragma mark -
#pragma mark class method

/**
 * \if English
 * \brief Set the width and height of label
 *
 * Set the width and height of label
 * \param [in]  width      Label width, unit: dot
 * \param [in]  height     Label height, unit: dot
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \elseif Chinese
 * \brief 设置标签宽度及高度
 *
 * 设置标签宽度及高度
 * \param [in]  width      标签宽度，单位点
 * \param [in]  height     标签高度，单位点
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \endif
 */
- (void)setLabelSize:(UInt32)width
              height:(UInt32)height;


/**
 * \if English
 * \brief Print characters
 *
 * Print characters
 * \param [in]  x           Horizontal coordinate, unit: dot
 * \param [in]  y           Vertical coordinate, unit: dot
 * \param [in]  fontName    Font name, the name is queried by getFontFileName
 * \param [in]  content     Character string to be printed
 * \param [in]  angle       Rotation angle of printing
 * \param [in]  sizeHorizontal  Horizontal enlargement times or dots of words
 * \param [in]  sizeVertical    Vertical enlargement times or dots of words
 * \param [in]  reverse    if set to TRUE, print text with black background; otherwise, print text with white background. Only BPLE support this param
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \elseif Chinese
 * \brief 打印字符
 *
 * 打印字符
 * \param [in]  x           横坐标，单位点
 * \param [in]  y           纵坐标，单位点
 * \param [in]  fontName    字体名称；该名称可以通过getFontFileName获取
 * \param [in]  content     待打印的字符串
 * \param [in]  angle       打印旋转角度
 * \param [in]  sizeHorizontal  文字横向放大倍数或点数
 * \param [in]  sizeVertical    文字纵向放大倍数或点数
 * \param [in]  reverse  当设置TRUE时，打印方式黑底白字；设置为FALSE时，打印方式为白底黑字.只有BPLE指令集支持此参数设置
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note
 * \endif
 */
- (void)printText:(UInt32)x
                y:(UInt32)y
         fontName:(NSString*)fontName
          content:(NSString*)content
            angle:(Rotation)angle
   sizeHorizontal:(UInt32)sizeHorizontal
     sizeVertical:(UInt32)sizeVertical
          reverse:(BOOL)reverse;

- (void)printText:(UInt32)x
                y:(UInt32)y
         fontName:(NSString*)fontName
          content:(NSString*)content
            angle:(Rotation)angle
   sizeHorizontal:(UInt32)sizeHorizontal
     sizeVertical:(UInt32)sizeVertical;

/**
 * \if English
 * \brief Print characters using the fonts in iOS device
 *
 * Print characters using the fonts in iOS device
 * \param [in]  x           Horizontal coordinate, unit: dot
 * \param [in]  y           Vertical coordinate, unit: dot
 * \param [in]  fontName    Name of fonts in the iOS system
 * \param [in]  fontSize    Font size, unit: dot
 * \param [in]  content     Character string to be printed
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note
 * \elseif Chinese
 * \brief 使用iOS设备中的字库打印字符
 *
 * 使用iOS设备中的字库打印字符
 * \param [in]  x           横坐标，单位点
 * \param [in]  y           纵坐标，单位点
 * \param [in]  fontName    iOS系统中的字体名称
 * \param [in]  fontSize    字符大小，单位点
 * \param [in]  content     待打印的字符串
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note
 * \endif
 */
- (void)printTextUseTTF:(UInt32)x
                      y:(UInt32)y
               fontName:(NSString*)fontName
               fontSize:(UInt32)fontSize
                content:(NSString*)content;

/**
 * \if English
 * \brief Print one-dimension barcode
 *
 * Print one-dimension barcode
 * \param [in]  x           Horizontal coordinate, unit: dot
 * \param [in]  y           Vertical coordinate, unit: dot
 * \param [in]  barcodeType Barcode type
 * \param [in]  angle       Rotation angle of printing
 * \param [in]  content     Barcode content
 * \param [in]  height      Height of barcode, unit: dot
 * \param [in]  HRIPostion  HRI character printing mode. For BPLZ/BPLE/BPLC, HRI_ALIGN_LEFT/HRI_ALIGN_RIGHT is same as HRI_ALIGN_CENTER
 * \param [in]  narrowbarWidth Width of narrow bar, unit: dot
 * \param [in]  wideBarwidth   Width of wide bar, unit: dot
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note
 * \elseif Chinese
 * \brief 打印一维条码
 *
 * 打印一维条码
 * \param [in]  x           横坐标，单位点
 * \param [in]  y           纵坐标，单位点
 * \param [in]  barcodeType 条码类型
 * \param [in]  angle       打印旋转角度
 * \param [in]  content     条码内容
 * \param [in]  height      条码高度，单位点
 * \param [in]  HRIPostion  HRI字符打印模式。对于BPLZ/BPLE/BPLC指令集， HRI_ALIGN_LEFT/HRI_ALIGN_RIGHT按HRI_ALIGN_CENTER处理
 * \param [in]  narrowbarWidth 窄条宽度，单位点
 * \param [in]  wideBarwidth   宽条宽度，单位点
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note
 * \endif
 */
- (void)printBarcode1D:(UInt32)x
                     y:(UInt32)y
           barcodeType:(BarcodeType)barcodeType
                 angle:(Rotation)angle
               content:(NSData*)content
                height:(UInt32)height
            HRIPostion:(HRIAlign)HRIPostion
        narrowbarWidth:(UInt32)narrowbarWidth
          wideBarwidth:(UInt32)wideBarwidth;


/**
 * \if English
 * \brief Print PDF417 code
 *
 * Print PDF417 code
 * \param [in]  x           Horizontal coordinate, unit: dot
 * \param [in]  y           Vertical coordinate, unit: dot
 * \param [in]  angle       Rotation angle of printing
 * \param [in]  content     Barcode content
 * \param [in]  securityLevel   Security level, range: 1-7
 * \param [in]  moduleWidth     Width of module, unit: dot
 * \param [in]  moduleHeight    Height of module, unit: dot
 * \param [in]  rows            Rows
 * \param [in]  columns         Columns
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note
 * \elseif Chinese
 * \brief 打印PDF417码
 *
 * 打印PDF417码
 * \param [in]  x           横坐标，单位点
 * \param [in]  y           纵坐标，单位点
 * \param [in]  angle       打印旋转角度
 * \param [in]  content     条码内容
 * \param [in]  securityLevel   安全级别，范围为1-7
 * \param [in]  moduleWidth     模块宽度，单位点
 * \param [in]  moduleHeight    模块高度，单位点
 * \param [in]  rows            行数
 * \param [in]  columns         列数
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note
 * \endif
 */
- (void)printBarcodePDF417:(UInt32)x
                         y:(UInt32)y
                     angle:(UInt32)angle
                   content:(NSData*)content
             securityLevel:(UInt32)securityLevel
               moduleWidth:(UInt32)moduleWidth
              moduleHeight:(UInt32)moduleHeight
                      rows:(UInt32)rows
                   columns:(UInt32)columns;

/**
 * \if English
 * \brief Print QR code
 *
 * Print QR code
 * \param [in]  x           Horizontal coordinate, unit: dot
 * \param [in]  y           Vertical coordinate, unit: dot
 * \param [in]  angle       Rotation angle of printing
 * \param [in]  content     Barcode content
 * \param [in]  ECCLever    Security level
 * \param [in]  cellWidth   Cell width
 * \param [in]  model       Barcode mode
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note
 * \elseif Chinese
 * \brief 打印QR码
 *
 * 打印QR码
 * \param [in]  x           横坐标，单位点
 * \param [in]  y           纵坐标，单位点
 * \param [in]  angle       打印旋转角度
 * \param [in]  content     条码内容
 * \param [in]  ECCLever    安全级别
 * \param [in]  cellWidth   模块宽度
 * \param [in]  model       条码模式
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \endif
 */
- (void)printBarcodeQR:(UInt32)x
                     y:(UInt32)y
                 angle:(Rotation)angle
               content:(NSData*)content
              ECCLever:(QRLevel)ECCLever
             cellWidth:(UInt32)cellWidth
                 model:(QRMode)model;


/**
 * \if English
 * \brief Print DM code
 *
 * Print DM code
 * \param [in]  x           Horizontal coordinate, unit: dot
 * \param [in]  y           Vertical coordinate, unit: dot
 * \param [in]  angle       Rotation angle of printing
 * \param [in]  content     Barcode content
 * \param [in]  rows        Rows
 * \param [in]  columns     Columns
 * \param [in]  moduleSize  Module size
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note BPLZ/BPLE/BPLT command sets support the function. The following table show the acceptable rows and columns:
 * \elseif Chinese
 * \brief 打印DM码
 *
 * 打印DM码
 * \param [in]  x           横坐标，单位点
 * \param [in]  y           纵坐标，单位点
 * \param [in]  angle       打印旋转角度
 * \param [in]  content     条码内容
 * \param [in]  rows        行数
 * \param [in]  columns     列数
 * \param [in]  moduleSize  模块大小
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note BPLZ/BPLE/BPLT指令集支持此功能。 合法的行数及列数组合见下表：
 * \endif
 * {8,18},     {8, 32},    {10,10},    {12,12},    {12,26},    {12,36},    {14,14},    {16,16},
 * {16,36},    {16,48},    {18,18},    {20,20},    {22,22},    {24,24},    {26,26},    {32,32},
 * {36,36},    {40,40},    {44,44},    {48,48},    {52,52},    {64,64},    {72,72},    {80,80},
 * {88,88},    {96,96},    {104,104},  {120,120},  {132,132},  {144,144},  {0,0}
 */
- (void)printBarcodeDataMatrix:(UInt32)x
                             y:(UInt32)y
                         angle:(Rotation)angle
                       content:(NSData*)content
                          rows:(UInt32)rows
                       columns:(UInt32)columns
                    moduleSize:(UInt32)moduleSize;

/**
 * \if English
 * \brief Print maxicode code
 *
 * Print maxicode code
 * \param [in]  x           Horizontal coordinate, unit: dot
 * \param [in]  y           Vertical coordinate, unit: dot
 * \param [in]  content     Barcode content
 * \param [in]  mode        Barcode mode, valid value contains 2,3,4,5(only for BPLZ),6
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note BPLZ/BPLE command sets support the function.
 * \elseif Chinese
 * \brief 打印maxicode码
 *
 * 打印maxicode码
 * \param [in]  x           横坐标，单位点
 * \param [in]  y           纵坐标，单位点
 * \param [in]  content     条码内容
 * \param [in]  mode        条码模式, 合法值2,3,4,5(仅适用于BPLZ),6
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note BPLZ/BPLE指令集支持此功能。
 * \endif
 */
- (void)printBarcodeMaxiCode:(UInt32)x
                           y:(UInt32)y
                     content:(NSData*)content
                        mode:(UInt32)mode;

/**
 * \if English
 * \brief Print the image stored in printer
 *
 * Print the image stored in printer
 * \param [in]  x           Horizontal coordinate, unit: dot
 * \param [in]  y           Vertical coordinate, unit: dot
 * \param [in]  imageName   Image name stored in printer, the name is queried by getImageFileName
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note
 * \elseif Chinese
 * \brief 打印打印机中存储的图像
 *
 * 打印打印机中存储的图像
 * \param [in]  x           横坐标，单位点
 * \param [in]  y           纵坐标，单位点
 * \param [in]  imageName   打印机中存储的图像名称；该名称可以通过getImageFileName获取
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note
 * \endif
 */
- (void)printStoredImage:(UInt32)x
                       y:(UInt32)y
               imageName:(NSString*)imageName;

/**
 * \if English
 * \brief Print the image in the iOS system
 *
 * Print the image in the iOS system
 * \param [in]  x           Horizontal coordinate, unit: dot
 * \param [in]  y           Vertical coordinate, unit: dot
 * \param [in]  imagePath   Name of image file that includes route
 * \param [in]  method      Image managing method
 * \param [in]  customThreshold Self-defined threshold, use when the method is IMAGE_BINARIZE_CUSTOM_THRESHOLD.
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note
 * \elseif Chinese
 * \brief 打印iOS系统中的图像
 *
 * 打印iOS系统中的图像
 * \param [in]  x           横坐标，单位点
 * \param [in]  y           纵坐标，单位点
 * \param [in]  imagePath   包含路径的图像文件名称
 * \param [in]  method      图像处理模式
 * \param [in]  customThreshold 自定义阈值，当method为IMAGE_BINARIZE_CUSTOM_THRESHOLD时使用
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note
 * \endif
 */
- (void)printImage:(UInt32)x
                 y:(UInt32)y
         imagePath:(NSString*)imagePath
            method:(ImageBinarizeMethord)method
   customThreshold:(UInt8)customThreshold;

/**
 * \if English
 * \brief Print the image in the iOS system
 *
 * Print the image in the iOS system
 * \param [in]  x           Horizontal coordinate, unit: dot
 * \param [in]  y           Vertical coordinate, unit: dot
 * \param [in]  image       UIImage type image
 * \param [in]  method      Image managing method
 * \param [in]  customThreshold Self-defined threshold, use when the method is IMAGE_BINARIZE_CUSTOM_THRESHOLD.
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note
 * \elseif Chinese
 * \brief 打印iOS系统中的图像
 *
 * 打印iOS系统中的图像
 * \param [in]  x           横坐标，单位点
 * \param [in]  y           纵坐标，单位点
 * \param [in]  image       UIImage类型的图像
 * \param [in]  method      图像处理模式
 * \param [in]  customThreshold 自定义阈值，当method为IMAGE_BINARIZE_CUSTOM_THRESHOLD时使用
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note
 * \endif
 */
- (void)printImage:(UInt32)x
                 y:(UInt32)y
             image:(UIImage*)image
            method:(ImageBinarizeMethord)method
   customThreshold:(UInt8)customThreshold;

/**
 * \if English
 * \brief Print rectangle
 *
 * Print rectangle
 * \param [in]  x           Horizontal coordinate, unit: dot
 * \param [in]  y           Vertical coordinate, unit: dot
 * \param [in]  width       Width of rectangle, unit: dot
 * \param [in]  height      Height of rectangle, unit: dot
 * \param [in]  thickness   Line thickness, unit: dot
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note
 * \elseif Chinese
 * \brief 打印矩形
 *
 * 打印矩形
 * \param [in]  x           横坐标，单位点
 * \param [in]  y           纵坐标，单位点
 * \param [in]  width       矩形宽度，单位点
 * \param [in]  height      矩形高度，单位点
 * \param [in]  thickness   线条宽度，单位点
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note
 * \endif
 */
- (void)printRectangle:(UInt32)x
                     y:(UInt32)y
                 width:(UInt32)width
                height:(UInt32)height
             thickness:(UInt32)thickness;

/**
 * \if English
 * \brief Print oval
 *
 * Print oval
 * \param [in]  x           Horizontal coordinate, unit: dot
 * \param [in]  y           Vertical coordinate, unit: dot
 * \param [in]  radiusHorizontal    Length of horizontal axle, unit: dot
 * \param [in]  radiusVertical      Length of vertical axle, unit: dot
 * \param [in]  thickness   Line thickness, unit: dot
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note BPLZ/BPLT support the function.
 * \elseif Chinese
 * \brief 打印椭圆
 *
 * 打印椭圆
 * \param [in]  x           横坐标，单位点
 * \param [in]  y           纵坐标，单位点
 * \param [in]  radiusHorizontal    横轴长度，单位点
 * \param [in]  radiusVertical      纵轴长度，单位点
 * \param [in]  thickness   线条宽度，单位点
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note BPLZ/BPLT支持此功能
 * \endif
 */
- (void)printEllipse:(UInt32)x
                   y:(UInt32)y
    radiusHorizontal:(UInt32)radiusHorizontal
      radiusVertical:(UInt32)radiusVertical
           thickness:(UInt32)thickness;

/**
 * \if English
 * \brief Print lines
 *
 * Print lines
 * \param [in]  startX      Horizontal coordinate of start line, unit: dot
 * \param [in]  startY      Vertical coordinate of start line, unit: dot
 * \param [in]  endX        Horizontal coordinate of end line, unit: dot
 * \param [in]  endY        Vertical coordinate of end line, unit: dot
 * \param [in]  thickness   Line thickness, unit: dot
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note
 * \elseif Chinese
 * \brief 打印直线
 *
 * 打印直线
 * \param [in]  startX      起点横坐标，单位点
 * \param [in]  startY      起点纵坐标，单位点
 * \param [in]  endX        终点横坐标，单位点
 * \param [in]  endY        终点纵坐标，单位点
 * \param [in]  thickness   线条宽度，单位点
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note
 * \endif
 */
- (void)printLine:(UInt32)startX
           startY:(UInt32)startY
             endX:(UInt32)endX
             endY:(UInt32)endY
        thickness:(UInt32)thickness;


/**
 * \if English
 * \brief Print triangle
 *
 * Print triangle
 * \param [in]  x1          Horizontal coordinate of vertex 1, unit: dot
 * \param [in]  y1          vertical coordinate of vertex 1, unit: dot
 * \param [in]  x2          Horizontal coordinate of vertex 2, unit: dot
 * \param [in]  y2          vertical coordinate of vertex 2, unit: dot
 * \param [in]  x3          Horizontal coordinate of vertex 3, unit: dot
 * \param [in]  y3          vertical coordinate of vertex 3, unit: dot
 * \param [in]  thickness   Line thickness, unit: dot
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note
 * \elseif Chinese
 * \brief 打印三角形
 *
 * 打印三角形
 * \param [in]  x1          顶点1横坐标，单位点
 * \param [in]  y1          顶点1纵坐标，单位点
 * \param [in]  x2          顶点2横坐标，单位点
 * \param [in]  y2          顶点2纵坐标，单位点
 * \param [in]  x3          顶点3横坐标，单位点
 * \param [in]  y3          顶点3纵坐标，单位点
 * \param [in]  thickness   线条宽度，单位点
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note
 * \endif
 */
- (void)printTriangle:(UInt32)x1
                   y1:(UInt32)y1
                   x2:(UInt32)x2
                   y2:(UInt32)y2
                   x3:(UInt32)x3
                   y3:(UInt32)y3
            thickness:(UInt32)thickness;


/**
 * \if English
 * \brief Set the print column and horizontal spacing
 *
 * Set the print column and horizontal spacing
 * \param [in]  column      Print column
 * \param [in]  space       Label spacing, unit: dot
 * \return void
 * \exception When the parameter is illegal, cause ExceptionSDK type exception.
 * \note Call this method before setLabelSize.
 * \elseif Chinese
 * \brief 设置打印列数及横向间距
 *
 * 设置打印列数及横向间距
 * \param [in]  column      打印列数
 * \param [in]  space       标签间距，单位：点
 * \return void
 * \exception 参数非法时会抛出 ExceptionSDK 类型异常
 * \note 此方法需在setLabelSize前调用
 * \endif
 */
- (void)setColumn:(UInt32)column space:(SInt32)space;

/**
 * \if English
 * \brief Set the measuring unit
 *
 * Set the measuring unit
 * \param [in]  measuringUnit     Measuring unit
 * \return void
 * \exception ExceptionSDK
 * \note Reserved method, unrealized function.
 * \elseif Chinese
 * \brief 设置计量单位
 *
 * 设置计量单位
 * \param [in]  measuringUnit      计量单位
 * \return void
 * \exception ExceptionSDK
 * \note 预留方法，功能暂未实现
 * \endif
 */
- (void)setMeasuringUnit:(MeasuringUnit)measuringUnit;

/**
 * \if English
 * \brief Clear the print buffer
 *
 * Clear the print buffer
 * \return void
 * \exception ExceptionSDK
 * \note BPLE/BPLT support the function
 * \elseif Chinese
 * \brief 清空打印缓冲区
 *
 * 清空打印缓冲区
 * \return void
 * \exception ExceptionSDK
 * \note BPLE/BPLT支持此功能
 * \endif
 */
- (void)clearPrintBuffer;

/**
 * \if English
 * \brief Select the codepage
 *
 * Select codepage
 * \param [in] codepage The number of the codepage
 * \return void
 * \exception ExceptionSDK
 * \note BPLZ/BPLE/BPLT support the function
 * \elseif Chinese
 * \brief 设置打印机的代码页
 *
 * 设置打印机的代码页
 * \param [in] codepage 代码页编号
 * \return void
 * \exception ExceptionSDK
 * \note BPLZ/BPLE/BPLT支持此功能
 * \endif
 */
- (void)selectPrinterCodepage:(NSInteger)codepage;

/**
 * \if English
 * \brief Set english font name when print ASII and chinese characters
 *
 * In BPLA Mode, set english font name to print
 * \param [in] fontName English font name, valid value:"0"~"8" "000"~"007" "P06" "P08" "P10" "P12" "P14" "P18"
 * \param [in] verticalOffset The vertical distance between ASII and chinese character, valid value:-999~999(dot)
 * \return void
 * \exception ExceptionSDK
 * \note Only BPLA support this function
 * \elseif Chinese
 * \brief 设置中英文混排打印时使用的英文字体名称
 *
 * 在BPLA指令集下，设置中英文混排打印时使用的英文字体名称
 * \param [in] fontName 英文字体名称，有效值包括"0"~"8" "000"~"007" "P06" "P08" "P10" "P12" "P14" "P18"
 * \param [in] verticalOffset 英文字符和中文字符纵向距离，有效范围为－999至999，单位点
 * \return void
 * \exception ExceptionSDK
 * \note 只有BPLA指令集支持此功能
 * \endif
 */
- (void)setEnglishFontName:(NSString*)fontName
            verticalOffset:(NSInteger)verticalOffset;
@end

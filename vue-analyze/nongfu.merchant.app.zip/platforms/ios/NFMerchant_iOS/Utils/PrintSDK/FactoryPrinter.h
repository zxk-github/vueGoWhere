/**
 * \file FactoryPrinter.h
 * \copyright
 * \if English
 * This document is owned by Shandong New Beiyang Information Technology Co., Ltd. Without the express written permission of SNBC,
 * no part of this document may be reproduced or transmitted in any form or by any means.\n
 * Shandong New Beiyang Information Technology Co., Ltd. 2015
 * \elseif Chinese
 * 本文档为山东新北洋信息技术股份有限公司所有。未经山东新北洋信息技术股份有效公司书面授权，
 * 任何人不得以任何形式进行再次分发或复制。\n
 * 山东新北洋信息技术股份有限公司。2015
 * \endif
 */

#import <Foundation/Foundation.h>
#import "Printer.h"

/**
 * \if English
 *  \brief Printer building factory
 *
 * Build and manage printer
 * \elseif Chinese
 *  \brief 打印机构建工厂
 *
 * 构建并管理打印机对象
 * \endif
 */
@interface FactoryPrinter : NSObject

/**
 * \if English
 * \brief Build printer
 *
 * Build printer according to connection and printer language.
 * \param [in]  connection      Communication connection instance
 * \param [in]  printerLanguage Printer language
 * \return Printer type instance
 * \exception When connection or printerLanguage is invalid, cause ExceptionSDK type abnormality.
 * \note The instance built through this method does not need to destroy, and the FactoryPrinter will destroy automatically.
 * \elseif Chinese
 * \brief 构建打印机
 *
 * 根据连接connection及打印机语言printerLanguage构建打印机
 * \param [in]  connection      通讯连接对象
 * \param [in]  printerLanguage 打印机语言
 * \return Printer 类型的对象
 * \exception connection无效或printerLanguage无效时会抛出 ExceptionSDK 类型异常
 * \note 该方法创建的对象无需销毁， FactoryPrinter 会进行自动销毁
 * \endif
 */
- (Printer*)createPrinter:(Connection*)connection
          printerLanguage:(PrinterLanguage)printerLanguage;
@end

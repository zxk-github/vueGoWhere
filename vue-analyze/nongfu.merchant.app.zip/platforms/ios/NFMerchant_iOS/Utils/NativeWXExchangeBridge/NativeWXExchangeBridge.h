//
//  NativeWXExchangeBridge.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/20.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WeexSDK/WeexSDK.h>



@interface NativeWXExchangeBridge : NSObject
+(instancetype)shardBridge;


+(NSDictionary *)configWXPragmas:(NSString *)status result:(NSDictionary *)res;
-(void)fireWXEvent:(NSString *)eventName instanceKey:(NSString *)key pragmas:(NSDictionary *)pragmas;
-(void)saveWXInstance:(WXSDKInstance *)instance forKey:(NSString *)key;
-(void)deleteWXInstance:(WXSDKInstance *)instance forKey:(NSString *)key;
-(NSString *)getPageNameByWXInstance:(WXSDKInstance *)instance;
-(void)setInstancePage:(NSString *)pageName forWXInstance:(WXSDKInstance*)instance;
@end

//
//  NativeWXExchangeBridge.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/4/20.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "NativeWXExchangeBridge.h"

@interface NativeWXExchangeBridge()
@property (nonatomic, strong) NSMutableDictionary<NSString *, WXSDKInstance *> *instances;
@property (nonatomic, strong) NSMutableDictionary<NSString *, NSString *> *instancesPages;
@end

static NativeWXExchangeBridge *bridge = nil;
@implementation NativeWXExchangeBridge
-(void)fireWXEvent:(NSString *)eventName instanceKey:(NSString *)key pragmas:(NSDictionary *)pragmas{
    WXSDKInstance *wxInstance = [bridge.instances objectForKey:key];
    if (wxInstance) {
        [wxInstance fireGlobalEvent:eventName params:pragmas];
    }
}
+(NSDictionary *)configWXPragmas:(NSString *)status result:(NSDictionary *)res {
    return @{@"status" : status, @"result":@{@"res": res}};
}
+(instancetype)shardBridge{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        bridge = [[NativeWXExchangeBridge alloc] init];
        bridge.instances = [NSMutableDictionary dictionary];
        //        manger.babyBluetooth.scanForPeripherals().begin().stop(3);
        bridge.instancesPages = [NSMutableDictionary dictionary];
        
    });
    return bridge;
}
-(void)saveWXInstance:(WXSDKInstance *)instance forKey:(NSString *)key{
    [bridge.instances setObject:instance forKey:key];
    
}
-(void)deleteWXInstance:(WXSDKInstance *)instance forKey:(NSString *)key{
    
    [bridge.instances removeObjectForKey:key];
}

-(void)setInstancePage:(NSString *)pageName forWXInstance:(WXSDKInstance*)instance{
    [bridge.instancesPages setObject:pageName forKey:instance.instanceId];
}
-(NSString *)getPageNameByWXInstance:(WXSDKInstance *)instance{
    return [bridge.instancesPages objectForKey:instance.instanceId];
}

@end

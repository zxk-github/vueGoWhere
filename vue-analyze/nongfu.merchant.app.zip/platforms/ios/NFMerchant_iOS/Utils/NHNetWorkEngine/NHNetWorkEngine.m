//
//  NHNetWorkEngine.m
//  NongheMobileApp
//
//  Created by 胡鹏飞 on 2017/7/12.
//  Copyright © 2017年 WMJ. All rights reserved.
//

#import "NHNetWorkEngine.h"
#import "GlobalUtil.h"
#import "AppUtil.h"

@interface NHNetWorkEngine ()
@property (nonatomic, strong) NSURLSession *uploadImageSession;
@end
static NHNetWorkEngine *engine;
@implementation NHNetWorkEngine


+(NHNetWorkEngine *)sharedEngine{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        engine = [NHNetWorkEngine manager];
        [self configCommon: engine];
    });
    return engine;
}


- (NSURLSessionDataTask *)dataTaskWithHTTPMethod:(NSString *)method
                                       URLString:(NSString *)URLString
                                      parameters:(id)parameters
                                  uploadProgress:(nullable void (^)(NSProgress *uploadProgress)) uploadProgress
                                downloadProgress:(nullable void (^)(NSProgress *downloadProgress)) downloadProgress
                                         success:(void (^)(NSURLSessionDataTask *, id))success
                                         failure:(void (^)(NSURLSessionDataTask *, id  _Nullable responseObject, NSError *))failure
{
    NSError *serializationError = nil;
    NSMutableURLRequest *request = [self.requestSerializer requestWithMethod:method URLString:[[NSURL URLWithString:URLString relativeToURL:self.baseURL] absoluteString] parameters:parameters error:&serializationError];
    if (serializationError) {
        if (failure) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wgnu"
            dispatch_async(self.completionQueue ?: dispatch_get_main_queue(), ^{
                failure(nil, nil, serializationError);
            });
#pragma clang diagnostic pop
        }
        
        return nil;
    }
    NSLog(@"\n ==========request:%@ \n ============header: %@",request.URL.absoluteString, request.allHTTPHeaderFields);
    __block NSURLSessionDataTask *dataTask = nil;
    dataTask = [self dataTaskWithRequest:request
                          uploadProgress:uploadProgress
                        downloadProgress:downloadProgress
                       completionHandler:^(NSURLResponse * __unused response, id responseObject, NSError *error) {
                           if (error) {
                               if (failure) {
                                   failure(dataTask,responseObject,error);
                               }
                           } else {
                               if (success) {
                                   success(dataTask, responseObject);
                               }
                           }
                       }];
    
    return dataTask;
}

+ (void)configCommon:(NHNetWorkEngine *)engine{
    engine.responseSerializer = [AFHTTPResponseSerializer serializer];
    //    [engine.requestSerializer setValue:@"nongheios" forHTTPHeaderField:@"User-Agent"];
    engine.securityPolicy.allowInvalidCertificates = YES;
    engine.requestSerializer = [AFJSONRequestSerializer serializer];
    [engine.requestSerializer setValue:@"application/json;charset=utf-8" forHTTPHeaderField:@"Content-Type"];
}




+ (nullable NSURLSessionDataTask *)POSTRequestWithPath:(NSString *)requestPathString
                                         andParameters:(nullable id )parameters
                                               success:(nullable void (^)(NSURLSessionDataTask *task, id _Nullable responseObject))resultBlock
                                                  fail:(nullable void (^)(NSURLSessionDataTask * _Nullable task,id  _Nullable responseObject, NSError *error))failBlock{
    NSMutableString *reqStr = [NSMutableString string];
    if ([parameters isKindOfClass:[NSDictionary class]]) {
        [parameters enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
            [reqStr appendString:[NSString stringWithFormat:@"%@=%@&",key,obj]];
        }];
    }
    NSLog(@"\n===========request===========\n%@%@ ? \n%@", requestPathString,reqStr,parameters);
    
    NHNetWorkEngine *manager = [NHNetWorkEngine sharedEngine];
    
    NSURLSessionDataTask *dataTask = [manager dataTaskWithHTTPMethod:@"POST" URLString:requestPathString parameters:parameters uploadProgress:nil downloadProgress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSString *string = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
        NSLog(@"\n===========request===========\n%@%@ : \n=====Json====\n%@", requestPathString,reqStr,string);
        NSError * error = nil;
        id jsonObj = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:&error];
        if (!error) {
            responseObject = jsonObj;
        }
        
        
        resultBlock(task,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, id  _Nullable responseObject,NSError * _Nonnull error) {
        if (failBlock) {
            if (responseObject) {
                NSError * error = nil;
                id jsonObj = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:&error];
                if (!error) {
                    responseObject = jsonObj;
                }
            }
            
            failBlock(task,responseObject, error);
        }
        
    }];
    [dataTask resume];
    return  dataTask;
}
+ (nullable NSURLSessionDataTask *)GETRequestWithPath:(NSString *_Nullable)requestPathString
                                        andParameters:(nullable NSDictionary *)parameters
                                              success:(nullable void (^)(NSURLSessionDataTask * _Nullable task, id _Nullable responseObject))resultBlock
                                                 fail:(nullable void (^)(NSURLSessionDataTask * _Nullable task,id  _Nullable responseObject, NSError * _Nullable error ))failBlock{
    NSMutableString *reqStr = [NSMutableString string];
    if ([parameters isKindOfClass:[NSDictionary class]]) {
        [parameters enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
            [reqStr appendString:[NSString stringWithFormat:@"%@=%@&",key,obj]];
        }];
    }
    NSLog(@"\n===========begin request===========\n%@  参数%@  ", requestPathString,reqStr);
    NHNetWorkEngine *manager = [NHNetWorkEngine sharedEngine];
    
    NSURLSessionDataTask *dataTask = [manager dataTaskWithHTTPMethod:@"GET" URLString:requestPathString parameters:parameters uploadProgress:nil downloadProgress:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        
        NSString *string = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
        NSLog(@"\n===========end request===========\n%@ 参数%@ : \n=====Json====\n%@", requestPathString,reqStr,string);
        NSError * error = nil;
        id jsonObj = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:&error];
        if (!error) {
            responseObject = jsonObj;
        }
        
        
        resultBlock(task,responseObject);
    } failure:^(NSURLSessionDataTask *task,id  _Nullable responseObject, NSError *error) {
        if (failBlock) {
            if (responseObject) {
                NSError * error = nil;
                id jsonObj = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:&error];
                if (!error) {
                    responseObject = jsonObj;
                    NSLog(@"\n ======== requset failed: %@ \n =========response: %@", task.currentRequest.URL.absoluteString, responseObject);
                }
            }
            
            failBlock(task,responseObject,error);
        }
    }];
    [dataTask resume];
    return dataTask;
    
    
}








+ (nullable NSURLSessionDataTask *)postFormDataRequest:(NSString *_Nonnull)requestPathString configHeaderDic:(NSDictionary * _Nonnull)config parameters:(NSDictionary *_Nullable)parameters formData:(NSArray *_Nullable)formData success:(nonnull void (^)(NSURLSessionDataTask * _Nullable task, id _Nullable responseObject))success
                                               failure:(nullable void (^)(NSURLSessionDataTask * _Nullable task, NSError * _Nullable error))failure{
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:requestPathString]];
    request.HTTPMethod = @"POST";
    NSMutableData *bodyData = [NSMutableData data];
    // 分隔符
    NSString *boundary = [NSString stringWithFormat:@"Boundary+%08X%08X", arc4random(), arc4random()];
    //表单开始
    [formData enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        
        NSDictionary *file = obj[@"file"];
        NSMutableString *topStr = [NSMutableString string];
        [topStr appendString:[NSString stringWithFormat:@"--%@\r\n", boundary]];
        [topStr appendString: [NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"; filename=\"%@\"\r\n",file[@"input"], file[@"name"]] ];
        [topStr appendString:  [NSString stringWithFormat:@"Content-Type:%@\r\n",file[@"type"]]];
        [topStr appendString:@"Content-Transfer-Encoding: binary\r\n\r\n"];
        [bodyData appendData:[topStr dataUsingEncoding:NSUTF8StringEncoding]];
        [bodyData appendData:file[@"data"]];
        [bodyData appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        
        NSDictionary *action = [obj valueForKey:@"action"];
        if (action.count > 0) {
            NSString *key = action.allKeys.firstObject;
            NSMutableString *fieldStr = [NSMutableString string];
            [fieldStr appendString:[NSString stringWithFormat:@"--%@\r\n", boundary]];
            [fieldStr appendString:[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n", key]];
            [fieldStr appendString:[NSString stringWithFormat:@"%@", action[key]]];
            [bodyData appendData:[fieldStr dataUsingEncoding:NSUTF8StringEncoding]];
            [bodyData appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        }
    }];
    //api参数
    [parameters enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
        NSMutableString *fieldStr = [NSMutableString string];
        [fieldStr appendString:[NSString stringWithFormat:@"--%@\r\n", boundary]];
        [fieldStr appendString:[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n", key]];
        [fieldStr appendString:[NSString stringWithFormat:@"%@", obj]];
        [bodyData appendData:[fieldStr dataUsingEncoding:NSUTF8StringEncoding]];
        [bodyData appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    }];
    //结束符
    NSString *bottomStr = [NSString stringWithFormat:@"--%@--", boundary];
    [bodyData appendData:[bottomStr dataUsingEncoding:NSUTF8StringEncoding]];
    //头字段
    [request setValue:[NSString stringWithFormat:@"%ld", (unsigned long) bodyData.length] forHTTPHeaderField:@"Content-Length"];
    [request setValue:[NSString stringWithFormat:@"multipart/form-data; boundary=%@", boundary] forHTTPHeaderField:@"Content-Type"];
    [request setValue:[NSString stringWithFormat:@"Basic eGRvbWFpbi1ub25naGVxdWFuLXVzZXI6S000eTVPNE05NU1aT2FWMzlZN0Z0cjk1c25vOG5USQ=="] forHTTPHeaderField:@"Authorization"];
    [config enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {//自定义的头字段
        [request setValue:obj forHTTPHeaderField:key];
    }];
    //请求体
    request.HTTPBody = bodyData;
    if (![NHNetWorkEngine sharedEngine].uploadImageSession) {
        [NHNetWorkEngine sharedEngine].uploadImageSession = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    }
    
    __block NSURLSessionDataTask *task = [engine.uploadImageSession dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (!error) {
                //            NSError * err = nil;
                NSString *string = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                NSLog(@"\n===========end request===========\n%@ : \n=====Json====\n%@\n\n=============", requestPathString,string);
                NSError *err = nil;
                id jsonObj = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
                if (!err) {
                    success(task, jsonObj);
                }
                
                
            }else{
                failure(task, error);
            }
        });
        
    }];
    [task resume];
    
    return task;
}


@end

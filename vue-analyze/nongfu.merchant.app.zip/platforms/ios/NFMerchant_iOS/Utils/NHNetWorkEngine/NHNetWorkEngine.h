//
//  NHNetWorkEngine.h
//  NongheMobileApp
//
//  Created by 胡鹏飞 on 2017/7/12.
//  Copyright © 2017年 WMJ. All rights reserved.
//

#import <AFNetworking/AFNetworking.h>
typedef NS_ENUM(NSInteger,EngineType){
    EngineTypeComon,
    EngineTypeNative
};
@protocol AFMultipartFormData;
@interface NHNetWorkEngine : AFHTTPSessionManager
+ (nullable NSURLSessionDataTask *)POSTRequestWithPath:(NSString *_Nullable)requestPathString
                                         andParameters:(nullable id )parameters
                                               success:(nullable void (^)(NSURLSessionDataTask * _Nullable task, id _Nullable responseObject))resultBlock
                                                  fail:(nullable void (^)(NSURLSessionDataTask * _Nullable task,id  _Nullable responseObject, NSError * _Nullable error))failBlock;
+ (nullable NSURLSessionDataTask *)GETRequestWithPath:(NSString *_Nullable)requestPathString
                                        andParameters:(nullable id )parameters
                                              success:(nullable void (^)(NSURLSessionDataTask * _Nullable task, id _Nullable responseObject))resultBlock
                                                 fail:(nullable void (^)(NSURLSessionDataTask * _Nullable task, id  _Nullable responseObject, NSError * _Nullable error))failBlock;




//config: 配置http的头字段,除了表单上传的必要字段外,项目中需要定义的其他字段
//parameters: 请求参数
//formData: 表单数据(如图片,文件)的信息 格式如:[{"file":{"input":"uploadfile","name":"001.png","data":"xxxxx",type:"image/png"}} ] 
+ (nullable NSURLSessionDataTask *)postFormDataRequest:(NSString *_Nonnull)requestPathString configHeaderDic:(NSDictionary * _Nonnull)config parameters:(NSDictionary *_Nullable)parameters formData:(NSArray *_Nullable)formData success:(nonnull void (^)(NSURLSessionDataTask * _Nullable task, id _Nullable responseObject))success
                                               failure:(nullable void (^)(NSURLSessionDataTask * _Nullable task, NSError * _Nullable error))failure;
@end

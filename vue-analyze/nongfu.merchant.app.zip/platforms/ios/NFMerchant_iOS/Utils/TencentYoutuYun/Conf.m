//
//  Conf.m
//  YoutuYunDemo
//
//  Created by Patrick Yang on 15/9/15.
//  Copyright (c) 2015年 Tencent. All rights reserved.
//

#import "Conf.h"

#define API_END_POINT @"http://api.youtu.qq.com/youtu"
#define API_VIP_END_POINT @"https://vip-api.youtu.qq.com/youtu"

@implementation Conf

+ (Conf *)instance
{
    static Conf *singleton = nil;
    if (singleton) {
        return singleton;
    }
    
    singleton = [[Conf alloc] init];
    return singleton;
}
-(void)setValue:(id)value forKey:(NSString *)key{
    
}
-(instancetype)init{
    self = [super init];
    _appId = @"10092130";      // 替换APP_ID
    _secretId = @"AKIDd9UdZL1RgjeOvHRlwyrX3MSO8g1AGuiT";    // 替换SECRET_ID
    _secretKey = @"mNo8GEE4iATimiS0NXVItOkvtgGu6D8r";   // 替换SECRET_KEY
    _API_END_POINT = API_END_POINT;
    _API_VIP_END_POINT = API_VIP_END_POINT;
    return self;
}

@end

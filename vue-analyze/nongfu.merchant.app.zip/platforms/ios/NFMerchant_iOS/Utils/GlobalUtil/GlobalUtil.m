//
//  GlobalUtil.m
//  NongheMobileApp
//
//  Created by 胡鹏飞 on 2017/7/14.
//
//

#import "GlobalUtil.h"
#import <OpenUDID/OpenUDID.h>
#import <UICKeyChainStore/UICKeyChainStore.h>
#import "sys/utsname.h"
#import <MBProgressHUD/MBProgressHUD.h>
//#import <UMSocialCore/UMSocialCore.h>
//#import "ZYShareView.h"
#import <JavaScriptCore/JavaScriptCore.h>
//#import "NongheDataManager.h"
@implementation GlobalUtil

+ (NSString *) platformString{
    // 需要#import "sys/utsname.h"
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString *deviceString = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
    
    if ([deviceString isEqualToString:@"iPhone3,1"])    return @"iPhone 4";
    if ([deviceString isEqualToString:@"iPhone3,2"])    return @"iPhone 4";
    if ([deviceString isEqualToString:@"iPhone3,3"])    return @"iPhone 4";
    if ([deviceString isEqualToString:@"iPhone4,1"])    return @"iPhone 4S";
    if ([deviceString isEqualToString:@"iPhone5,1"])    return @"iPhone 5";
    if ([deviceString isEqualToString:@"iPhone5,2"])    return @"iPhone 5 (GSM+CDMA)";
    if ([deviceString isEqualToString:@"iPhone5,3"])    return @"iPhone 5c (GSM)";
    if ([deviceString isEqualToString:@"iPhone5,4"])    return @"iPhone 5c (GSM+CDMA)";
    if ([deviceString isEqualToString:@"iPhone6,1"])    return @"iPhone 5s (GSM)";
    if ([deviceString isEqualToString:@"iPhone6,2"])    return @"iPhone 5s (GSM+CDMA)";
    if ([deviceString isEqualToString:@"iPhone7,1"])    return @"iPhone 6 Plus";
    if ([deviceString isEqualToString:@"iPhone7,2"])    return @"iPhone 6";
    if ([deviceString isEqualToString:@"iPhone8,1"])    return @"iPhone 6s";
    if ([deviceString isEqualToString:@"iPhone8,2"])    return @"iPhone 6s Plus";
    if ([deviceString isEqualToString:@"iPhone8,4"])    return @"iPhone SE";
    // 日行两款手机型号均为日本独占，可能使用索尼FeliCa支付方案而不是苹果支付
    if ([deviceString isEqualToString:@"iPhone9,1"])    return @"国行、日版、港行iPhone 7";
    if ([deviceString isEqualToString:@"iPhone9,2"])    return @"港行、国行iPhone 7 Plus";
    if ([deviceString isEqualToString:@"iPhone9,3"])    return @"美版、台版iPhone 7";
    if ([deviceString isEqualToString:@"iPhone9,4"])    return @"美版、台版iPhone 7 Plus";
    if ([deviceString isEqualToString:@"iPhone10,1"])   return @"国行(A1863)、日行(A1906)iPhone 8";
    if ([deviceString isEqualToString:@"iPhone10,4"])   return @"美版(Global/A1905)iPhone 8";
    if ([deviceString isEqualToString:@"iPhone10,2"])   return @"国行(A1864)、日行(A1898)iPhone 8 Plus";
    if ([deviceString isEqualToString:@"iPhone10,5"])   return @"美版(Global/A1897)iPhone 8 Plus";
    if ([deviceString isEqualToString:@"iPhone10,3"])   return @"国行(A1865)、日行(A1902)iPhone X";
    if ([deviceString isEqualToString:@"iPhone10,6"])   return @"美版(Global/A1901)iPhone X";
    
    if ([deviceString isEqualToString:@"iPod1,1"])      return @"iPod Touch 1G";
    if ([deviceString isEqualToString:@"iPod2,1"])      return @"iPod Touch 2G";
    if ([deviceString isEqualToString:@"iPod3,1"])      return @"iPod Touch 3G";
    if ([deviceString isEqualToString:@"iPod4,1"])      return @"iPod Touch 4G";
    if ([deviceString isEqualToString:@"iPod5,1"])      return @"iPod Touch (5 Gen)";
    
    if ([deviceString isEqualToString:@"iPad1,1"])      return @"iPad";
    if ([deviceString isEqualToString:@"iPad1,2"])      return @"iPad 3G";
    if ([deviceString isEqualToString:@"iPad2,1"])      return @"iPad 2 (WiFi)";
    if ([deviceString isEqualToString:@"iPad2,2"])      return @"iPad 2";
    if ([deviceString isEqualToString:@"iPad2,3"])      return @"iPad 2 (CDMA)";
    if ([deviceString isEqualToString:@"iPad2,4"])      return @"iPad 2";
    if ([deviceString isEqualToString:@"iPad2,5"])      return @"iPad Mini (WiFi)";
    if ([deviceString isEqualToString:@"iPad2,6"])      return @"iPad Mini";
    if ([deviceString isEqualToString:@"iPad2,7"])      return @"iPad Mini (GSM+CDMA)";
    if ([deviceString isEqualToString:@"iPad3,1"])      return @"iPad 3 (WiFi)";
    if ([deviceString isEqualToString:@"iPad3,2"])      return @"iPad 3 (GSM+CDMA)";
    if ([deviceString isEqualToString:@"iPad3,3"])      return @"iPad 3";
    if ([deviceString isEqualToString:@"iPad3,4"])      return @"iPad 4 (WiFi)";
    if ([deviceString isEqualToString:@"iPad3,5"])      return @"iPad 4";
    if ([deviceString isEqualToString:@"iPad3,6"])      return @"iPad 4 (GSM+CDMA)";
    if ([deviceString isEqualToString:@"iPad4,1"])      return @"iPad Air (WiFi)";
    if ([deviceString isEqualToString:@"iPad4,2"])      return @"iPad Air (Cellular)";
    if ([deviceString isEqualToString:@"iPad4,4"])      return @"iPad Mini 2 (WiFi)";
    if ([deviceString isEqualToString:@"iPad4,5"])      return @"iPad Mini 2 (Cellular)";
    if ([deviceString isEqualToString:@"iPad4,6"])      return @"iPad Mini 2";
    if ([deviceString isEqualToString:@"iPad4,7"])      return @"iPad Mini 3";
    if ([deviceString isEqualToString:@"iPad4,8"])      return @"iPad Mini 3";
    if ([deviceString isEqualToString:@"iPad4,9"])      return @"iPad Mini 3";
    if ([deviceString isEqualToString:@"iPad5,1"])      return @"iPad Mini 4 (WiFi)";
    if ([deviceString isEqualToString:@"iPad5,2"])      return @"iPad Mini 4 (LTE)";
    if ([deviceString isEqualToString:@"iPad5,3"])      return @"iPad Air 2";
    if ([deviceString isEqualToString:@"iPad5,4"])      return @"iPad Air 2";
    if ([deviceString isEqualToString:@"iPad6,3"])      return @"iPad Pro 9.7";
    if ([deviceString isEqualToString:@"iPad6,4"])      return @"iPad Pro 9.7";
    if ([deviceString isEqualToString:@"iPad6,7"])      return @"iPad Pro 12.9";
    if ([deviceString isEqualToString:@"iPad6,8"])      return @"iPad Pro 12.9";
    if ([deviceString isEqualToString:@"iPad6,11"])    return @"iPad 5 (WiFi)";
    if ([deviceString isEqualToString:@"iPad6,12"])    return @"iPad 5 (Cellular)";
    if ([deviceString isEqualToString:@"iPad7,1"])     return @"iPad Pro 12.9 inch 2nd gen (WiFi)";
    if ([deviceString isEqualToString:@"iPad7,2"])     return @"iPad Pro 12.9 inch 2nd gen (Cellular)";
    if ([deviceString isEqualToString:@"iPad7,3"])     return @"iPad Pro 10.5 inch (WiFi)";
    if ([deviceString isEqualToString:@"iPad7,4"])     return @"iPad Pro 10.5 inch (Cellular)";
    
    if ([deviceString isEqualToString:@"AppleTV2,1"])    return @"Apple TV 2";
    if ([deviceString isEqualToString:@"AppleTV3,1"])    return @"Apple TV 3";
    if ([deviceString isEqualToString:@"AppleTV3,2"])    return @"Apple TV 3";
    if ([deviceString isEqualToString:@"AppleTV5,3"])    return @"Apple TV 4";
    
    if ([deviceString isEqualToString:@"i386"])         return @"Simulator";
    if ([deviceString isEqualToString:@"x86_64"])       return @"Simulator";
    
    return deviceString;}
+ (NSString *)getAppVersion{
    return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
}
+ (NSString *)UDIDString{
    NSString *uuid = [UICKeyChainStore stringForKey:UDIDSTOREKEY];
    if (uuid.length == 0) {
        uuid = [OpenUDID value];
        [UICKeyChainStore setString:uuid forKey:UDIDSTOREKEY];
    }
    return uuid;
}
+ (NSString *_Nullable)appToken{
   return [[NSUserDefaults standardUserDefaults] objectForKey:@"APP_TOKEN"];
}//用于设置到请求的header(cookie)里
+ (void)saveToken:(NSString *_Nonnull)token{
    [[NSUserDefaults standardUserDefaults] setObject:token forKey:@"APP_TOKEN"];
    
    [[NSUserDefaults standardUserDefaults] synchronize];
}
+(void)makeAlertForMessage:(NSString *)message{
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"提示" message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
    [alertVC addAction:action];
    [[[UIApplication sharedApplication] keyWindow].rootViewController presentViewController:alertVC animated:YES completion:nil];
}

+(NSString *)backStr:(NSString *) str defaultValue:(NSString *)defaultValue{
    return  str ? str : defaultValue;
}
+ (MBProgressHUD *)showMessage:(NSString *)message toView:(UIView *)view {
    if (view == nil) view = [[UIApplication sharedApplication].windows lastObject];
    // 快速显示一个提示信息
    MBProgressHUD *hud = nil;
    if (![MBProgressHUD HUDForView:view]) {
        hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    }
    hud.label.text = message;
    // 隐藏时候从父控件中移除
    hud.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
    hud.bezelView.color = [UIColor blackColor];
    hud.contentColor = [UIColor whiteColor];
    hud.removeFromSuperViewOnHide = YES;
    hud.backgroundView.style = MBProgressHUDBackgroundStyleSolidColor;
    hud.backgroundView.color = RGBA(0, 0, 0, 0.5);
    
    return hud;
}

+(void)showHudForView:(UIView *)view message:(NSString *)message{
    dispatch_async(dispatch_get_main_queue(), ^{
        [self showMessage:message toView:view];
    });
    
}//显示指示器
+(void)hudDismissForView:(UIView *)view{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *hud = [MBProgressHUD HUDForView:view];
        [hud hideAnimated:YES];
    });
    
}//移除指示器

+(NSDictionary *_Nonnull)environmentInfo{
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"environment" ofType:@"json"];
    NSData *jsonData = [NSData dataWithContentsOfFile:filePath];
    NSError *error = nil;
    NSDictionary *source = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
    return source;
}
+(NSDictionary *_Nonnull)findAreaByProvinceName:(NSString *_Nullable)provinceName cityName:(NSString *_Nullable)cityName districtName:(NSString *_Nullable)districtName{
    if (!provinceName && !cityName && !districtName ) {
        return @{@"provinceId":@"", @"cityId":@"", @"districtId":@""};
    }
    __block NSString *provinceId = @"";
    __block NSString *cityId = @"";
    __block NSString *districtId = @"";
    
    NSData *cityJson = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"city" ofType:@"json"]];
    NSMutableArray *info = [NSJSONSerialization JSONObjectWithData:cityJson options:NSJSONReadingMutableContainers error:nil];
    [info enumerateObjectsUsingBlock:^(NSDictionary *_Nonnull obj1, NSUInteger idx1, BOOL * _Nonnull stop1) {
        if (!provinceName || provinceName.length == 0) {
            NSArray *level2 = obj1[@"children"];
            [level2 enumerateObjectsUsingBlock:^(id  _Nonnull obj2, NSUInteger idx2, BOOL * _Nonnull stop2) {
                if(!cityName || cityName.length == 0){
                    NSArray *level3 = obj2[@"children"];
                    [level3 enumerateObjectsUsingBlock:^(id  _Nonnull obj3, NSUInteger idx3, BOOL * _Nonnull stop3) {
                        if ([obj3[@"name"] isEqualToString: districtName]) {
                            provinceId = obj1[@"id"];
                            cityId = obj2[@"id"];
                            districtId = obj3[@"id"];
                            *stop3 = YES;
                            *stop2 = YES;
                            *stop1 = YES;
                        }
                    }];
                    
                } else {
                    if ([obj2[@"name"] isEqualToString: cityName]) {
                        provinceId = obj2[@"id"];
                        cityId = obj2[@"id"];
                        NSArray *level3 = obj2[@"children"];
                        [level3 enumerateObjectsUsingBlock:^(id  _Nonnull obj3, NSUInteger idx3, BOOL * _Nonnull stop3) {
                            if (!districtName || districtName.length == 0) {
                                *stop3 = YES;
                                *stop2 = YES;
                                *stop1 = YES;
                            } else {
                                if ([obj3[@"name"] isEqualToString: districtName]) {
                                    districtId = obj3[@"id"];
                                    *stop3 = YES;
                                    *stop2 = YES;
                                    *stop1 = YES;
                                }
                                
                            }
                        }];
                    }
                }
            }];
            
        } else {
            if ([obj1[@"name"] isEqualToString: provinceName]) {
                provinceId = obj1[@"id"];
                NSArray *level2 = obj1[@"children"];
                [level2 enumerateObjectsUsingBlock:^(id  _Nonnull obj2, NSUInteger idx2, BOOL * _Nonnull stop2) {
                    if(!cityName || cityName.length == 0){
                        NSArray *level3 = obj2[@"children"];
                        [level3 enumerateObjectsUsingBlock:^(id  _Nonnull obj3, NSUInteger idx3, BOOL * _Nonnull stop3) {
                            if (!districtName || districtName.length == 0) {
                                *stop3 = YES;
                                *stop2 = YES;
                                *stop1 = YES;
                            } else {
                                if ([obj3[@"name"] isEqualToString: districtName]) {
                                    cityId = obj2[@"id"];
                                    districtId = obj3[@"id"];
                                    *stop3 = YES;
                                    *stop2 = YES;
                                    *stop1 = YES;
                                }
                                
                            }
                        }];
                        
                    } else {
                        if ([obj2[@"name"] isEqualToString: cityName]) {
                            cityId = obj2[@"id"];
                            NSArray *level3 = obj2[@"children"];
                            [level3 enumerateObjectsUsingBlock:^(id  _Nonnull obj3, NSUInteger idx3, BOOL * _Nonnull stop3) {
                                if (!districtName || districtName.length == 0) {
                                    *stop3 = YES;
                                    *stop2 = YES;
                                    *stop1 = YES;
                                } else {
                                    if ([obj3[@"name"] isEqualToString: districtName]) {
                                        districtId = obj3[@"id"];
                                        *stop3 = YES;
                                        *stop2 = YES;
                                        *stop1 = YES;
                                    }
                                }
                            }];
                        }
                    }
                }];
            }
        }
        
    }];
    return @{@"provinceId":provinceId, @"cityId":cityId, @"districtId":districtId};
}

+(AppEnvironment)getAppEnvironment{
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"environment" ofType:@"json"];
    NSData *jsonData = [NSData dataWithContentsOfFile:filePath];
    NSError *error = nil;
    NSDictionary *source = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
    if (!error) {
        NSString *env = source[@"environment"];
        if ([env isEqualToString:@"test"]) {
            return Test;
        }
        if ([env isEqualToString:@"stage"]) {
            return Stage;
        }
        if ([env isEqualToString:@"prod"]) {
            return Prod;
        }
    }
    return None;
    
}
@end

//
//  Header.h
//  xiaoxinbao
//
//  Created by chyang on 16/2/25.
//  Copyright © 2016年 chyang. All rights reserved.
//

#ifndef Header_h
#define Header_h


#define First_Launched @"firstLaunch"
//友盟统计
#define UM_ANALYTICS @"5b0faf29a40fa32449000016"
#define UM_ANALYTICS_STAGE @"5b31fe49a40fa319b1000013"
//友盟推送
#define UM_KEY @"570e1c32e0f55a622b003145"
//微信 appid
#define APP_ID @"wx84116c02d50bb9c8"
//udid key
#define UDIDSTOREKEY @"UUIDSTOREKEY"


#endif /* Header_h */

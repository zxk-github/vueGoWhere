//
//  GlobalUtil.h
//  NongheMobileApp
//
//  Created by 胡鹏飞 on 2017/7/14.
//
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Header.h"
//适配swift 改写宏定义



typedef NS_ENUM(NSUInteger, AppEnvironment) {
    Test,
    Stage,
    Prod,
    None
};

@interface GlobalUtil : NSObject

//DEBUG  模式下打印日志,当前行
#ifdef DEBUG
#define NSLog(format, ...) do {                                                             \
fprintf(stderr, "<%s : %d> %s\n",                                           \
[[[NSString stringWithUTF8String:__FILE__] lastPathComponent] UTF8String],  \
__LINE__, __func__);                                                        \
(NSLog)((format), ##__VA_ARGS__);                                           \
fprintf(stderr, "-------\n");                                               \
} while (0)
#else
#define NSLog(...)
#endif

//代码块弱引用
#define WS(weakSelf)  __weak __typeof(&*self)weakSelf = self;
/**随机0~Int的整数*/
#define AYRandInt(Int) arc4random_uniform(Int+1)

//获取系统版本
#define IOS_VERSION [[[UIDevice currentDevice] systemVersion] floatValue]
#define CurrentSystemVersion [[UIDevice currentDevice] systemVersion]
#define UMSYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[UIDevice currentDevice].systemVersion floatValue] >= v)
#define backStr(Oldtr) IsEmptyValue(Oldtr)?@"":Oldtr
//#define RGB(r, g, b) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:1.0f]
//读取本地图片
#define LOADIMAGE(file,ext) [UIImage imageWithContentsOfFile:[[NSBundle mainBundle]pathForResource:file ofType:ext]]

//定义UIImage对象
#define IMAGE(imageName) [UIImage imageNamed:[NSString stringWithFormat:@"%@",imageName]]

// rgb颜色转换（16进制->10进制）
#define UIColorFromHex(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

// 获取RGB颜色
#define RGBA(r,g,b,a) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:a]

#define IS_IOS_7 ([GlobalUtils getDeviceSystemVersion] >= 7 )
#define IOS_VERSION_LOW_7 ([GlobalUtils getDeviceSystemVersion] < 7)
#define IS_IOS_8 ([GlobalUtils getDeviceSystemVersion] >= 8 )
//竖屏下的设备尺寸
#define is_iPhoenX ([[UIScreen mainScreen] currentMode].size.width == 1125.0f && [[UIScreen mainScreen] currentMode].size.height == 2436.0f)
#define is_iPhone6PlusZoomModel ([[UIScreen mainScreen] currentMode].size.width == 1125.0f)
#define is_iphone6Plus ([[UIScreen mainScreen] currentMode].size.width == 1242.0f )
#define is_iPhone6 ([[UIScreen mainScreen] currentMode].size.width == 750.0f )
#define is_iPhone5 (([[UIScreen mainScreen] currentMode].size.width == 640.0f ) && ([[UIScreen mainScreen] currentMode].size.height == 1136.0f))
//未做ipad情况下将ipad认为4s来适配
#define is_iPhone4s (((([[UIScreen mainScreen] currentMode].size.width == 640.0f ) && ([[UIScreen mainScreen] currentMode].size.height == 960.0f))) || [[UIDevice currentDevice].model hasPrefix:@"iPad"]) ? YES : NO
#define isRetina_4InchWidth ([[UIScreen mainScreen] currentMode].size.width == 640.0f ) || ([[UIDevice currentDevice].model hasPrefix:@"iPad"]) ? YES : NO

#define CGM(X, Y, W, H) CGRectMake(X, Y, W, H)
/** 屏幕宽度 */
#define UI_SCREEN_WIDTH             ([[UIScreen mainScreen] bounds].size.width)
/** 屏幕高度 */
#define UI_SCREEN_HEIGHT            ([[UIScreen mainScreen] bounds].size.height)

#define  UI_StatusBarHeight      (is_iPhoenX ? 44.f : 20.f)
#define  UI_TabbarHeight         (is_iPhoenX ? (49.f + 34.f) : 49.f)
#define  UI_TabbarSafeBottomMargin         (is_iPhoenX ? 34.f : 0.f)
#define  UI_StatusBarAndNavigationBarHeight  (is_iPhoenX ? 88.f : 64.f)
// safe area
#define  UI_SafeAreInsets(view) ({UIEdgeInsets insets; if(@available(iOS 11.0, *)) {insets = view.safeAreaInsets;} else {insets = UIEdgeInsetsZero;} insets;})
/** 屏幕大小 */
#define UI_SCREEN_BOUNDS [UIScreen mainScreen].bounds
/** 去除空格 */
#define allTrim( object ) [object stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]





+ (NSString *_Nullable)getAppVersion;//app 版本
+ (NSString *_Nullable)UDIDString;//设备唯一标示
+ (NSString *_Nullable)appToken;//用于设置到请求的header(cookie)里
+ (void)saveToken:(NSDictionary *_Nonnull)token;
+(NSString *_Nonnull)backStr:(NSString *_Nonnull) str defaultValue:(NSString *_Nonnull)defaultValue;
+(void)showHudForView:(UIView *_Nonnull)view message:(NSString *_Nonnull)message;
+(void)hudDismissForView:(UIView *_Nonnull)view;
+(NSDictionary *_Nonnull)environmentInfo;
+(NSDictionary *_Nonnull)findAreaByProvinceName:(NSString *_Nullable)provinceName cityName:(NSString *_Nullable)cityName districtName:(NSString *_Nullable)districtName;
+(void)makeAlertForMessage:(NSString *)message;
+(AppEnvironment)getAppEnvironment;

@end
static inline BOOL IsEmptyValue(id _Nullable thing) {
    return thing == nil
    || ([thing respondsToSelector:@selector(length)]
        && [(NSData *)thing length] == 0)
    || ([thing respondsToSelector:@selector(count)]
        && [(NSArray *)thing count] == 0)
    ||  ([thing isKindOfClass:[NSNull class]]);
}
static inline CGFloat screenWidth(){
    return [[UIScreen mainScreen] bounds].size.width;
}
static inline CGFloat screenHeight(){
    return [[UIScreen mainScreen] bounds].size.height;
}
static inline CGRect screenBounds(){
    return [UIScreen mainScreen].bounds;
}
static inline UIColor * _Nonnull colorFromRGBA(CGFloat r, CGFloat g, CGFloat b, CGFloat a){
    return [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:1.0f];
}
static inline UIColor * _Nonnull colorFromHex(int hexValue){
    return [UIColor colorWithRed:((float)((hexValue & 0xFF0000) >> 16))/255.0 green:((float)((hexValue & 0xFF00) >> 8))/255.0 blue:((float)(hexValue & 0xFF))/255.0 alpha:1.0];
}
static inline UIImage * _Nonnull imageByName(NSString * _Nonnull name){
    return [UIImage imageNamed:[NSString stringWithFormat:@"%@",name]];
}
//竖屏下的设备,根据宽度判断 主要对个别控件纵向高度适配
static inline BOOL is6PZoomMode(){
    return ([[UIScreen mainScreen] currentMode].size.width == 1125.0f) ? YES : NO;
}
static inline BOOL is6P(){
    return ([[UIScreen mainScreen] currentMode].size.width == 1242.0f ) ? YES : NO;
}

static inline BOOL is6(){
    return ([[UIScreen mainScreen] currentMode].size.width == 750.0f ) ? YES : NO;
}
static inline BOOL is4With(){
    return ([[UIScreen mainScreen] currentMode].size.width == 640.0f ) ? YES : NO;
}
//未适配ipad时
static inline BOOL universalIpad(){
    return ([[UIDevice currentDevice].model hasPrefix:@"iPad"]) ? YES : NO;
}
//static inline NSString * _Nonnull baseURL(){
//    return baseUrl;
//}


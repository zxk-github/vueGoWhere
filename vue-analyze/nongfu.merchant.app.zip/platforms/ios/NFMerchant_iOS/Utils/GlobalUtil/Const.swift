//
//  const.swift
//  NongheMobileApp
//
//  Created by 胡鹏飞 on 2017/7/28.
//
//

import Foundation
import WebKit
//import
//let baseUrl = baseURL()
let C_mainGreen = colorFromRGBA(13, 189, 118, 1)
let C_mainRed = colorFromRGBA(255, 113, 47, 1)
let C_background = colorFromRGBA(244, 245, 248, 1) // 背景打底色
let C_darkGray = colorFromRGBA(51, 51, 51, 1)//深灰 用于深色字体
let C_lightGray = colorFromRGBA(102, 102, 102, 1)//浅灰 描述性文字
let C_disable = colorFromHex(0xB6B6B6) // 不可点击按钮


var navigationBarHeight: CGFloat {
    return is_iPhoneX ? 88.0 : 64.0
}



func printLog<T>(message: T,
                 file: String = #file,
                 method: String = #function,
                 line: Int = #line)
{
    #if DEBUG
        print("\((file as NSString).lastPathComponent)[\(line)], \(method): \(message)")
    #endif
}
var is_iPhoneX: Bool {
    return UIScreen.main.currentMode?.size.width ==
    1125.0
}
var statusBarHeight: CGFloat {
    return is_iPhoneX ? 44.0 : 20.0
}

var safeBottomMargin: CGFloat {
    return is_iPhoneX ? 34.0 : 0.0
}

var translucentNavigationBarHeight: CGFloat {
    return is_iPhoneX ? 88.0 : 64.0
}



func randomInRange(range: Range<Int>) -> Int {
    let count = UInt32(range.upperBound - range.lowerBound)
    return  Int(arc4random_uniform(count)) + range.lowerBound
}

// weex

let WX_SDK_ROOT_REF = "_root"

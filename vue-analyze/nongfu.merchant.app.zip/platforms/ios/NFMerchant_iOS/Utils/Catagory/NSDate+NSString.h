//
//  NSDate+NSString.h
//  Hnair4iPhone
//
//  Created by yingkong1987 on 13-10-18.
//  Copyright (c) 2013年 yingkong1987. All rights reserved.
//

@import Foundation;

@interface NSDate (NSString)
- (NSString *) GJHString;
- (NSString *) GJHWeekString;
- (NSString *) yearString;
- (NSString *) monthString;
- (NSString *) dayString;
- (NSString *) weekString;
- (NSString *) dateString;
- (NSString *) sortDateString;
- (NSString *) timeString;
- (NSString *) sortDateStringAndWeek;
- (NSString *) briefWeekString;
- (NSString *) briefDayString;
@end

//
//  NSDate+NSString.m
//  Hnair4iPhone
//
//  Created by yingkong1987 on 13-10-18.
//  Copyright (c) 2013年 yingkong1987. All rights reserved.
//

#import "NSDate+NSString.h"
#import "NSDate+Calendar.h"

@implementation NSDate (NSString)
- (NSString *)GJHString
{
    NSString *str = [self dateString];
    NSString *eeStr = [self GJHWeekString];
    return [NSString stringWithFormat:@"%@ %@",str,eeStr];
}

- (NSString *)GJHWeekString
{
    NSString *eeStr = nil;
    switch ([self weekday]) {
        case 1:
        {
            eeStr = @"周日";
        }
            break;
        case 2:
        {
            eeStr = @"周一";
        }
            break;
        case 3:
        {
            eeStr = @"周二";
        }
            break;
        case 4:
        {
            eeStr = @"周三";
        }
            break;
        case 5:
        {
            eeStr = @"周四";
        }
            break;
        case 6:
        {
            eeStr = @"周五";
        }
            break;
        case 7:
        {
            eeStr = @"周六";
        }
            break;
        default:
            eeStr = @"";
            break;
    }
    return eeStr;
}

- (NSString *) yearString
{
    if (!self) {
        return @"";
    }
    NSDateFormatter *fm = [NSDateFormatter new];
    [fm setDateFormat:@"yyyy"];
    return [fm stringFromDate:self];
}

- (NSString *) monthString
{
    if (!self) {
        return @"";
    }
    NSDateFormatter *fm = [NSDateFormatter new];
    [fm setDateFormat:@"MM月"];
    return [fm stringFromDate:self];
}

- (NSString *) dayString
{
    if (!self) {
        return @"";
    }
    NSDateFormatter *fm = [NSDateFormatter new];
    [fm setDateFormat:@"dd日"];
    return [fm stringFromDate:self];
}

- (NSString *) weekString
{
		if (!self) {
				return @"";
		}
        NSDateFormatter *fm = [NSDateFormatter new];
		[fm setDateFormat:@"EE"];
		return [fm stringFromDate:self];
}

- (NSString *) dateString
{
		if (!self) {
				return @"";
		}
		NSDateFormatter *fm = [NSDateFormatter new];
		[fm setDateFormat:@"yyyy-MM-dd"];
		return [fm stringFromDate:self];
}

- (NSString *) timeString
{
		if (!self) {
				return @"";
		}
		NSDateFormatter *fm = [NSDateFormatter new];
		[fm setDateFormat:@"HH:mm"];
		return [fm stringFromDate:self];
}

- (NSString *) sortDateString
{
		if (!self) {
				return @"";
		}
		NSDateFormatter *fm = [NSDateFormatter new];
		[fm setDateFormat:@"MM-dd"];
		return [fm stringFromDate:self];
}

- (NSString *) sortDateStringAndWeek
{
		if (!self) {
				return @"";
		}
		NSDateFormatter *fm = [NSDateFormatter new];
		[fm setDateFormat:@"MM-dd EE"];
		return [fm stringFromDate:self];
}

- (NSString *) briefWeekString{
    if (!self) {
        return @"";
    }
    NSString *eeStr = nil;
    switch ([self weekday]) {
        case 1:
        {
            eeStr = @"日";
        }
            break;
        case 2:
        {
            eeStr = @"一";
        }
            break;
        case 3:
        {
            eeStr = @"二";
        }
            break;
        case 4:
        {
            eeStr = @"三";
        }
            break;
        case 5:
        {
            eeStr = @"四";
        }
            break;
        case 6:
        {
            eeStr = @"五";
        }
            break;
        case 7:
        {
            eeStr = @"六";
        }
            break;
        default:
            eeStr = @"";
            break;
    }
    return eeStr;
    
}
- (NSString *) briefDayString{
    if (!self) {
        return @"";
    }
    NSDateFormatter *fm = [NSDateFormatter new];
    [fm setDateFormat:@"dd"];
    return [fm stringFromDate:self];
}


@end

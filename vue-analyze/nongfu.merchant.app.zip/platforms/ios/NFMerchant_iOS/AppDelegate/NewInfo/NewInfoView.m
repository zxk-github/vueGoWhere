//
//  NewInfoView.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/3/28.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "NewInfoView.h"

@implementation NewInfoView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end

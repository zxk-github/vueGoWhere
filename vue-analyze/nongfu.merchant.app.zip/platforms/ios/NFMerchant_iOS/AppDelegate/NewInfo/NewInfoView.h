//
//  NewInfoView.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2018/3/28.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewInfoView : UIView

@end

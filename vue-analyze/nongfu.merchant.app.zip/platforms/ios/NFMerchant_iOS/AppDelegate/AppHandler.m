//
//  AppDelegateHandler.m
//  NFMerchant_iOS
//
//  Created by 胡鹏飞 on 2018/5/17.
//  Copyright © 2018年 taobao. All rights reserved.
//

#import "AppHandler.h"

#import "DemoDefine.h"
#import <WeexSDK/WeexSDK.h>
#import <AVFoundation/AVFoundation.h>
//#import <ATSDK/ATManager.h>
#import "WeexSDKManager.h"
#if DEVELOPMENT
#import <TBWXDevTool/WXDevTool.h>
#endif
#import "FLViewController.h"
#import "WXApi.h"
#import "WXApiManager.h"
#import "NHNetWorkEngine.h"
#import "GlobalUtil.h"
#import "SystemPermissionsManager.h"
#import "StorageModule.h"

#if DEVELOPMENT
#import "NFMerchant_iOSDev-Swift.h"
#else
#import "NFMerchant_iOS-Swift.h"
#endif

#import <UMCommon/UMCommon.h>
#import <UMAnalytics/MobClick.h>
#import <UMCommonLog/UMCommonLogHeaders.h>
#import "Reachability.h"


@implementation NSArray (Compare)

- (BOOL)lexicographicallyPrecedesWithOther:(NSArray *)array areInIncreasingOrder:(BOOL (^)(id, id))block
{
    NSParameterAssert(array);
    NSParameterAssert(block);
    NSUInteger idx = 0;
    
    for (id obj in self) {
        if (idx == array.count) { break; }//遍历结束
        
        if ([obj isEqual:array[idx]]) { ++idx; continue; }//两元素相等 跳过
        
        return block(obj, array[idx]); //交由block判断
    }
    
    return self.count > array.count; //若self 元素为空  或者 self 和 Other 前N位相同
}

@end
@implementation AppHandler
+(void) initSDK {
    //    [WXDevTool setDebug:YES];
    //    [WXDevTool launchDevToolDebugWithUrl:@"ws://192.168.1.98:8088/debugProxy/native"];
    [NSThread sleepUntilDate:[NSDate dateWithTimeIntervalSinceNow:1]];//说是启动图太快,看不清
    
    //添加蓝牙打印的key
    
    /*
     //引导页
     if ([[NSUserDefaults standardUserDefaults] boolForKey:@"first_launch"]) {
     [WeexSDKManager setup];
     } else {
     FLViewController *firstView = [[FLViewController alloc] init];
     firstView.completionBlock = ^(){
     [WeexSDKManager setup];
     [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"first_launch"];
     [[NSUserDefaults standardUserDefaults] synchronize];
     };
     self.window.rootViewController = firstView;
     }
     */
    //向微信注册wxd930ea5d5a258f4f
    //    [WXApi registerApp:WX_AppId];
    
    //友盟
    
    if ([GlobalUtil getAppEnvironment] == Stage) {
        [UMConfigure initWithAppkey:UM_ANALYTICS_STAGE channel:@"App Store"];//初始化
    } else {
        [UMConfigure initWithAppkey:UM_ANALYTICS channel:@"App Store"];//初始化
    }
    [UMConfigure initWithAppkey:UM_ANALYTICS channel:@"App Store"];//初始化
    [MobClick setScenarioType:E_UM_NORMAL];//统计普通场景
    //开发者需要显式的调用此函数，日志系统才能工作
#if DEBUG
//    [UMCommonLogManager setUpUMCommonLogManager];
//    [UMConfigure setLogEnabled:YES];//设置打开日志  上线关闭
//    NSString* deviceID =  [UMConfigure deviceIDForIntegration];
//    NSLog(@"集成测试的deviceID:%@",deviceID);
#endif
    [MobClick setCrashReportEnabled:YES];   // Crash收集
    
    //此函数在UMCommon.framework版本1.4.2及以上版本，在UMConfigure.h的头文件中加入。
    //如果用户用组件化SDK,需要升级最新的UMCommon.framework版本。

    
    
    [[SystemPermissionsManager sharedManager] startLocationRequest];
    [WeexSDKManager setup];
 
}
+(void)dealNetWortMonitor{
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    [(AppDelegate *)[UIApplication sharedApplication].delegate setReachablity:reachability];
    [reachability startNotifier];
}

+(void) checkNews{
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
    
//    NSDictionary *responseObject = @{
//        @"Version": @"2.0.5",
//        @"VersionCode": @8,
//        @"Filename": @"https://itunes.apple.com/us/app/%E6%86%9C%E6%9C%8D%E6%8E%8C%E6%9F%9C/id1356462437?l=zh&ls=1&mt=8",
//        @"Description": @"农服掌柜",
//        @"AlertTitle": @"发现新版本",
//        @"SpecialVersion": @{
//            @"2.0.5": @1,
//            @"2.0.6": @1
//        },
//        @"NeedShowTip": @1,
//        @"ForceUpdate": @1,
//        @"ForceUpdateRanges":@[
//                             @{
//                                 @"Lower": @"2.0.0",
//                                 @"Upper": @"2.4.0"
//                             }
//                             ],
//        @"Update": @1,
//        @"UpdateRanges": @[
//                         @{
//                             @"Lower": @"2.0.0",
//                             @"Upper": @"2.0.6"
//                         }
//                         ]
//        };
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"environment" ofType:@"json"];
    NSData *jsonData = [NSData dataWithContentsOfFile:filePath];
    NSError *error = nil;
    NSDictionary *source = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
    if (!error) {
        [NHNetWorkEngine GETRequestWithPath:source[@"release_url"] andParameters:nil success:^(NSURLSessionDataTask * _Nullable task, id  _Nullable responseObject) {
            NSString *currentVersion = [GlobalUtil getAppVersion];
//            NSString *currentVersion = @"2.4.0.53";
            //        NSDictionary *version = backStr([data objectForKey:@"SpecialVersion"]);//老版本的范围表
            
            //新增范围内版本号更新 2.4.0上线之后 修改 -------------------------start
            NSNumber *showTip = [responseObject objectForKey:@"NeedShowTip"];
            //强制
            NSArray *forceVersionRanges = [responseObject objectForKey:@"ForceUpdateRanges"];
            NSNumber *forceUpdate = [responseObject objectForKey:@"ForceUpdate"];
            //非强制
            NSNumber *update = [responseObject objectForKey:@"Update"];
            NSArray *versionRanges = [responseObject objectForKey:@"UpdateRanges"];
            
            BOOL force = [forceUpdate boolValue];
            BOOL normal = [update boolValue];
            
            BOOL needForce = [self isCurrent:currentVersion InRanges:forceVersionRanges];
            BOOL needNormal = [self isCurrent:currentVersion InRanges:versionRanges];
            
            if (force && needForce && [showTip integerValue] == 1) {
                ((AppDelegate *) [UIApplication sharedApplication].delegate).force = force;
                [self showTipsWithData:responseObject force:YES];
                return;
            }
            
            if (normal && needNormal && [showTip integerValue] == 1) {
                [self showTipsWithData:responseObject force:NO];
                
            }
            //2.4.0上线之后 修改 --------------------end
            
        } fail:^(NSURLSessionDataTask * _Nullable task, id  _Nullable responseObject, NSError * _Nullable error) {

        }];
    }
    
    
}


+(BOOL)isCurrent:(NSString *)current InRanges:(NSArray <NSDictionary <NSString*, NSString*> *> *)ranges {
    //version最多有4部分组成
    __block BOOL contain = NO;
    contain = NO;
    NSArray *currentVersionCommpents = [current componentsSeparatedByString:@"."];
    
    [ranges enumerateObjectsUsingBlock:^(NSDictionary<NSString*, NSString*>*  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSString *low = obj[@"Lower"];
        NSString *high = obj[@"Upper"];
        
        NSArray *lowVersionCommpents = [low componentsSeparatedByString:@"."];
        NSArray *highVersionCommpents = [high componentsSeparatedByString:@"."];

        
        if ([low isEqualToString:current] || [high isEqualToString:current]) {//边界也算上
            contain = YES;
        } else { //判断 是否在 lower 和upper 区间内
            
            BOOL first = NO;
            BOOL second = NO;
            //current > lower
            first = [currentVersionCommpents lexicographicallyPrecedesWithOther:lowVersionCommpents areInIncreasingOrder:^BOOL(NSString * current, NSString * low) {
                return current.integerValue > low.integerValue;
            }];
            //upper > current
            second = [highVersionCommpents lexicographicallyPrecedesWithOther:currentVersionCommpents areInIncreasingOrder:^BOOL(NSString * hight, NSString * current) {
                return current.integerValue < hight.integerValue;
            }];
            if (first && second) {
                contain = YES;
            }
        }
        
        *stop = contain;
    }];
    return contain;
}

+(void)showTipsWithData:(NSDictionary *)data force:(BOOL)force {
    
    
    NSString *link = backStr([data objectForKey:@"Filename"]);
    NSString *title = backStr([data objectForKey:@"AlertTitle"]);
    NSString *description = backStr([data objectForKey:@"Description"]);
    
    
    UIAlertController *alertVc = [UIAlertController alertControllerWithTitle:title message:description preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *sureAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[link stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]]]];
    }];
    UIAlertAction *cancleAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    [alertVc addAction:sureAction];
    if (!force) {
        [alertVc addAction:cancleAction];
    }
    alertVc.preferredAction = sureAction;
    [[UIApplication sharedApplication].delegate.window.rootViewController presentViewController:alertVc animated:true completion:nil];
    return ;
}


@end

/**
 * Created by Weex.
 * Copyright (c) 2016, Alibaba, Inc. All rights reserved.
 *
 * This source code is licensed under the Apache Licence 2.0.
 * For the full copyright and license information,please view the LICENSE file in the root directory of this source tree.
 */

#import "AppDelegate.h"
#import "DemoDefine.h"
#import <WeexSDK/WeexSDK.h>
#import <AVFoundation/AVFoundation.h>
//#import <ATSDK/ATManager.h>
#import "WeexSDKManager.h"
#import "WXScannerVC.h"
#if DEVELOPMENT
#import <TBWXDevTool/WXDevTool.h>
#endif
#import "FLViewController.h"
#import "WXApi.h"
#import "WXApiManager.h"
#import "NHNetWorkEngine.h"
#import "GlobalUtil.h"
#import "SystemPermissionsManager.h"
@interface AppDelegate ()
@property (nonatomic, assign) BOOL force;
@end

@implementation AppDelegate

#pragma mark
#pragma mark application

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = [UIColor whiteColor];
    self.force = NO;
    
    
//    [WXDevTool setDebug:YES];
//    [WXDevTool launchDevToolDebugWithUrl:@"ws://192.168.1.98:8088/debugProxy/native"];
    [NSThread sleepUntilDate:[NSDate dateWithTimeIntervalSinceNow:1]];//说是启动图太快,看不清
        
    //添加蓝牙打印的key
    
    /*
     //引导页
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"first_launch"]) {
        [WeexSDKManager setup];
    } else {
        FLViewController *firstView = [[FLViewController alloc] init];
        firstView.completionBlock = ^(){
            [WeexSDKManager setup];
            [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"first_launch"];
            [[NSUserDefaults standardUserDefaults] synchronize];
        };
        self.window.rootViewController = firstView;
    }
    */
    //向微信注册wxd930ea5d5a258f4f
    //    [WXApi registerApp:WX_AppId];
    [self checkNews];
    [[SystemPermissionsManager sharedManager] startLocationRequest];
    [WeexSDKManager setup];
    [self.window makeKeyAndVisible];
    
    
    
    // Override point for customization after application launch.
//    [self startSplashScreen];
    
//    [self checkUpdate];
    
    return YES;
}



-(void)applicationDidBecomeActive:(UIApplication *)application{
    if (_force) {
        [self checkNews];
    }
    
}

-(void)application:(UIApplication *)application performActionForShortcutItem:(UIApplicationShortcutItem *)shortcutItem completionHandler:(void (^)(BOOL))completionHandler
{
    if ([shortcutItem.type isEqualToString:QRSCAN]) {
        WXScannerVC * scanViewController = [[WXScannerVC alloc] init];
        [(WXRootViewController*)self.window.rootViewController pushViewController:scanViewController animated:YES];
    }
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    
#ifdef UITEST
#if !TARGET_IPHONE_SIMULATOR
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    setenv("GCOV_PREFIX", [documentsDirectory cStringUsingEncoding:NSUTF8StringEncoding], 1);
    setenv("GCOV_PREFIX_STRIP", "6", 1);
#endif
    extern void __gcov_flush(void);
    __gcov_flush();
#endif
}
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url {
    return  [WXApi handleOpenURL:url delegate:[WXApiManager sharedManager]];
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation {
    return [WXApi handleOpenURL:url delegate:[WXApiManager sharedManager]];
}
#pragma mark
#pragma mark animation when startup

- (void)startSplashScreen
{
    UIView* splashView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    splashView.backgroundColor = WEEX_COLOR;
    
    UIImageView *iconImageView = [UIImageView new];
    UIImage *icon = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"weex-icon" ofType:@"png"]];
    if ([icon respondsToSelector:@selector(imageWithRenderingMode:)]) {
        iconImageView.image = [icon imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        iconImageView.tintColor = [UIColor whiteColor];
    } else {
        iconImageView.image = icon;
    }
    iconImageView.frame = CGRectMake(0, 0, 320, 320);
    iconImageView.contentMode = UIViewContentModeScaleAspectFit;
    iconImageView.center = splashView.center;
    [splashView addSubview:iconImageView];
    
    [self.window addSubview:splashView];
    
    float animationDuration = 1.4;
    CGFloat shrinkDuration = animationDuration * 0.3;
    CGFloat growDuration = animationDuration * 0.7;
    
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0) {
        [UIView animateWithDuration:shrinkDuration delay:1.0 usingSpringWithDamping:0.7f initialSpringVelocity:10 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            CGAffineTransform scaleTransform = CGAffineTransformMakeScale(0.75, 0.75);
            iconImageView.transform = scaleTransform;
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:growDuration animations:^{
                CGAffineTransform scaleTransform = CGAffineTransformMakeScale(20, 20);
                iconImageView.transform = scaleTransform;
                splashView.alpha = 0;
            } completion:^(BOOL finished) {
                [splashView removeFromSuperview];
            }];
        }];
    } else {
        [UIView animateWithDuration:shrinkDuration delay:1.0 options:0 animations:^{
            CGAffineTransform scaleTransform = CGAffineTransformMakeScale(0.75, 0.75);
            iconImageView.transform = scaleTransform;
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:growDuration animations:^{
                CGAffineTransform scaleTransform = CGAffineTransformMakeScale(20, 20);
                iconImageView.transform = scaleTransform;
                splashView.alpha = 0;
            } completion:^(BOOL finished) {
                [splashView removeFromSuperview];
            }];
        }];
    }
}

#pragma mark

- (void)atAddPlugin {
    
//    [[ATManager shareInstance] addPluginWithId:@"weex" andName:@"weex" andIconName:@"../weex" andEntry:@"" andArgs:@[@""]];
//    [[ATManager shareInstance] addSubPluginWithParentId:@"weex" andSubId:@"logger" andName:@"logger" andIconName:@"log" andEntry:@"WXATLoggerPlugin" andArgs:@[@""]];
//    [[ATManager shareInstance] addSubPluginWithParentId:@"weex" andSubId:@"viewHierarchy" andName:@"hierarchy" andIconName:@"log" andEntry:@"WXATViewHierarchyPlugin" andArgs:@[@""]];
//    [[ATManager shareInstance] addSubPluginWithParentId:@"weex" andSubId:@"test2" andName:@"test" andIconName:@"at_arr_refresh" andEntry:@"" andArgs:@[]];
//    [[ATManager shareInstance] addSubPluginWithParentId:@"weex" andSubId:@"test3" andName:@"test" andIconName:@"at_arr_refresh" andEntry:@"" andArgs:@[]];
}

- (void)checkNews {
    [NHNetWorkEngine GETRequestWithPath:@"http://pkgs.b2cf.cn/public/dists/zhanggui_prod/app/ios/release" andParameters:nil success:^(NSURLSessionDataTask * _Nullable task, id  _Nullable responseObject) {
        NSString *currentVersion = [GlobalUtil getAppVersion];
        NSString *link = backStr([responseObject objectForKey:@"Filename"]);
        NSString *title = backStr([responseObject objectForKey:@"AlertTitle"]);
        NSString *description = backStr([responseObject objectForKey:@"Description"]);
        NSDictionary *version = backStr([responseObject objectForKey:@"SpecialVersion"]);
        
        //新增范围内版本号更新 2.2.0上线之后 修改 -------------------------start
        NSNumber *showTip = [responseObject objectForKey:@"NeedShowTip"];
        NSArray *versionRange = [responseObject objectForKey:@"VersonRangeForUpdate"];
        NSNumber *forceUpdate = [responseObject objectForKey:@"ForceUpdate"];
        self.force = [forceUpdate boolValue];
        
        if ([version valueForKey:currentVersion] && [[version valueForKey:currentVersion] integerValue] == 1 && [showTip integerValue] == 1) {//如果version有对应的当前版本 且对应的当前版本值为1 且 提示
            UIAlertController *alertVc = [UIAlertController alertControllerWithTitle:title message:description preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *sureAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[link stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]]]];
            }];
            UIAlertAction *cancleAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
            [alertVc addAction:sureAction];
            if (!_force) {
                [alertVc addAction:cancleAction];
            }
            alertVc.preferredAction = sureAction;
            [self.window.rootViewController presentViewController:alertVc animated:true completion:nil];
            return ;
        }
        
        //version最多有4部分组成
        __block BOOL contain = NO;
        NSArray *currentVersionCommpents = [currentVersion componentsSeparatedByString:@"."];
        NSString *current1 = currentVersionCommpents[0];
        NSString *current2 = currentVersionCommpents[1];
        NSString *current3 = currentVersionCommpents[2];
        NSString *current4 = @"0";
        if (currentVersionCommpents.count > 3) {
            current4 = currentVersionCommpents[3];
        }
        
        [versionRange enumerateObjectsUsingBlock:^(NSDictionary<NSString*, NSString*>*  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSString *low = obj[@"low"];
            NSString *high = obj[@"high"];
            
            NSArray *lowVersionCommpents = [currentVersion componentsSeparatedByString:@"."];
            NSString *low1 = currentVersionCommpents[0];
            NSString *low2 = currentVersionCommpents[1];
            NSString *low3 = currentVersionCommpents[2];
            NSString *low4 = @"0";
            if (lowVersionCommpents.count > 3) {
                low4 = currentVersionCommpents[3];
            }
            
            NSArray *highVersionCommpents = [currentVersion componentsSeparatedByString:@"."];
            NSString *high1 = currentVersionCommpents[0];
            NSString *high2 = currentVersionCommpents[1];
            NSString *high3 = currentVersionCommpents[2];
            NSString *high4 = @"0";
            if (highVersionCommpents.count > 3) {
                high4 = currentVersionCommpents[3];
            }
            
            if ([low isEqualToString:currentVersion] || [high isEqualToString:currentVersion]) {//边界也算上
                contain = YES;
            } else if (low1.integerValue < current1.integerValue && high1.integerValue > current1.integerValue) {
                contain = YES;
            } else if (low2.integerValue < current2.integerValue && high2.integerValue > current1.integerValue) {
                contain = YES;
            } else if (low3.integerValue < current3.integerValue && high3.integerValue > current4.integerValue) {
                contain = YES;
            } else if (low4.integerValue < current4.integerValue && high4.integerValue > current4.integerValue) {
                contain = YES;
            }
            *stop = contain;
        }];
        if (contain && [showTip integerValue] == 1) {
            UIAlertController *alertVc = [UIAlertController alertControllerWithTitle:title message:description preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *sureAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[link stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]]]];
            }];
            UIAlertAction *cancleAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
            [alertVc addAction:sureAction];
            if (!_force) {
                [alertVc addAction:cancleAction];
            }
            alertVc.preferredAction = sureAction;
            [self.window.rootViewController presentViewController:alertVc animated:true completion:nil];
            return ;
        }
        //2.2.0上线之后 修改 --------------------end
        
    } fail:^(NSURLSessionDataTask * _Nullable task, id  _Nullable responseObject, NSError * _Nullable error) {
        
    }];
    
}



@end

//
//  FirstLaunchView.h
//  HangLianAirLine
//
//  Created by 航联千方 on 16/3/29.
//  Copyright © 2016年 胡鹏飞. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstLaunchView : UIView<UIScrollViewDelegate>
@property (weak, nonatomic) IBOutlet UIButton *finishBtn;
@property (copy, nonatomic) dispatch_block_t willTransitionBlock;

@property (weak, nonatomic) IBOutlet UIPageControl *pageController;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

@end

//
//  FirstLaunchView.m
//  HangLianAirLine
//
//  Created by 航联千方 on 16/3/29.
//  Copyright © 2016年 胡鹏飞. All rights reserved.
//

#import "FirstLaunchView.h"
#import "GlobalUtil.h"
@implementation FirstLaunchView
-(void)awakeFromNib{
    [super awakeFromNib];
    self.scrollView.delegate = self;
    self.pageController.userInteractionEnabled = NO;
    self.finishBtn.layer.borderColor = colorFromHex(0xfebe64).CGColor;
    self.finishBtn.layer.borderWidth = 1;
    self.finishBtn.layer.cornerRadius = 20;
    for (int i = 0; i < 4; i++) {
        UIImageView *imageView = [_scrollView viewWithTag:100 + i];
        if (is_iPhone4s || is_iphone6Plus) {
            imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"firstlaunch%d",i + 1]];
        }else if (is_iPhone5){
            imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"firstlaunch%d_568",i + 1]];
        }else if (is_iPhone6 || is_iPhone6PlusZoomModel ){
            imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"firstlaunch%d_667",i + 1]];
        }
    }
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    if (scrollView.contentOffset.x > [UIScreen mainScreen].bounds.size.width * 2 ) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            if (scrollView.contentOffset.x > [UIScreen mainScreen].bounds.size.width * 2 ) {
                [UIView animateWithDuration:1.5 animations:^{
                    self.layer.affineTransform = CGAffineTransformMakeScale(1.5, 1.5);
                    self.alpha = 0;
                } completion:^(BOOL finished) {
                    if (self.willTransitionBlock) {
                        self.willTransitionBlock();
                    }
                }];
            }
        });
    }
}
- (IBAction)handleFinish:(id)sender {
    [UIView animateWithDuration:1.5 animations:^{
        self.layer.affineTransform = CGAffineTransformMakeScale(1.5, 1.5);
        self.alpha = 0;
    } completion:^(BOOL finished) {
        if (self.willTransitionBlock) {
            self.willTransitionBlock();
        }
    }];

}
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    self.pageController.currentPage = (NSInteger) (scrollView.contentOffset.x / UI_SCREEN_WIDTH);
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end

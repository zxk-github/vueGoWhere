//
//  FirstLaunchViewController.m
//  WeexDemo
//
//  Created by 胡鹏飞 on 2017/8/23.
//  Copyright © 2017年 taobao. All rights reserved.
//

#import "FLViewController.h"
#import "FirstLaunchView.h"
#import "GlobalUtil.h"
@interface FLViewController ()

@end

@implementation FLViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    FirstLaunchView *firstView = [[[NSBundle mainBundle] loadNibNamed:@"FirstLaunchView" owner:nil options:nil] firstObject];
    firstView.frame = [UIScreen mainScreen].bounds;
    firstView.willTransitionBlock = self.completionBlock;
    [self.view addSubview:firstView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  FirstLaunchViewController.h
//  WeexDemo
//
//  Created by 胡鹏飞 on 2017/8/23.
//  Copyright © 2017年 taobao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FLViewController : UIViewController
@property (copy, nonatomic) dispatch_block_t completionBlock;
@end

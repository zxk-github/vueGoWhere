//
//  File.swift
//  NFMerchant_iOS
//
//  Created by 胡鹏飞 on 2018/5/16.
//  Copyright © 2018年 taobao. All rights reserved.
//

import Foundation
import ReSwift

struct AppState: StateType  {
    let routingState: RoutingState
}

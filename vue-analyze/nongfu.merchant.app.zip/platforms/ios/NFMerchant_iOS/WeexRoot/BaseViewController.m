//
//  BaseViewController.m
//  NongheMobileApp
//
//  Created by 胡鹏飞 on 2017/7/18.
//
//

#import "BaseViewController.h"
#import "UINavigationController+FDFullscreenPopGesture.h"
#import "GlobalUtil.h"
@interface BaseViewController () 

@end

@implementation BaseViewController
-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}
-(void)viewWillAppear:(BOOL)animated{
    NSLog(@"show---  %@",self.class);
    [super viewWillAppear:animated];
}

-(void)viewWillDisappear:(BOOL)animated{
    NSLog(@"remove--- %@", self.class);
    [super viewWillDisappear:animated];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self configNav];
    if (self.navigationController.viewControllers.firstObject != self) {
        [self setSingleBackItem];
    }
    self.navigationController.interactivePopGestureRecognizer.delegate = self;
    
    
}
//-(BOOL)isConnectionAvailable{
//    return self.reachability.currentReachabilityStatus != NotReachable;
//}
- (void)configNav {
    self.navigationController.navigationBar.barTintColor = colorFromHex(0x272A33);
    self.navigationController.navigationBar.translucent = NO;
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName : [UIColor whiteColor], NSFontAttributeName: [UIFont systemFontOfSize:17]};

}
- (void)setSingleCloseItem {
    if (self.navigationController.viewControllers.count <= 1) {
        return;
    }
    UIButton  * leftButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 40, 40)];
    leftButton.tintColor = [UIColor lightGrayColor];
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [leftButton setImage:[UIImage imageNamed:@"close_leftItem"] forState:UIControlStateNormal];
    [leftButton setImageEdgeInsets:UIEdgeInsetsMake(0, -5, 0, 0)];
    [leftButton addTarget:self action:@selector(close) forControlEvents:UIControlEventTouchUpInside];
    
    
    UIBarButtonItem * leftBar = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftBar;
}
- (void) setDoubleReturnItem {
    if (self.navigationController.viewControllers.count <= 1) {
        return;
    }
    UIButton  * leftButton1 = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 40, 40)];
    leftButton1.tintColor = [UIColor lightGrayColor];
    leftButton1.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [leftButton1 setImage:[UIImage imageNamed:@"backItem"] forState:UIControlStateNormal];
    [leftButton1 setImageEdgeInsets:UIEdgeInsetsMake(0, -5, 0, 0)];
    [leftButton1 addTarget:self action:@selector(goBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem * leftBar1 = [[UIBarButtonItem alloc] initWithCustomView:leftButton1];

    UIButton  * leftButton2 = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 40, 40)];
    leftButton2.tintColor = [UIColor lightGrayColor];
    leftButton2.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [leftButton2 setImage:[UIImage imageNamed:@"close_leftItem"] forState:UIControlStateNormal];
    [leftButton2 setImageEdgeInsets:UIEdgeInsetsMake(0, -5, 0, 0)];
    [leftButton2 addTarget:self action:@selector(close) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem * leftBar2 = [[UIBarButtonItem alloc] initWithCustomView:leftButton2];

    self.navigationItem.leftBarButtonItems = @[leftBar1, leftBar2];
}
-(void)setSingleBackItem{
    if (self.navigationController.viewControllers.count < 1) {
        return;
    }
    UIButton  * leftButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 40, 40)];
    leftButton.tintColor = [UIColor lightGrayColor];
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [leftButton setImage:[UIImage imageNamed:@"fanhui_native"] forState:UIControlStateNormal];
    [leftButton setImageEdgeInsets:UIEdgeInsetsMake(0, -5, 0, 0)];
    [leftButton addTarget:self action:@selector(goBack) forControlEvents:UIControlEventTouchUpInside];

    
    UIBarButtonItem * leftBar = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftBar;
}
//- (void)setReachabilityChanged:(reachabilityBlock)reachabilityChanged{
//    _reachabilityChanged = reachabilityChanged;
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reachabilityChanged:) name:kReachabilityChangedNotification object:nil];
//}
//- (void)reachabilityChanged:(NSNotification *)note {
//    Reachability *curReach = [note object];
//    NetworkStatus netStatus = [curReach currentReachabilityStatus];
//    if (self.reachabilityChanged) {
//        self.reachabilityChanged(netStatus);
//    }
//}
//- (void)dealloc{
//
//    [[NSNotificationCenter defaultCenter]  removeObserver:self name:kReachabilityChangedNotification object:nil];
//}
- (void)goBack{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)close{
    if (self.presentingViewController) {
        [self dismissViewControllerAnimated:YES completion:nil];
    } else {
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@synthesize callback;

@synthesize wxData;

@end

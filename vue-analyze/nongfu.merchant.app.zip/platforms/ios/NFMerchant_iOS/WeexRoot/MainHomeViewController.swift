//
//  MainHomeViewController.swift
//  NFMerchant_iOS
//
//  Created by 胡鹏飞 on 2018/5/17.
//  Copyright © 2018年 taobao. All rights reserved.
//

import UIKit
import SocketRocket
import SwiftyJSON


class MainHomeViewController: BaseViewController {
    
    var url: URL?
    @objc var instance: WXSDKInstance?
    var weexView: UIView?
    
    var sharkMarked = true
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    @objc static func show(url: URL) {
        
        let routingAction = RoutingAction(destination: .mainHome, pragmas: JSON(["url": url.absoluteString]))
        
        store.dispatch(routingAction)
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.fd_prefersNavigationBarHidden = true
        self.view.backgroundColor = UIColor.white
        self.pageType = "weex"
        
        NotificationCenter.default.addObserver(self, selector: #selector(notificationRefreshInstance(_:)), name: NSNotification.Name(rawValue: "RefreshInstance"), object: nil)
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: Notification.Name.UIKeyboardWillHide, object: nil)
        if let urlStr = self.pragmas?["url"].string {
            url = URL(string: urlStr);
            render()
        }
        
        
        // Do any additional setup after loading the view.
    }

    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if self.canBecomeFirstResponder {
            UIApplication.shared.applicationSupportsShakeToEdit = true
            self.becomeFirstResponder()
        }
        updateInstanceState(state: .WeexInstanceAppear)
        let routingAction = RoutingAction(destination: .mainHome, pragmas: self.pragmas)
        store.dispatch(routingAction)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidAppear(animated)
        updateInstanceState(state: .WeexInstanceDisappear)
    }
    
    override func viewDidLayoutSubviews() {
        instance?.frame = CGRect(x: 0, y: 0, width: screenWidth(), height: self.view.frame.size.height)
        
    }
    
    
    @objc func notificationRefreshInstance(_ notify: Notification) {
        refreshWeex()
    }
    
    @objc func keyboardWillHide(_ notify: Notification) {
        instance?.frame = CGRect(x: 0, y: 0, width: screenWidth(), height: self.view.frame.size.height)
        instance?.rootView.frame = CGRect(x: 0, y: 0, width: screenWidth(), height: self.view.frame.size.height);
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "RefreshInstance"), object: nil)
        NotificationCenter.default.removeObserver(self, name: Notification.Name.UIKeyboardWillHide, object: nil)
        if instance != nil {
            AppDelegate.app2WXBridge?.deleteWXInstance(instance, forKey: RoutingDestination.mainHome.rawValue)
        }
        instance?.destroy()
    }
    
    
    func updateInstanceState(state: WXState) {
        if let wx = instance, wx.state != state {
            wx.state = state
            if state == .WeexInstanceAppear {
                WXSDKManager.bridgeMgr().fireEvent(wx.instanceId, ref: WX_SDK_ROOT_REF, type: "viewappear", params: nil, domChanges: nil)
            } else if state == .WeexInstanceDisappear {
                WXSDKManager.bridgeMgr().fireEvent(wx.instanceId, ref: WX_SDK_ROOT_REF, type: "viewdisappear", params: nil, domChanges: nil)
            }

        }
    }
    
    func render() {
        instance?.destroy()
        instance = WXSDKInstance()
        AppDelegate.app2WXBridge?.saveWXInstance(instance, forKey: RoutingDestination.mainHome.rawValue)

        instance!.viewController = self
        instance!.frame = CGRect(x: 0, y: 0, width: screenWidth(), height: self.view.frame.size.height)
        instance!.onCreate = { [weak self] (view) in
            self?.weexView?.removeFromSuperview()
            self?.weexView = view
            if self != nil {
                self!.view.addSubview(self!.weexView!)
            }
            UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, self?.weexView)
            
        }
        
        
        instance!.renderFinish = { [weak self] (view) in
            printLog(message: "Render Finish...")
            self?.updateInstanceState(state: .WeexInstanceAppear)
        }
        instance!.updateFinish = { [weak self] (view) in
            self?.updateInstanceState(state: .WeexInstanceAppear)
            printLog(message: "Update Finish...")
        }
        
        guard let currentUrl = testURL(url: url?.absoluteString) else {
            printLog(message: "error: render url is nil")
            return
        }
        let randomURL = String(format: "%@%@random=%d", currentUrl.absoluteString, (currentUrl.query != nil) ? "&" : "?", arc4random())
        
        instance?.render(with: URL(string: randomURL), options: ["bundleUrl": currentUrl.absoluteString], data: nil)
        
        
        
    }
    func refreshWeex() {
        render()
    }
    
    
    func testURL(url: String?) -> URL? {
        if let range =  url?.range(of: "_wx_tpl") {
            let tmp = url![range.lowerBound...]
            if let start = tmp.range(of: "=")?.lowerBound  {
                let lower = tmp.index(start, offsetBy: 1)
                var end = range.upperBound
                
                if let wxEnd = tmp.range(of: "&")?.lowerBound {
                    end = tmp.index(wxEnd, offsetBy: -1)
                }
                let wxTest = tmp[lower...end]
                return URL(string: String(wxTest))
            }
        }
        
        if let urlStr = url {
            return URL(string: urlStr)
        }
        
        return nil
        
    }
    
    func setTest() {
        self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(image: UIImage(named: "scan"), style: .plain, target: self, action: #selector(scanQR(item:)))
    }
    @objc func scanQR(item: UIBarButtonItem) {
        self.navigationController?.pushViewController(WXScannerVC(), animated: true)
    }
    //MARK - 摇一摇
    
//    override var canBecomeFirstResponder: Bool {
//        return true
//    }
//    override func motionBegan(_ motion: UIEventSubtype, with event: UIEvent?) {
//        
//    }
//    override func motionEnded(_ motion: UIEventSubtype, with event: UIEvent?) {
//        if motion == .motionShake {
//            if sharkMarked {
//                self.navigationController?.isNavigationBarHidden = false
//                sharkMarked = false
//            } else {
//                self.navigationController?.isNavigationBarHidden = true
//                sharkMarked = true
//            }
//            self.navigationController?.pushViewController(WXScannerVC(), animated: true)
//        }
//    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension MainHomeViewController: SRWebSocketDelegate {
    func webSocket(_ webSocket: SRWebSocket!, didReceiveMessage message: Any!) {
        if let msg = message as? String, msg == "refresh" {
            render()
        }
    }
}

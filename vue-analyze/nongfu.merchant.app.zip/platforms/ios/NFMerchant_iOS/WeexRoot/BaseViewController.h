//
//  BaseViewController.h
//  NongheMobileApp
//
//  Created by 胡鹏飞 on 2017/7/18.
//
//

#import <UIKit/UIKit.h>
#import "Navigator.h"

//#import "Reachability.h"

//typedef void(^reachabilityBlock)(NetworkStatus status);

@interface BaseViewController : UIViewController<NavigatorDataTransferDelegate>
//@property (nonatomic, strong) Reachability * reachability;
//@property (nonatomic, copy) reachabilityBlock reachabilityChanged;
@property (nonatomic, assign) BOOL preferedNavbarHidden;
//-(BOOL)isConnectionAvailable;
-(void)goBack;
@end
